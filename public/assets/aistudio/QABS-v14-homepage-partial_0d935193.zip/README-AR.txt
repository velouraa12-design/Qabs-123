قبس — ملفات الصفحة الرئيسية المعدّلة فقط
هذه ليست نسخة كاملة من قالب Shopify ولا تصلح للنشر منفردة.
تحتوي على ملف الصفحة الرئيسية وقسمها المعدلين، من مسودة PR #6 المبنية على النسخة المؤرشفة PR #3.
النسخة المرجعية الكاملة: https://github.com/velouraa12-design/qabs-unified-dashboard-template/pull/3
التعديل: https://github.com/velouraa12-design/qabs-unified-dashboard-template/pull/6
الأصول الثنائية وملفات القالب الأخرى غير موجودة في هذا الملف. لم يتم اختبارها في معاينة Shopify.
