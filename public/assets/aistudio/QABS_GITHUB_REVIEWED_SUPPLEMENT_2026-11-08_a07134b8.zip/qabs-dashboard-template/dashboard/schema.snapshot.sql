-- Snapshot of schema only. Apply ONLY to a new isolated empty database.
PRAGMA foreign_keys=ON;

CREATE TABLE account_email_changes (
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),session_hash TEXT NOT NULL,
 old_email TEXT NOT NULL,new_email TEXT NOT NULL,password_hash TEXT NOT NULL,mfa_version INTEGER NOT NULL,
 proof_hash TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,
 attempts INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL CHECK(status IN ('sending','sent','complete')),claim TEXT
);

CREATE TABLE account_mfa(user_id TEXT PRIMARY KEY REFERENCES users(id),enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN(0,1)),version INTEGER NOT NULL DEFAULT 0,secret TEXT,iv TEXT,last_step INTEGER NOT NULL DEFAULT -1,last_claim TEXT,updated_at INTEGER NOT NULL);

CREATE TABLE account_notifications (user_id TEXT PRIMARY KEY REFERENCES users(id),service_updates INTEGER NOT NULL DEFAULT 1 CHECK(service_updates IN (0,1)),support_replies INTEGER NOT NULL DEFAULT 1 CHECK(support_replies IN (0,1)),revision INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL);

CREATE TABLE account_settings (user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, profile_json TEXT NOT NULL, preferences_json TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>=1), updated_at TEXT NOT NULL);

CREATE TABLE account_ticket_posts (id TEXT PRIMARY KEY,ticket_id TEXT NOT NULL REFERENCES account_tickets(id),actor_id TEXT NOT NULL REFERENCES users(id),attempt_id TEXT NOT NULL,body TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(actor_id,attempt_id));

CREATE TABLE account_tickets (id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),attempt_id TEXT NOT NULL,category TEXT NOT NULL CHECK(category IN ('technical','question','suggestion','security','account_deletion')),subject TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,attempt_id));

CREATE TABLE auth_identities(provider TEXT NOT NULL CHECK(provider='google'),subject TEXT NOT NULL,user_id TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,PRIMARY KEY(provider,subject),UNIQUE(provider,user_id));

CREATE TABLE email_login_challenges(id TEXT PRIMARY KEY,email TEXT NOT NULL,proof_hash TEXT NOT NULL,browser_hash TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL CHECK(status IN ('sending','sent')));

CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id TEXT NOT NULL REFERENCES requests(id),actor_id TEXT NOT NULL REFERENCES users(id),kind TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE formation_details(request_id TEXT PRIMARY KEY REFERENCES requests(id),owner_id TEXT NOT NULL REFERENCES users(id),ciphertext TEXT NOT NULL,iv TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE formation_documents(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES requests(id),owner_id TEXT NOT NULL REFERENCES users(id),owner_index INTEGER NOT NULL,kind TEXT NOT NULL,details_revision INTEGER NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,digest TEXT NOT NULL,object_key TEXT NOT NULL UNIQUE,iv TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE formation_selections(request_id TEXT PRIMARY KEY REFERENCES requests(id),payload_hash TEXT NOT NULL,snapshot TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE google_auth_challenges(id TEXT PRIMARY KEY,nonce_hash TEXT NOT NULL,csrf_hash TEXT NOT NULL,browser_hash TEXT NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,user_id TEXT REFERENCES users(id),session_hash TEXT);

CREATE TABLE messages(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES requests(id),actor_id TEXT NOT NULL REFERENCES users(id),visibility TEXT NOT NULL CHECK(visibility IN ('client','internal')),content TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE mfa_backups(user_id TEXT NOT NULL REFERENCES users(id),version INTEGER NOT NULL,code_hash TEXT NOT NULL,used_claim TEXT,PRIMARY KEY(user_id,version,code_hash));

CREATE TABLE mfa_challenges(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),csrf_hash TEXT NOT NULL,version INTEGER NOT NULL,password_hash TEXT NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,claim TEXT);

CREATE TABLE mfa_setups(user_id TEXT PRIMARY KEY REFERENCES users(id),id TEXT NOT NULL,session_hash TEXT NOT NULL,password_hash TEXT NOT NULL,secret TEXT NOT NULL,iv TEXT NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0);

CREATE TABLE password_reset_tokens(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL);

CREATE TABLE project_events(id INTEGER PRIMARY KEY AUTOINCREMENT,workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),project_id TEXT NOT NULL REFERENCES projects(id),actor_id TEXT NOT NULL REFERENCES users(id),actor_name TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('created','updated','archived','restored','update_rejected')),result TEXT NOT NULL CHECK(result IN ('success','conflict')),created_at TEXT NOT NULL);

CREATE TABLE project_memberships(workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),user_id TEXT NOT NULL REFERENCES users(id),display_name TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('owner','admin','editor','viewer')),status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','revoked')), team_revision INTEGER NOT NULL DEFAULT 1, team_actor TEXT REFERENCES users(id), team_updated_at TEXT,PRIMARY KEY(workspace_id,user_id));

CREATE TABLE project_store_link_events(id INTEGER PRIMARY KEY AUTOINCREMENT,project_id TEXT NOT NULL REFERENCES projects(id),store_id TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES users(id),actor_name TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('linked','unlinked')),created_at TEXT NOT NULL);

CREATE TABLE project_store_links(project_id TEXT PRIMARY KEY REFERENCES projects(id),studio_owner_id TEXT NOT NULL REFERENCES users(id),store_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('linked','unlinked')),revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE project_store_profile_events(id INTEGER PRIMARY KEY AUTOINCREMENT,project_id TEXT NOT NULL REFERENCES projects(id),actor_id TEXT NOT NULL REFERENCES users(id),actor_name TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('setup_created','setup_updated')),revision INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(project_id,revision));

CREATE TABLE project_store_profiles(project_id TEXT PRIMARY KEY REFERENCES projects(id),kind TEXT NOT NULL CHECK(kind IN ('physical','digital','mixed')),language TEXT NOT NULL CHECK(language IN ('ar','en')),country TEXT NOT NULL,currency TEXT NOT NULL,time_zone TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE project_team_events(id INTEGER PRIMARY KEY AUTOINCREMENT,workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),actor_id TEXT REFERENCES users(id),target_user_id TEXT REFERENCES users(id),invite_id TEXT,kind TEXT NOT NULL,old_role TEXT,new_role TEXT,created_at TEXT NOT NULL);

CREATE TABLE project_team_invites(
 id TEXT PRIMARY KEY,workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),email TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','editor','viewer')),token_hash TEXT NOT NULL UNIQUE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','revoked')),
 revision INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,
 expires_at TEXT NOT NULL,accepted_by TEXT REFERENCES users(id),accept_op TEXT,updated_by TEXT REFERENCES users(id),updated_at TEXT NOT NULL,
 attempt_id TEXT NOT NULL,UNIQUE(created_by,attempt_id));

CREATE TABLE project_workspaces(id TEXT PRIMARY KEY,personal_owner_id TEXT NOT NULL UNIQUE REFERENCES users(id),name TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE projects(id TEXT PRIMARY KEY,workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),owner_id TEXT NOT NULL REFERENCES users(id),attempt_id TEXT NOT NULL,payload_hash TEXT NOT NULL,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',type TEXT NOT NULL,template_key TEXT NOT NULL,editor_draft_id TEXT UNIQUE REFERENCES store_drafts(id),status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')),revision INTEGER NOT NULL DEFAULT 1,last_actor TEXT NOT NULL REFERENCES users(id),last_operation TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,archived_at TEXT,FOREIGN KEY(workspace_id,owner_id) REFERENCES project_memberships(workspace_id,user_id),UNIQUE(owner_id,attempt_id));

CREATE TABLE qabs_ai_trial_days (
 day TEXT PRIMARY KEY,
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 20)
);

CREATE TABLE qabs_ai_trial_operations (
 owner_id TEXT NOT NULL REFERENCES qabs_ai_trial_wallets(owner_id) ON DELETE CASCADE,
 attempt_id TEXT NOT NULL,
 nonce TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 tool TEXT NOT NULL CHECK(tool IN ('description','seo','ads','reply')),
 status TEXT NOT NULL CHECK(status IN ('reserved','completed','failed')),
 day TEXT NOT NULL,
 error_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 PRIMARY KEY(owner_id,attempt_id)
);

CREATE TABLE qabs_ai_trial_wallets (
 owner_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 granted INTEGER NOT NULL DEFAULT 10 CHECK(granted = 10),
 remaining INTEGER NOT NULL DEFAULT 10 CHECK(remaining BETWEEN 0 AND 10),
 granted_at TEXT NOT NULL
);

CREATE TABLE qabs_content_versions (
 draft_id TEXT NOT NULL REFERENCES store_drafts(id),revision INTEGER NOT NULL CHECK(revision>0),
 owner_id TEXT NOT NULL REFERENCES users(id),config TEXT NOT NULL,saved_at TEXT NOT NULL,
 PRIMARY KEY(draft_id,revision)
);

CREATE TABLE qabs_project_versions (
 project_id TEXT NOT NULL REFERENCES projects(id), revision INTEGER NOT NULL CHECK(revision>0),
 name TEXT NOT NULL,description TEXT NOT NULL,type TEXT NOT NULL,template_key TEXT NOT NULL,status TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES users(id),saved_at TEXT NOT NULL,
 PRIMARY KEY(project_id,revision)
);

CREATE TABLE qs_events(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id TEXT NOT NULL REFERENCES qs_requests(id),actor_id TEXT NOT NULL REFERENCES users(id),kind TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);

CREATE TABLE qs_files(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES qs_requests(id),actor_id TEXT NOT NULL REFERENCES users(id),name TEXT NOT NULL,mime TEXT NOT NULL,bytes INTEGER NOT NULL,sha256 TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_messages(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES qs_requests(id),actor_id TEXT NOT NULL REFERENCES users(id),visibility TEXT NOT NULL CHECK(visibility IN ('client','internal')),kind TEXT NOT NULL CHECK(kind IN ('message','requirement')),body TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_requests(id TEXT PRIMARY KEY,formation_id TEXT UNIQUE REFERENCES requests(id),workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),owner_id TEXT NOT NULL REFERENCES users(id),service TEXT NOT NULL,title TEXT NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','under_review','needs_information','quoted','approved','in_progress','delivered','revision_requested','completed','rejected')),revision INTEGER NOT NULL DEFAULT 1,attempt_id TEXT NOT NULL,payload_hash TEXT NOT NULL,quote TEXT,quote_accepted_at TEXT,delivery TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(owner_id,attempt_id));

CREATE TABLE qs_team(workspace_id TEXT NOT NULL REFERENCES project_workspaces(id),user_id TEXT NOT NULL REFERENCES users(id),granted_by TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,PRIMARY KEY(workspace_id,user_id));

CREATE TABLE rate_limits(key TEXT PRIMARY KEY,window INTEGER NOT NULL,count INTEGER NOT NULL);

CREATE TABLE requests(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),attempt_id TEXT NOT NULL,entity TEXT NOT NULL CHECK(entity='LLC'),state TEXT NOT NULL,company_name TEXT NOT NULL,alternatives TEXT NOT NULL DEFAULT '',activity TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','under_review','needs_information','rejected')),payment_status TEXT NOT NULL DEFAULT 'not_configured' CHECK(payment_status='not_configured'),revision INTEGER NOT NULL DEFAULT 1,last_actor TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(owner_id,attempt_id));

CREATE TABLE session_assurance(session_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 0,reauth_until INTEGER NOT NULL DEFAULT 0,password_hash TEXT NOT NULL);

CREATE TABLE sessions(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires_at INTEGER NOT NULL);

CREATE TABLE store_draft_content(draft_id TEXT PRIMARY KEY REFERENCES store_drafts(id),owner_id TEXT NOT NULL REFERENCES users(id),config TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL);

CREATE TABLE store_drafts(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),attempt_id TEXT NOT NULL,template_key TEXT NOT NULL,name TEXT NOT NULL,payload_hash TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft' CHECK(status='draft'),created_at TEXT NOT NULL,UNIQUE(owner_id,attempt_id));

CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,salt TEXT NOT NULL,iterations INTEGER NOT NULL,role TEXT NOT NULL DEFAULT 'client' CHECK(role IN ('client','admin')),email_verified INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);

CREATE INDEX account_email_changes_owner ON account_email_changes(user_id,created_at);

CREATE INDEX account_ticket_posts_ticket ON account_ticket_posts(ticket_id,created_at);

CREATE INDEX account_tickets_owner ON account_tickets(user_id,updated_at);

CREATE INDEX email_login_address ON email_login_challenges(email,created_at);

CREATE INDEX email_login_expiry ON email_login_challenges(expires_at);

CREATE INDEX formation_details_owner ON formation_details(owner_id);

CREATE INDEX formation_documents_owner ON formation_documents(owner_id,request_id);

CREATE INDEX google_auth_expiry ON google_auth_challenges(expires_at);

CREATE INDEX mfa_challenges_expiry ON mfa_challenges(expires_at);

CREATE INDEX password_reset_expiry ON password_reset_tokens(expires_at);

CREATE INDEX project_events_workspace_list ON project_events(workspace_id,id DESC);

CREATE INDEX project_store_link_events_project ON project_store_link_events(project_id,id DESC);

CREATE UNIQUE INDEX project_store_link_unique_active ON project_store_links(store_id) WHERE status='linked';

CREATE INDEX project_store_profile_events_idx ON project_store_profile_events(project_id,id DESC);

CREATE INDEX projects_workspace_list ON projects(workspace_id,status,updated_at DESC,id);

CREATE INDEX qabs_ai_trial_operation_status ON qabs_ai_trial_operations(owner_id,status,created_at);

CREATE INDEX qs_events_request ON qs_events(request_id,id);

CREATE INDEX qs_files_request ON qs_files(request_id,created_at);

CREATE INDEX qs_messages_request ON qs_messages(request_id,created_at);

CREATE INDEX qs_owner ON qs_requests(owner_id,updated_at DESC);

CREATE INDEX requests_owner ON requests(owner_id,updated_at);

CREATE INDEX sessions_user ON sessions(user_id);

CREATE INDEX store_draft_content_owner ON store_draft_content(owner_id,draft_id);

CREATE INDEX store_drafts_owner ON store_drafts(owner_id,created_at);

CREATE INDEX team_event_workspace ON project_team_events(workspace_id,id DESC);

CREATE UNIQUE INDEX team_invite_one_pending ON project_team_invites(workspace_id,email) WHERE status='pending';

CREATE INDEX team_invite_workspace ON project_team_invites(workspace_id,created_at DESC,id);

CREATE TRIGGER project_content_insert_guard BEFORE INSERT ON store_draft_content WHEN EXISTS(SELECT 1 FROM projects p WHERE p.editor_draft_id=NEW.draft_id) AND NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.owner_id WHERE p.editor_draft_id=NEW.draft_id AND p.owner_id=NEW.owner_id AND p.status='active' AND m.status='active' AND m.role IN ('owner','admin','editor')) BEGIN SELECT RAISE(ABORT,'project_editor_access_changed'); END;

CREATE TRIGGER project_content_update_guard BEFORE UPDATE ON store_draft_content WHEN EXISTS(SELECT 1 FROM projects p WHERE p.editor_draft_id=NEW.draft_id) AND NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.owner_id WHERE p.editor_draft_id=NEW.draft_id AND p.owner_id=NEW.owner_id AND p.status='active' AND m.status='active' AND m.role IN ('owner','admin','editor')) BEGIN SELECT RAISE(ABORT,'project_editor_access_changed'); END;

CREATE TRIGGER project_created_event AFTER INSERT ON projects BEGIN INSERT INTO project_events(workspace_id,project_id,actor_id,actor_name,kind,result,created_at) SELECT NEW.workspace_id,NEW.id,NEW.last_actor,m.display_name,'created','success',NEW.created_at FROM project_memberships m WHERE m.workspace_id=NEW.workspace_id AND m.user_id=NEW.last_actor; END;

CREATE TRIGGER project_insert_membership BEFORE INSERT ON projects WHEN NOT EXISTS(SELECT 1 FROM project_memberships m WHERE m.workspace_id=NEW.workspace_id AND m.user_id=NEW.last_actor AND m.status='active' AND m.role IN ('owner','admin','editor')) BEGIN SELECT RAISE(ABORT,'project_membership_changed'); END;

CREATE TRIGGER project_store_link_changed AFTER UPDATE OF revision ON project_store_links WHEN NEW.revision!=OLD.revision BEGIN INSERT INTO project_store_link_events(project_id,store_id,actor_id,actor_name,kind,created_at) SELECT NEW.project_id,NEW.store_id,NEW.studio_owner_id,m.display_name,CASE WHEN NEW.status='linked' THEN 'linked' ELSE 'unlinked' END,NEW.updated_at FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.studio_owner_id WHERE p.id=NEW.project_id; END;

CREATE TRIGGER project_store_link_created AFTER INSERT ON project_store_links BEGIN INSERT INTO project_store_link_events(project_id,store_id,actor_id,actor_name,kind,created_at) SELECT NEW.project_id,NEW.store_id,NEW.studio_owner_id,m.display_name,'linked',NEW.updated_at FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.studio_owner_id WHERE p.id=NEW.project_id; END;

CREATE TRIGGER project_store_link_insert_guard BEFORE INSERT ON project_store_links WHEN NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.studio_owner_id WHERE p.id=NEW.project_id AND p.owner_id=NEW.studio_owner_id AND p.type='store' AND p.status='active' AND m.status='active' AND m.role='owner') BEGIN SELECT RAISE(ABORT,'project_store_permission_changed'); END;

CREATE TRIGGER project_store_link_update_guard BEFORE UPDATE ON project_store_links WHEN NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.studio_owner_id WHERE p.id=NEW.project_id AND p.owner_id=NEW.studio_owner_id AND p.type='store' AND (NEW.status='unlinked' OR p.status='active') AND m.status='active' AND m.role='owner') BEGIN SELECT RAISE(ABORT,'project_store_permission_changed'); END;

CREATE TRIGGER project_update_membership BEFORE UPDATE ON projects WHEN NOT EXISTS(SELECT 1 FROM project_memberships m WHERE m.workspace_id=NEW.workspace_id AND m.user_id=NEW.last_actor AND m.status='active' AND (m.role IN ('owner','admin') OR (m.role='editor' AND NEW.status=OLD.status))) BEGIN SELECT RAISE(ABORT,'project_membership_changed'); END;

CREATE TRIGGER project_updated_event AFTER UPDATE OF revision ON projects WHEN NEW.revision!=OLD.revision BEGIN INSERT INTO project_events(workspace_id,project_id,actor_id,actor_name,kind,result,created_at) SELECT NEW.workspace_id,NEW.id,NEW.last_actor,m.display_name,CASE WHEN OLD.status!=NEW.status THEN CASE WHEN NEW.status='archived' THEN 'archived' ELSE 'restored' END ELSE 'updated' END,'success',NEW.updated_at FROM project_memberships m WHERE m.workspace_id=NEW.workspace_id AND m.user_id=NEW.last_actor; END;

CREATE TRIGGER qabs_content_versions_insert AFTER INSERT ON store_draft_content BEGIN
 INSERT INTO qabs_content_versions(draft_id,revision,owner_id,config,saved_at) VALUES(NEW.draft_id,NEW.revision,NEW.owner_id,NEW.config,NEW.updated_at);
END;

CREATE TRIGGER qabs_content_versions_update AFTER UPDATE ON store_draft_content WHEN NEW.revision>OLD.revision BEGIN
 INSERT INTO qabs_content_versions(draft_id,revision,owner_id,config,saved_at) VALUES(NEW.draft_id,NEW.revision,NEW.owner_id,NEW.config,NEW.updated_at);
END;

CREATE TRIGGER qabs_project_versions_insert AFTER INSERT ON projects BEGIN
 INSERT INTO qabs_project_versions(project_id,revision,name,description,type,template_key,status,actor_id,saved_at)
 VALUES(NEW.id,NEW.revision,NEW.name,NEW.description,NEW.type,NEW.template_key,NEW.status,NEW.last_actor,NEW.updated_at);
END;

CREATE TRIGGER qabs_project_versions_update AFTER UPDATE ON projects WHEN NEW.revision>OLD.revision BEGIN
 INSERT INTO qabs_project_versions(project_id,revision,name,description,type,template_key,status,actor_id,saved_at)
 VALUES(NEW.id,NEW.revision,NEW.name,NEW.description,NEW.type,NEW.template_key,NEW.status,NEW.last_actor,NEW.updated_at);
END;

CREATE TRIGGER request_changed AFTER UPDATE ON requests BEGIN INSERT INTO events(request_id,actor_id,kind,created_at) VALUES(NEW.id,NEW.last_actor,CASE WHEN OLD.status=NEW.status THEN 'draft_updated' ELSE 'status:'||NEW.status END,NEW.updated_at);END;

CREATE TRIGGER request_created AFTER INSERT ON requests BEGIN INSERT INTO events(request_id,actor_id,kind,created_at) VALUES(NEW.id,NEW.last_actor,'draft_created',NEW.created_at);END;

CREATE TRIGGER store_profile_create_event AFTER INSERT ON project_store_profiles BEGIN INSERT INTO project_store_profile_events(project_id,actor_id,actor_name,kind,revision,created_at) SELECT NEW.project_id,NEW.updated_by,m.display_name,'setup_created',NEW.revision,NEW.updated_at FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.updated_by WHERE p.id=NEW.project_id; END;

CREATE TRIGGER store_profile_insert_permission BEFORE INSERT ON project_store_profiles WHEN NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.updated_by WHERE p.id=NEW.project_id AND p.type='store' AND p.status='active' AND m.status='active' AND m.role IN ('owner','admin','editor')) BEGIN SELECT RAISE(ABORT,'store_profile_permission_changed'); END;

CREATE TRIGGER store_profile_update_event AFTER UPDATE OF revision ON project_store_profiles WHEN NEW.revision!=OLD.revision BEGIN INSERT INTO project_store_profile_events(project_id,actor_id,actor_name,kind,revision,created_at) SELECT NEW.project_id,NEW.updated_by,m.display_name,'setup_updated',NEW.revision,NEW.updated_at FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.updated_by WHERE p.id=NEW.project_id; END;

CREATE TRIGGER store_profile_update_permission BEFORE UPDATE ON project_store_profiles WHEN NOT EXISTS(SELECT 1 FROM projects p JOIN project_memberships m ON m.workspace_id=p.workspace_id AND m.user_id=NEW.updated_by WHERE p.id=NEW.project_id AND p.type='store' AND p.status='active' AND m.status='active' AND m.role IN ('owner','admin','editor')) BEGIN SELECT RAISE(ABORT,'store_profile_permission_changed'); END;

CREATE TRIGGER team_invite_changed AFTER UPDATE OF status ON project_team_invites WHEN OLD.status!=NEW.status BEGIN
 INSERT INTO project_team_events(workspace_id,actor_id,invite_id,kind,new_role,created_at) VALUES(NEW.workspace_id,NEW.updated_by,NEW.id,'invite_'||NEW.status,NEW.role,NEW.updated_at);END;

CREATE TRIGGER team_invite_created AFTER INSERT ON project_team_invites BEGIN
 INSERT INTO project_team_events(workspace_id,actor_id,invite_id,kind,new_role,created_at) VALUES(NEW.workspace_id,NEW.created_by,NEW.id,'invite_created',NEW.role,NEW.created_at);END;

CREATE TRIGGER team_member_changed AFTER UPDATE OF role,status ON project_memberships WHEN OLD.role!=NEW.role OR OLD.status!=NEW.status BEGIN
 INSERT INTO project_team_events(workspace_id,actor_id,target_user_id,kind,old_role,new_role,created_at) VALUES(NEW.workspace_id,NEW.team_actor,NEW.user_id,CASE WHEN NEW.status='revoked' THEN 'member_revoked' WHEN OLD.status='revoked' THEN 'member_rejoined' ELSE 'role_changed' END,OLD.role,NEW.role,NEW.team_updated_at);
 DELETE FROM qs_team WHERE workspace_id=NEW.workspace_id AND user_id=NEW.user_id AND NEW.status='revoked';
 END;

CREATE TRIGGER team_member_created AFTER INSERT ON project_memberships BEGIN
 INSERT INTO project_team_events(workspace_id,actor_id,target_user_id,kind,new_role,created_at) VALUES(NEW.workspace_id,COALESCE(NEW.team_actor,NEW.user_id),NEW.user_id,'member_joined',NEW.role,COALESCE(NEW.team_updated_at,strftime('%Y-%m-%dT%H:%M:%fZ','now')));END;
