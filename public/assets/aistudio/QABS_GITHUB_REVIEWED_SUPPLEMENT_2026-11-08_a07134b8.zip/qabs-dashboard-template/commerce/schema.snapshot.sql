-- Snapshot of schema only. Apply ONLY to a new isolated empty database.
PRAGMA foreign_keys=ON;

CREATE TABLE qabs_identity_links (studio_user_id TEXT PRIMARY KEY,commerce_user_id TEXT NOT NULL UNIQUE REFERENCES qs_users(id),credential_fingerprint TEXT NOT NULL,linked_at TEXT NOT NULL);

CREATE TABLE qs_alert_deliveries(id TEXT PRIMARY KEY,event_id TEXT NOT NULL REFERENCES qs_alert_events(id),channel TEXT NOT NULL CHECK(channel IN ('email','telegram')),state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','blocked','sending','accepted','failed')),attempts INTEGER NOT NULL DEFAULT 0,next_attempt_at TEXT NOT NULL,lease_until TEXT,lease_token TEXT,first_attempt_at TEXT,provider_id TEXT,message_json TEXT,generation INTEGER NOT NULL DEFAULT 0,last_error_code TEXT,accepted_at TEXT,updated_at TEXT NOT NULL,UNIQUE(event_id,channel));

CREATE TABLE qs_alert_events(id TEXT PRIMARY KEY,dedupe_key TEXT NOT NULL UNIQUE,kind TEXT NOT NULL,resource_type TEXT NOT NULL,resource_id TEXT NOT NULL,payload_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL);

CREATE TABLE qs_audit(id TEXT PRIMARY KEY,actor_id TEXT NOT NULL REFERENCES qs_users(id),store_id TEXT,action TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_billing_requests(id TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),user_id TEXT NOT NULL REFERENCES qs_users(id),plan_id TEXT NOT NULL REFERENCES qs_plans(id),status TEXT NOT NULL DEFAULT 'pending_review',created_at TEXT NOT NULL);

CREATE TABLE qs_buyer_cart (user_id TEXT NOT NULL REFERENCES qs_users(id) ON DELETE CASCADE, product_id TEXT NOT NULL REFERENCES qs_products(id) ON DELETE CASCADE, variant_id TEXT NOT NULL DEFAULT '', quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 1000), created_at TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(user_id,product_id,variant_id));

CREATE TABLE qs_buyer_favorites (user_id TEXT NOT NULL REFERENCES qs_users(id) ON DELETE CASCADE, product_id TEXT NOT NULL REFERENCES qs_products(id) ON DELETE CASCADE, created_at TEXT NOT NULL, PRIMARY KEY(user_id,product_id));

CREATE TABLE qs_buyer_order_drafts (
 id TEXT PRIMARY KEY,
 buyer_id TEXT NOT NULL REFERENCES qs_users(id),
 store_id TEXT NOT NULL REFERENCES qs_stores(id),
 attempt_id TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 quote_fingerprint TEXT NOT NULL,
 snapshot_json TEXT NOT NULL CHECK(json_valid(snapshot_json)),
 subtotal_cents INTEGER NOT NULL CHECK(subtotal_cents BETWEEN 0 AND 100000000000),
 currency TEXT NOT NULL DEFAULT 'USD' CHECK(currency='USD'),
 state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','cancelled')),
 created_at TEXT NOT NULL,
 expires_at INTEGER NOT NULL,
 cancelled_at TEXT,
 UNIQUE(buyer_id,attempt_id)
);

CREATE TABLE qs_cart_activity(id TEXT PRIMARY KEY,group_id TEXT NOT NULL,line_id TEXT,actor_id TEXT,kind TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_cart_documents(id TEXT PRIMARY KEY,group_id TEXT NOT NULL,line_id TEXT NOT NULL,owner_id TEXT NOT NULL,actor_id TEXT NOT NULL,attempt_id TEXT NOT NULL,object_key TEXT NOT NULL UNIQUE,purpose TEXT NOT NULL CHECK(purpose IN ('intake','delivery')),mime TEXT NOT NULL,bytes INTEGER NOT NULL,sha256 TEXT NOT NULL,state TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,expires_at TEXT NOT NULL,UNIQUE(actor_id,attempt_id));

CREATE TABLE qs_cart_groups(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES qs_users(id),attempt_id TEXT NOT NULL,snapshot TEXT NOT NULL,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),currency TEXT NOT NULL CHECK(currency='USD'),state TEXT NOT NULL DEFAULT 'pending',reason TEXT,bridge_hash TEXT NOT NULL,order_gid TEXT UNIQUE,candidate_gid TEXT,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,verified_at TEXT,updated_at TEXT NOT NULL,UNIQUE(owner_id,attempt_id));

CREATE TABLE qs_cart_lines(id TEXT PRIMARY KEY,group_id TEXT NOT NULL REFERENCES qs_cart_groups(id),handle TEXT NOT NULL,title TEXT NOT NULL,portal TEXT NOT NULL,variant_id TEXT NOT NULL,variant_title TEXT NOT NULL,cents INTEGER NOT NULL,revision INTEGER NOT NULL DEFAULT 0,intake_cipher TEXT,intake_state TEXT NOT NULL DEFAULT 'empty',fulfillment_state TEXT NOT NULL DEFAULT 'awaiting_data',updated_at TEXT NOT NULL,UNIQUE(group_id,handle));

CREATE TABLE qs_catalog_approvals (
 id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE REFERENCES qs_service_requests(id), owner_id TEXT NOT NULL REFERENCES qs_users(id),
 product_handle TEXT NOT NULL, variant_gid TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents>0), currency TEXT NOT NULL CHECK(currency='USD'),
 scope TEXT NOT NULL, terms TEXT NOT NULL, delivery_days INTEGER NOT NULL CHECK(delivery_days BETWEEN 1 AND 365),
 approved_by TEXT NOT NULL REFERENCES qs_users(id), approved_at TEXT NOT NULL, accepted_at TEXT, expires_at TEXT NOT NULL
);

CREATE TABLE qs_catalog_categories (id TEXT PRIMARY KEY, slug TEXT NOT NULL UNIQUE CHECK(length(slug) BETWEEN 3 AND 40), name TEXT NOT NULL CHECK(length(name) BETWEEN 1 AND 100), description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')), created_at TEXT NOT NULL, updated_at TEXT NOT NULL);

CREATE TABLE qs_checkout_intents (
 id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE REFERENCES qs_service_requests(id), owner_id TEXT NOT NULL REFERENCES qs_users(id), attempt_id TEXT NOT NULL,
 product_handle TEXT NOT NULL, variant_gid TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents>0), currency TEXT NOT NULL CHECK(currency='USD'),
 candidate_order_gid TEXT, order_gid TEXT UNIQUE, state TEXT NOT NULL CHECK(state IN ('pending','paid','partially_refunded','refunded','cancelled','requires_attention')),
 reason TEXT, revision INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, updated_at TEXT NOT NULL, verified_at TEXT,
 UNIQUE(owner_id,attempt_id)
);

CREATE TABLE qs_checkout_transitions (
 intent_id TEXT NOT NULL REFERENCES qs_checkout_intents(id), revision INTEGER NOT NULL, state TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(intent_id,revision)
);

CREATE TABLE qs_domain_details (  hostname TEXT PRIMARY KEY REFERENCES qs_domains(hostname) ON DELETE CASCADE,  dns_provider TEXT NOT NULL DEFAULT 'other' CHECK(dns_provider IN ('cloudflare','godaddy','namecheap','hostinger','other')),  ownership_verified INTEGER NOT NULL DEFAULT 0 CHECK(ownership_verified IN (0,1)),  checked_at TEXT,  check_error TEXT );

CREATE TABLE qs_domains(hostname TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),status TEXT NOT NULL DEFAULT 'pending_configuration' CHECK(status IN ('pending_configuration','pending_verification','active','failed')),proof TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_feature_requests(id TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),kind TEXT NOT NULL CHECK(kind IN ('gateway_own','gateway_assisted','custom_domain','partnership')),state TEXT NOT NULL DEFAULT 'pending_review',created_at TEXT NOT NULL);

CREATE TABLE qs_images(key TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),bytes INTEGER NOT NULL CHECK(bytes>0),created_at TEXT NOT NULL);

CREATE TABLE qs_inquiries(id TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),buyer_id TEXT NOT NULL REFERENCES qs_users(id),product_id TEXT NOT NULL REFERENCES qs_products(id),quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 1000),quoted_cents INTEGER NOT NULL CHECK(quoted_cents>=0),status TEXT NOT NULL DEFAULT 'received' CHECK(status IN ('received','reviewing','awaiting_customer','completed','cancelled')),message TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE qs_inquiry_variants(inquiry_id TEXT PRIMARY KEY REFERENCES qs_inquiries(id),variant_id TEXT NOT NULL,variant_title TEXT NOT NULL,sku TEXT NOT NULL);

CREATE TABLE qs_integration_requests(id TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),provider TEXT NOT NULL,category TEXT NOT NULL CHECK(category IN ('payment','shipping','supplier','operations')),country TEXT NOT NULL,currency TEXT NOT NULL,has_account INTEGER NOT NULL CHECK(has_account IN (0,1)),status TEXT NOT NULL DEFAULT 'pending_review' CHECK(status IN ('pending_review','reviewing','needs_account','unavailable','cancelled')),created_at TEXT NOT NULL);

CREATE TABLE qs_limits(key TEXT PRIMARY KEY,window INTEGER NOT NULL,count INTEGER NOT NULL);

CREATE TABLE qs_magic_tokens(hash TEXT PRIMARY KEY,email TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER);

CREATE TABLE qs_notifications(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES qs_users(id),store_id TEXT REFERENCES qs_stores(id),type TEXT NOT NULL,resource_id TEXT NOT NULL,title TEXT NOT NULL,message TEXT NOT NULL,read_at TEXT,created_at TEXT NOT NULL);

CREATE TABLE qs_ops_backups(id TEXT PRIMARY KEY,object_key TEXT NOT NULL UNIQUE,state TEXT NOT NULL CHECK(state IN ('creating','verified','failed')),bytes INTEGER,checksum TEXT,created_at TEXT NOT NULL,verified_at TEXT,error_code TEXT);

CREATE TABLE qs_ops_errors(hour TEXT NOT NULL,code INTEGER NOT NULL CHECK(code BETWEEN 500 AND 599),count INTEGER NOT NULL CHECK(count>0),PRIMARY KEY(hour,code));

CREATE TABLE qs_ops_health(id INTEGER PRIMARY KEY CHECK(id=1),checked_at TEXT NOT NULL,summary_json TEXT NOT NULL);

CREATE TABLE qs_password_credentials(user_id TEXT PRIMARY KEY REFERENCES qs_users(id),salt TEXT NOT NULL,hash TEXT NOT NULL,iterations INTEGER NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE qs_plans(id TEXT PRIMARY KEY,title TEXT NOT NULL,product_limit INTEGER NOT NULL CHECK(product_limit BETWEEN 1 AND 5000),price_cents INTEGER CHECK(price_cents>0),cycle TEXT NOT NULL DEFAULT 'month' CHECK(cycle IN ('month','year')),status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','approved')));

CREATE TABLE qs_platform_billing_config(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN(0,1)),version TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE qs_platform_billing_holds(store_id TEXT PRIMARY KEY REFERENCES qs_stores(id),intent_id TEXT NOT NULL REFERENCES qs_platform_billing_intents(id),reason TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_platform_billing_intents(
 id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES qs_users(id),store_id TEXT NOT NULL REFERENCES qs_stores(id),attempt_id TEXT NOT NULL,
 plan_id TEXT NOT NULL CHECK(plan_id IN('basic','growth')),amount_cents INTEGER NOT NULL CHECK(amount_cents IN(1900,3900)),currency TEXT NOT NULL DEFAULT 'USD' CHECK(currency='USD'),days INTEGER NOT NULL DEFAULT 30 CHECK(days=30),
 state TEXT NOT NULL CHECK(state IN('creating','ready','needs_review','requires_attention','paid','partially_refunded','refunded','cancelled')),reason TEXT,
 draft_gid TEXT UNIQUE,order_gid TEXT UNIQUE,invoice_url TEXT,reconcile_version INTEGER NOT NULL DEFAULT 0,
 applied_at TEXT,granted_start INTEGER,granted_end INTEGER,actual_total_cents INTEGER,tax_cents INTEGER,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,verified_at TEXT,UNIQUE(owner_id,attempt_id),CHECK((plan_id='basic' AND amount_cents=1900)OR(plan_id='growth' AND amount_cents=3900))
);

CREATE TABLE qs_platform_billing_log(id TEXT PRIMARY KEY,intent_id TEXT NOT NULL REFERENCES qs_platform_billing_intents(id),event TEXT NOT NULL,created_at TEXT NOT NULL);

CREATE TABLE qs_product_categories (product_id TEXT PRIMARY KEY REFERENCES qs_products(id) ON DELETE CASCADE, category_id TEXT NOT NULL REFERENCES qs_catalog_categories(id), updated_at TEXT NOT NULL);

CREATE TABLE qs_product_details(product_id TEXT PRIMARY KEY REFERENCES qs_products(id),store_id TEXT NOT NULL REFERENCES qs_stores(id),sku TEXT NOT NULL DEFAULT '',weight_grams INTEGER NOT NULL DEFAULT 0,length_mm INTEGER NOT NULL DEFAULT 0,width_mm INTEGER NOT NULL DEFAULT 0,height_mm INTEGER NOT NULL DEFAULT 0,gallery_json TEXT NOT NULL DEFAULT '[]',variants_json TEXT NOT NULL DEFAULT '[]',seo_title TEXT NOT NULL DEFAULT '',seo_description TEXT NOT NULL DEFAULT '',supplier_cost_cents INTEGER,updated_at TEXT NOT NULL);

CREATE TABLE qs_products(id TEXT PRIMARY KEY,store_id TEXT NOT NULL REFERENCES qs_stores(id),title TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',price_cents INTEGER NOT NULL CHECK(price_cents BETWEEN 0 AND 100000000),currency TEXT NOT NULL DEFAULT 'USD' CHECK(currency='USD'),stock INTEGER NOT NULL DEFAULT 0 CHECK(stock BETWEEN 0 AND 1000000),image_key TEXT,status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','archived')),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);

CREATE TABLE qs_service_events (
 id TEXT PRIMARY KEY,
 request_id TEXT NOT NULL REFERENCES qs_service_requests(id),
 kind TEXT NOT NULL CHECK(kind IN ('draft_created','review_requested')),
 created_at TEXT NOT NULL
);

CREATE TABLE qs_service_reference_access(id TEXT PRIMARY KEY,reference_id TEXT NOT NULL REFERENCES qs_service_references(id),actor_id TEXT NOT NULL REFERENCES qs_users(id),action TEXT NOT NULL CHECK(action IN ('download','delete')),created_at TEXT NOT NULL);

CREATE TABLE qs_service_reference_activity(id TEXT PRIMARY KEY,reference_id TEXT NOT NULL REFERENCES qs_service_references(id),request_id TEXT NOT NULL REFERENCES qs_service_requests(id),kind TEXT NOT NULL CHECK(kind IN ('added','deleted')),created_at TEXT NOT NULL);

CREATE TABLE qs_service_references(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES qs_service_requests(id),owner_id TEXT NOT NULL REFERENCES qs_users(id),attempt_id TEXT NOT NULL,object_key TEXT NOT NULL UNIQUE,filename TEXT NOT NULL,mime TEXT NOT NULL,bytes INTEGER NOT NULL CHECK(bytes BETWEEN 1 AND 3145728),sha256 TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('uploading','ready','deleting','deleted','failed')),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(owner_id,attempt_id));

CREATE TABLE qs_service_requests (
 id TEXT PRIMARY KEY,
 owner_id TEXT NOT NULL REFERENCES qs_users(id),
 portal_slug TEXT NOT NULL,
 selection_json TEXT NOT NULL,
 attempt_id TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','under_review')),
 payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK(payment_status='unpaid'),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(owner_id,attempt_id)
);

CREATE TABLE qs_session_security(hash TEXT PRIMARY KEY REFERENCES qs_sessions(hash) ON DELETE CASCADE,auth_method TEXT NOT NULL,email_verified_at INTEGER);

CREATE TABLE qs_sessions(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES qs_users(id),csrf TEXT NOT NULL,expires_at INTEGER NOT NULL);

CREATE TABLE qs_shopify_events (
 shop TEXT NOT NULL, event_id TEXT NOT NULL, topic TEXT NOT NULL, payload_hash TEXT NOT NULL,
 resource_gid TEXT, state TEXT NOT NULL CHECK(state IN ('pending','processed')), created_at TEXT NOT NULL, processed_at TEXT,
 PRIMARY KEY(shop,event_id)
);

CREATE TABLE qs_shopify_integration (
 id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN(0,1)),
 configured_by TEXT REFERENCES qs_users(id), configured_at TEXT
);

CREATE TABLE qs_shopify_invoices (
 id TEXT PRIMARY KEY, quote_id TEXT NOT NULL UNIQUE REFERENCES qs_shopify_quotes(id),
 owner_id TEXT NOT NULL REFERENCES qs_users(id), draft_gid TEXT UNIQUE, order_gid TEXT UNIQUE, invoice_url TEXT,
 state TEXT NOT NULL CHECK(state IN ('creating','ready','needs_review','paid','partially_refunded','refunded','cancelled','requires_attention')),
 reconcile_version INTEGER NOT NULL DEFAULT 0, reason TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, verified_at TEXT
);

CREATE TABLE qs_shopify_quotes (
 id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE REFERENCES qs_service_requests(id),
 owner_id TEXT NOT NULL REFERENCES qs_users(id), product_key TEXT NOT NULL CHECK(product_key IN ('basic','complete')),
 variant_gid TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents>0), currency TEXT NOT NULL CHECK(currency='USD'),
 scope TEXT NOT NULL, delivery_days INTEGER NOT NULL CHECK(delivery_days BETWEEN 1 AND 365), terms TEXT NOT NULL,
 approved_by TEXT NOT NULL REFERENCES qs_users(id), approved_at TEXT NOT NULL, accepted_at TEXT, expires_at TEXT NOT NULL
);

CREATE TABLE qs_sku_registry(store_id TEXT NOT NULL REFERENCES qs_stores(id),sku TEXT NOT NULL COLLATE NOCASE,product_id TEXT NOT NULL REFERENCES qs_products(id),PRIMARY KEY(store_id,sku));

CREATE TABLE qs_store_onboarding(store_id TEXT PRIMARY KEY REFERENCES qs_stores(id),logo_key TEXT,preview_confirmed_at TEXT,review_requested_at TEXT,updated_at TEXT NOT NULL);

CREATE TABLE qs_store_package_preferences (
 request_id TEXT PRIMARY KEY REFERENCES qs_service_requests(id),
 product_key TEXT NOT NULL CHECK(product_key IN ('basic','complete')),
 revision INTEGER NOT NULL CHECK(revision>0), created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE qs_store_service_briefs(request_id TEXT PRIMARY KEY REFERENCES qs_service_requests(id),brief_json TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>0),updated_at TEXT NOT NULL);

CREATE TABLE qs_store_settings(store_id TEXT PRIMARY KEY REFERENCES qs_stores(id),support_email TEXT NOT NULL DEFAULT '',shipping_policy TEXT NOT NULL DEFAULT '',returns_policy TEXT NOT NULL DEFAULT '',privacy_policy TEXT NOT NULL DEFAULT '',terms_policy TEXT NOT NULL DEFAULT '',shipping_country_codes TEXT NOT NULL DEFAULT '[]',shipping_fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(shipping_fee_cents BETWEEN 0 AND 100000000),updated_at TEXT NOT NULL);

CREATE TABLE qs_stores(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES qs_users(id),slug TEXT NOT NULL UNIQUE,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',template TEXT NOT NULL DEFAULT 'classic' CHECK(template IN ('classic','boutique','minimal')),color TEXT NOT NULL DEFAULT '#075b65',plan_id TEXT NOT NULL REFERENCES qs_plans(id),status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','suspended')),subscription_state TEXT NOT NULL DEFAULT 'not_configured' CHECK(subscription_state IN ('not_configured','pending_review','active','expired')),paid_reference TEXT,expires_at INTEGER,requested_features TEXT NOT NULL DEFAULT '[]',payment_mode TEXT NOT NULL DEFAULT 'none',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,CHECK(subscription_state!='active' OR (paid_reference IS NOT NULL AND expires_at IS NOT NULL)));

CREATE TABLE qs_tickets(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES qs_users(id),subject TEXT NOT NULL,message TEXT NOT NULL,reply TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewing','closed')),created_at TEXT NOT NULL);

CREATE TABLE qs_users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL);

CREATE TABLE qs_workspace_sessions (commerce_session_hash TEXT PRIMARY KEY REFERENCES qs_sessions(hash) ON DELETE CASCADE,studio_session_hash TEXT NOT NULL,studio_user_id TEXT NOT NULL REFERENCES qabs_identity_links(studio_user_id) ON DELETE CASCADE,created_at TEXT NOT NULL);

CREATE INDEX qs_alert_due ON qs_alert_deliveries(state,next_attempt_at);

CREATE INDEX qs_buyer_order_drafts_buyer_idx ON qs_buyer_order_drafts(buyer_id,created_at DESC,id);

CREATE INDEX qs_buyer_order_drafts_store_idx ON qs_buyer_order_drafts(store_id,created_at DESC,id);

CREATE INDEX qs_cart_documents_line ON qs_cart_documents(line_id,state);

CREATE INDEX qs_cart_groups_owner ON qs_cart_groups(owner_id,created_at);

CREATE INDEX qs_checkout_intents_owner ON qs_checkout_intents(owner_id,created_at);

CREATE INDEX qs_images_store ON qs_images(store_id);

CREATE INDEX qs_inquiries_buyer ON qs_inquiries(buyer_id,created_at);

CREATE INDEX qs_inquiries_owner ON qs_inquiries(store_id,created_at);

CREATE INDEX qs_integration_requests_store ON qs_integration_requests(store_id,created_at);

CREATE INDEX qs_notifications_owner ON qs_notifications(user_id,created_at);

CREATE UNIQUE INDEX qs_notifications_unread_resource ON qs_notifications(user_id,type,resource_id) WHERE read_at IS NULL;

CREATE UNIQUE INDEX qs_ops_single_backup ON qs_ops_backups(state) WHERE state='creating';

CREATE INDEX qs_platform_billing_owner ON qs_platform_billing_intents(owner_id,created_at);

CREATE UNIQUE INDEX qs_platform_one_pending_store ON qs_platform_billing_intents(store_id) WHERE applied_at IS NULL AND state IN('creating','ready','needs_review','requires_attention');

CREATE INDEX qs_product_categories_category_idx ON qs_product_categories(category_id);

CREATE INDEX qs_product_details_store ON qs_product_details(store_id);

CREATE INDEX qs_products_store ON qs_products(store_id,status);

CREATE INDEX qs_service_events_request ON qs_service_events(request_id,created_at);

CREATE INDEX qs_service_references_request ON qs_service_references(request_id,state,created_at);

CREATE INDEX qs_service_requests_owner ON qs_service_requests(owner_id,portal_slug,created_at);

CREATE INDEX qs_shopify_invoices_owner ON qs_shopify_invoices(owner_id,created_at);

CREATE INDEX qs_stores_owner ON qs_stores(owner_id);

CREATE INDEX qs_workspace_sessions_owner ON qs_workspace_sessions(studio_user_id);

CREATE TRIGGER qs_alert_account_created_v38 AFTER INSERT ON qs_users BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'account-created:'||NEW.id,'account.created','account',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_audit_v38 AFTER INSERT ON qs_audit BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'audit:'||NEW.id,'operation.recorded','audit',NEW.id,json_object('action',substr(NEW.action,1,80)),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_backup_state_v38 AFTER UPDATE ON qs_ops_backups WHEN NEW.state!=OLD.state AND NEW.state IN ('failed','verified') BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'backup:'||NEW.id||':'||NEW.state,'backup.changed','operation',NEW.id,json_object('state',NEW.state),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_brief_insert_v38 AFTER INSERT ON qs_store_service_briefs WHEN NEW.revision>0 BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'brief:'||NEW.request_id||':'||NEW.revision,'data.saved','service',NEW.request_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_brief_update_v38 AFTER UPDATE ON qs_store_service_briefs WHEN NEW.revision>0 AND NEW.revision!=OLD.revision BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'brief:'||NEW.request_id||':'||NEW.revision,'data.saved','service',NEW.request_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_cart_created_v38 AFTER INSERT ON qs_cart_groups BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'cart-created:'||NEW.id,'cart.created','cart',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_cart_intake_v38 AFTER UPDATE ON qs_cart_lines WHEN NEW.revision!=OLD.revision AND NEW.revision>0 BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'intake:'||NEW.id||':'||NEW.revision,'data.saved','cart',NEW.group_id,json_object('handle',NEW.handle,'submitted',NEW.intake_state='submitted'),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_cart_paid_v38 AFTER UPDATE ON qs_cart_groups WHEN NEW.state='paid' AND OLD.state!='paid' AND NEW.order_gid IS NOT NULL BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'payment:'||NEW.order_gid,'payment.verified','cart',NEW.id,json_object('amountCents',NEW.amount_cents,'currency',NEW.currency,'handles',(SELECT json_group_array(json_extract(value,'$.handle')) FROM json_each(NEW.snapshot))),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_fanout_v38 AFTER INSERT ON qs_alert_events BEGIN
INSERT INTO qs_alert_deliveries(id,event_id,channel,next_attempt_at,updated_at) VALUES(lower(hex(randomblob(16))),NEW.id,'email',NEW.created_at,NEW.created_at);
INSERT INTO qs_alert_deliveries(id,event_id,channel,next_attempt_at,updated_at) VALUES(lower(hex(randomblob(16))),NEW.id,'telegram',NEW.created_at,NEW.created_at);
END;

CREATE TRIGGER qs_alert_fulfillment_v38 AFTER UPDATE ON qs_cart_lines WHEN NEW.fulfillment_state!=OLD.fulfillment_state BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'fulfillment:'||lower(hex(randomblob(16))),'fulfillment.changed','cart',NEW.group_id,json_object('handle',NEW.handle,'state',NEW.fulfillment_state),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_inquiry_v38 AFTER INSERT ON qs_inquiries BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'inquiry:'||NEW.id,'inquiry.created','inquiry',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_invoice_paid_v38 AFTER UPDATE ON qs_shopify_invoices WHEN NEW.state='paid' AND OLD.state!='paid' AND NEW.order_gid IS NOT NULL BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'payment:'||NEW.order_gid,'payment.verified','invoice',NEW.id,json_object('invoice',1,'amountCents',(SELECT amount_cents FROM qs_shopify_quotes WHERE id=NEW.quote_id),'currency','USD','handles',json_array((SELECT CASE product_key WHEN 'basic' THEN 'shopify-store-basic' ELSE 'shopify-store-complete' END FROM qs_shopify_quotes WHERE id=NEW.quote_id))),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_login_v38 AFTER INSERT ON qs_sessions BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'login:'||lower(hex(randomblob(16))),'account.login','account',NEW.user_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_password_insert_v38 AFTER INSERT ON qs_password_credentials BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'security:'||lower(hex(randomblob(16))),'account.security','account',NEW.user_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_password_update_v38 AFTER UPDATE ON qs_password_credentials BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'security:'||lower(hex(randomblob(16))),'account.security','account',NEW.user_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_product_created_v38 AFTER INSERT ON qs_products BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'product-created:'||NEW.id,'product.created','product',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_provider_event_v38 AFTER INSERT ON qs_shopify_events BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'provider-event:'||NEW.event_id,'payment.provider_event','shopify',NEW.resource_gid,json_object('topic',NEW.topic),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_qs_cart_groups_financial_v38 AFTER UPDATE ON qs_cart_groups WHEN NEW.state!=OLD.state AND NEW.state IN ('refunded','partially_refunded','cancelled','requires_attention') BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'financial:'||lower(hex(randomblob(16))),'payment.changed','cart',NEW.id,json_object('state',NEW.state),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_qs_checkout_intents_financial_v38 AFTER UPDATE ON qs_checkout_intents WHEN NEW.state!=OLD.state AND NEW.state IN ('refunded','partially_refunded','cancelled','requires_attention') BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'financial:'||lower(hex(randomblob(16))),'payment.changed','service',NEW.request_id,json_object('state',NEW.state),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_qs_shopify_invoices_financial_v38 AFTER UPDATE ON qs_shopify_invoices WHEN NEW.state!=OLD.state AND NEW.state IN ('refunded','partially_refunded','cancelled','requires_attention') BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'financial:'||lower(hex(randomblob(16))),'payment.changed','invoice',NEW.id,json_object('state',NEW.state),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_reference_ready_v38 AFTER UPDATE ON qs_service_references WHEN NEW.state='ready' AND OLD.state!='ready' BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'reference-ready:'||NEW.id,'document.reference','service',NEW.request_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_service_created_v38 AFTER INSERT ON qs_service_requests BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'service-created:'||NEW.id,'request.created','service',NEW.id,json_object('portal',NEW.portal_slug),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_service_review_v38 AFTER UPDATE ON qs_service_requests WHEN NEW.status='under_review' AND OLD.status!='under_review' BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'service-review:'||NEW.id,'request.review','service',NEW.id,json_object('portal',NEW.portal_slug),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_single_paid_v38 AFTER UPDATE ON qs_checkout_intents WHEN NEW.state='paid' AND OLD.state!='paid' AND NEW.order_gid IS NOT NULL BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'payment:'||NEW.order_gid,'payment.verified','service',NEW.request_id,json_object('amountCents',NEW.amount_cents,'currency',NEW.currency,'handles',json_array(NEW.product_handle)),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_store_created_v38 AFTER INSERT ON qs_stores BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'store-created:'||NEW.id,'store.created','store',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_ticket_created_v38 AFTER INSERT ON qs_tickets BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'ticket-created:'||NEW.id,'support.created','support',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_ticket_updated_v38 AFTER UPDATE ON qs_tickets WHEN NEW.reply!=OLD.reply OR NEW.status!=OLD.status BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'ticket-updated:'||lower(hex(randomblob(16))),'support.updated','support',NEW.id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_unlinked_payment_v38 AFTER UPDATE ON qs_shopify_events WHEN NEW.state='processed' AND OLD.state!='processed' AND NEW.topic='orders/paid' AND NOT EXISTS(SELECT 1 FROM qs_cart_groups WHERE order_gid=NEW.resource_gid) AND NOT EXISTS(SELECT 1 FROM qs_checkout_intents WHERE order_gid=NEW.resource_gid) AND NOT EXISTS(SELECT 1 FROM qs_shopify_invoices WHERE order_gid=NEW.resource_gid) BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'unlinked-payment-event:'||NEW.resource_gid,'payment.unlinked_event','shopify',NEW.resource_gid,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_vault_deleted_v38 AFTER UPDATE ON qs_cart_documents WHEN NEW.state='deleted' AND OLD.state!='deleted' BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'document-deleted:'||NEW.id,'document.deleted','cart',NEW.group_id,'{}',strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;

CREATE TRIGGER qs_alert_vault_ready_v38 AFTER UPDATE ON qs_cart_documents WHEN NEW.state='ready' AND OLD.state!='ready' BEGIN INSERT OR IGNORE INTO qs_alert_events(id,dedupe_key,kind,resource_type,resource_id,payload_json,created_at) VALUES(lower(hex(randomblob(16))),'document-ready:'||NEW.id,'document.uploaded','cart',NEW.group_id,json_object('purpose',NEW.purpose),strftime('%Y-%m-%dT%H:%M:%fZ','now')); END;
