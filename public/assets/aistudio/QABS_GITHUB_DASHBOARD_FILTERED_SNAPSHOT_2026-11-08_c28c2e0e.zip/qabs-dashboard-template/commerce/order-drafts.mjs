const ID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const HASH=/^[a-f0-9]{64}$/;
const fail=(code,status=400)=>{throw Object.assign(Error(code),{status})};
const uuid=x=>{if(typeof x!=='string'||!ID.test(x))fail('invalid_id');return x};
const fields=(b,keys)=>{if(!b||typeof b!=='object'||Array.isArray(b)||Object.keys(b).some(k=>!keys.includes(k))||keys.some(k=>!Object.hasOwn(b,k)))fail('invalid_fields');return b};
const hash=async x=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x))),x=>x.toString(16).padStart(2,'0')).join('');
const stamp=()=>new Date().toISOString();const seconds=()=>Math.floor(Date.now()/1000);
const array=async q=>(await q.all()).results||[];
const flags=Object.freeze({payment_state:'not_started',fulfillment_state:'not_started',stock_reserved:false,checkout_ready:false,total_cents:null,tax_cents:null,shipping_cents:null});
function draftView(r){const snap=JSON.parse(r.snapshot_json);return {id:r.id,store_id:r.store_id,state:r.state,created_at:r.created_at,expires_at:r.expires_at,expired:r.expires_at<=seconds(),cancelled_at:r.cancelled_at,quote_fingerprint:r.quote_fingerprint,subtotal_cents:r.subtotal_cents,currency:r.currency,lines:snap.lines,store_name:snap.store_name,...flags,requires_revalidation:true};}
export async function buildBuyerQuote(env,buyerId,storeId){
 uuid(storeId);
 const store=await env.DB.prepare("SELECT id,name FROM qs_stores WHERE id=? AND status='active' AND subscription_state='active' AND expires_at>?").bind(storeId,seconds()).first();
 if(!store)fail('store_unavailable',404);
 const raw=await array(env.DB.prepare('SELECT c.product_id,c.variant_id,c.quantity,p.title,p.price_cents,p.stock,p.status,p.currency,d.variants_json FROM qs_buyer_cart c JOIN qs_products p ON p.id=c.product_id LEFT JOIN qs_product_details d ON d.product_id=p.id WHERE c.user_id=? AND p.store_id=? ORDER BY c.product_id,c.variant_id LIMIT 101').bind(buyerId,storeId));
 if(!raw.length)fail('cart_empty',409);if(raw.length>100)fail('cart_limit_reached',409);
 let subtotal=0;const lines=raw.map(p=>{
  if(p.status!=='published'||p.currency!=='USD')fail('product_unavailable',409);
  let variants;try{variants=JSON.parse(p.variants_json||'[]')}catch{fail('catalog_unavailable',503)}
  if(!Array.isArray(variants))fail('catalog_unavailable',503);
  const variant=variants.find(v=>v.id===p.variant_id);
  if((variants.length&&!variant)||(!variants.length&&p.variant_id))fail('variant_unavailable',409);
  const price=variant?variant.price_cents:p.price_cents,stock=variant?variant.stock:p.stock;
  if(!Number.isSafeInteger(price)||price<0||price>100000000||!Number.isSafeInteger(stock)||stock<0)fail('catalog_unavailable',503);
  if(!Number.isSafeInteger(p.quantity)||p.quantity<1||p.quantity>1000)fail('invalid_quantity',409);
  if(stock<p.quantity)fail('stock_changed',409);
  const total=price*p.quantity;subtotal+=total;if(!Number.isSafeInteger(subtotal)||subtotal>100000000000)fail('cart_total_limit',409);
  return{product_id:p.product_id,variant_id:p.variant_id,quantity:p.quantity,title:p.title,variant_title:variant?.title||null,unit_price_cents:price,line_total_cents:total};
 });
 const authoritative={store_id:storeId,store_name:store.name,currency:'USD',lines,subtotal_cents:subtotal};
 return {...authoritative,quote_fingerprint:await hash(JSON.stringify(authoritative)),...flags,requires_revalidation:true};
}
export async function orderDraftRoute(req,env,u,{json,body,limit,owned}){
 const url=new URL(req.url),path=url.pathname;
 const mine='/api/buyer/order-drafts',quote='/api/buyer/cart/quote';
 const item=path.match(/^\/api\/buyer\/order-drafts\/([^/]+)(?:\/(cancel))?$/);
 const merchant=path.match(/^\/api\/stores\/([^/]+)\/order-drafts(?:\/([^/]+))?$/);
 if(path!==mine&&path!==quote&&!item&&!merchant)return null;
 if(merchant){const sid=uuid(merchant[1]);await owned(env,u,sid);if(req.method!=='GET')return json({error:'method_not_allowed'},405);if(merchant[2]){const r=await env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE id=? AND store_id=?').bind(uuid(merchant[2]),sid).first();if(!r)fail('draft_not_found',404);return json({draft:draftView(r)})}return listDrafts(env,json,url,'store_id',sid);}
 if(path===quote){if(req.method!=='POST')return json({error:'method_not_allowed'},405);await limit(env,'buyer-quote:'+u.user_id,200);const b=fields(await body(req),['store_id']);return json({quote:await buildBuyerQuote(env,u.user_id,b.store_id)})}
 if(item){const id=uuid(item[1]);let r=await env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE id=? AND buyer_id=?').bind(id,u.user_id).first();if(!r)fail('draft_not_found',404);
  if(item[2]){if(req.method!=='POST')return json({error:'method_not_allowed'},405);fields(await body(req),[]);await limit(env,'buyer-draft-cancel:'+u.user_id,100);await env.DB.prepare("UPDATE qs_buyer_order_drafts SET state='cancelled',cancelled_at=? WHERE id=? AND buyer_id=? AND state='draft'").bind(stamp(),id,u.user_id).run();r=await env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE id=? AND buyer_id=?').bind(id,u.user_id).first();return json({draft:draftView(r),funds_moved:false})}
  if(req.method!=='GET')return json({error:'method_not_allowed'},405);return json({draft:draftView(r)});
 }
 if(req.method==='GET')return listDrafts(env,json,url,'buyer_id',u.user_id);
 if(req.method!=='POST')return json({error:'method_not_allowed'},405);
 const b=fields(await body(req),['store_id','attempt_id','quote_fingerprint']);uuid(b.store_id);uuid(b.attempt_id);if(typeof b.quote_fingerprint!=='string'||!HASH.test(b.quote_fingerprint))fail('invalid_quote_fingerprint');
 await limit(env,'buyer-draft:'+u.user_id,60);
 const requestHash=await hash(JSON.stringify({store_id:b.store_id,quote_fingerprint:b.quote_fingerprint}));
 const replay=async()=>{const r=await env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE buyer_id=? AND attempt_id=?').bind(u.user_id,b.attempt_id).first();if(!r)return null;if(r.request_hash!==requestHash)fail('attempt_conflict',409);return r};
 const old=await replay();if(old)return json({draft:draftView(old),replayed:true},200);
 const q=await buildBuyerQuote(env,u.user_id,b.store_id);if(q.quote_fingerprint!==b.quote_fingerprint)fail('quote_changed',409);
 const id=crypto.randomUUID(),at=stamp();
 const inserted=await env.DB.prepare("INSERT INTO qs_buyer_order_drafts(id,buyer_id,store_id,attempt_id,request_hash,quote_fingerprint,snapshot_json,subtotal_cents,currency,state,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,'draft',?,?) ON CONFLICT(buyer_id,attempt_id) DO NOTHING RETURNING id").bind(id,u.user_id,b.store_id,b.attempt_id,requestHash,q.quote_fingerprint,JSON.stringify({lines:q.lines,store_name:q.store_name}),q.subtotal_cents,'USD',at,seconds()+86400).first();
 const row=inserted?await env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE id=? AND buyer_id=?').bind(id,u.user_id).first():await replay();if(!row)fail('draft_save_failed',503);
 return json({draft:draftView(row),replayed:!inserted},inserted?201:200);
}
async function listDrafts(env,json,url,column,value){const raw=url.searchParams.get('offset')||'0';if(!/^\d{1,5}$/.test(raw)||Number(raw)>10000)fail('invalid_pagination');const offset=Number(raw),rows=await array(env.DB.prepare('SELECT * FROM qs_buyer_order_drafts WHERE '+column+'=? ORDER BY created_at DESC,id DESC LIMIT 26 OFFSET ?').bind(value,offset));return json({drafts:rows.slice(0,25).map(draftView),next_offset:rows.length>25?offset+25:null,...flags});}
