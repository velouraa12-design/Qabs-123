import {platformEvent} from './platform-billing.mjs';
import {cartEvent} from './cart-groups.mjs';
import {PRODUCT_CATALOG} from './catalog.mjs';
// Fixed-shop, first-party QABS service invoices only. Never a merchant funds pool.
export const SHOP='5my584-2x.myshopify.com';
export const PRODUCTS=Object.freeze({basic:{title:'إعداد متجر مستقل — أساسي',variant:'gid://shopify/ProductVariant/48444153299081',cents:18000},complete:{title:'إنشاء متجر مستقل — متكامل',variant:'gid://shopify/ProductVariant/48444153331849',cents:79900}});
const CALLBACK='https://portal.qabs1.store/api/shopify/webhooks';
const TOPICS=['ORDERS_PAID','ORDERS_CANCELLED','REFUNDS_CREATE','DRAFT_ORDERS_UPDATE'];
const webhookTopics=['orders/paid','orders/cancelled','refunds/create','draft_orders/update'];
const scopeList=['write_draft_orders','read_draft_orders','read_orders'];
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const stamp=()=>new Date().toISOString();
function fail(code,status=400){throw Object.assign(Error(code),{status})}
const credentials=env=>!!env.SHOPIFY_CLIENT_ID&&!!env.SHOPIFY_CLIENT_SECRET;
const rows=async q=>(await q.all()).results;
export function cents(v){if(typeof v!=='string'||!/^\d{1,10}(\.\d{1,2})?$/.test(v))return null;const[a,b='']=v.split('.');const n=Number(a)*100+Number(b.padEnd(2,'0'));return Number.isSafeInteger(n)?n:null}
function moneyMatches(v,q){return !!v&&v.currencyCode===q.currency&&cents(v.amount)===q.amount_cents}
export function safeInvoiceURL(v){try{const u=new URL(v);return u.protocol==='https:'&&[SHOP,'www.qabs1.store','qabs1.store'].includes(u.hostname)&&!u.username&&!u.password&&!u.port&&/^\/\d+\/invoices\//.test(u.pathname)?u.href:null}catch{return null}}
let cachedToken;
export async function graph(env,query,variables={}){
 if(!credentials(env))fail('shopify_credentials_required',503);
 if(!cachedToken||cachedToken.client!==env.SHOPIFY_CLIENT_ID||cachedToken.secret!==env.SHOPIFY_CLIENT_SECRET||cachedToken.until<Date.now()){
  let r;try{r=await fetch('https://'+SHOP+'/admin/oauth/access_token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'client_credentials',client_id:env.SHOPIFY_CLIENT_ID,client_secret:env.SHOPIFY_CLIENT_SECRET}),signal:AbortSignal.timeout(15000)})}catch{fail('shopify_connection_unavailable',503)}
  if(!r.ok)fail('shopify_authentication_failed',503);const j=await r.json();if(typeof j.access_token!=='string'||!j.access_token)fail('shopify_authentication_failed',503);
  cachedToken={client:env.SHOPIFY_CLIENT_ID,secret:env.SHOPIFY_CLIENT_SECRET,value:j.access_token,until:Date.now()+Math.max(0,Math.min(Number(j.expires_in)||3600,86400)-120)*1000};
 }
 let r;try{r=await fetch('https://'+SHOP+'/admin/api/2026-07/graphql.json',{method:'POST',headers:{'Content-Type':'application/json','X-Shopify-Access-Token':cachedToken.value},body:JSON.stringify({query,variables}),signal:AbortSignal.timeout(20000)})}catch{fail('shopify_outcome_unconfirmed',503)}
 if(!r.ok)fail('shopify_outcome_unconfirmed',503);const j=await r.json();if(j.errors?.length||!j.data)fail('shopify_response_unconfirmed',503);return j.data;
}
function exact(b,keys){if(!b||typeof b!=='object'||Array.isArray(b)||Object.keys(b).length!==keys.length||keys.some(k=>!Object.hasOwn(b,k)))fail('invalid_invoice_request')}
function publicQuote(q){if(!q)return null;const{approved_by,owner_id,...v}=q;return v}
function publicInvoice(i){if(!i)return null;const {id,quote_id,state,created_at,updated_at,verified_at,reason}=i;return{id,quote_id,state,created_at,updated_at,verified_at,reason,paymentConfirmed:state==='paid',executionStarted:false,invoiceUrl:state==='ready'?safeInvoiceURL(i.invoice_url):null}}
async function ownRequest(env,id,u){const r=await env.DB.prepare('SELECT id,owner_id,portal_slug,status,selection_json FROM qs_service_requests WHERE id=?').bind(id).first();if(!r||(!u.is_admin&&r.owner_id!==u.user_id))fail('service_request_not_found',404);return r}
async function ownInvoice(env,id,u){const i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(id).first();if(!i||(!u.is_admin&&i.owner_id!==u.user_id))fail('invoice_not_found',404);return i}
async function enabled(env){return credentials(env)&&!!(await env.DB.prepare('SELECT enabled FROM qs_shopify_integration WHERE id=1').first())?.enabled}
const draftFields=`id status tags customAttributes{key value} invoiceUrl totalPriceSet{shopMoney{amount currencyCode}} lineItems(first:10){nodes{quantity variant{id}}} order{id}`;
async function draftById(env,id){return(await graph(env,`query QabsDraft($id:ID!){draftOrder(id:$id){${draftFields}}}`,{id})).draftOrder}
function matchingDraft(d,i,q){return d&&d.tags.includes('qabs-invoice-'+i.id)&&d.customAttributes.some(a=>a.key==='qabs_invoice_id'&&a.value===i.id)&&d.lineItems.nodes.length===1&&d.lineItems.nodes[0].quantity===1&&d.lineItems.nodes[0].variant?.id===q.variant_gid&&moneyMatches(d.totalPriceSet?.shopMoney,q)}
async function attachDraft(env,i,q,d){
 const ok=matchingDraft(d,i,q),url=ok?safeInvoiceURL(d.invoiceUrl):null;
 if(!d?.id?.startsWith('gid://shopify/DraftOrder/'))fail('shopify_draft_unconfirmed',503);
 await env.DB.prepare("UPDATE qs_shopify_invoices SET draft_gid=?,invoice_url=?,state=?,reason=?,updated_at=? WHERE id=? AND draft_gid IS NULL AND state IN ('creating','needs_review')").bind(d.id,url,ok&&url?'ready':'requires_attention',ok&&url?null:'draft_total_or_identity_mismatch',stamp(),i.id).run();
}
// Reconcile from current Shopify truth, not event payload, browser return or note attributes.
export function financialState(o,q){
 if(!o)return{state:'requires_attention',reason:'order_missing'};
 if(o.test)return{state:'requires_attention',reason:'test_order_not_payment'};
 if(o.cancelledAt)return{state:'cancelled',reason:null};
 if(!moneyMatches(o.totalPriceSet?.shopMoney,q)||o.lineItems?.nodes?.length!==1||o.lineItems.nodes[0].quantity!==1||o.lineItems.nodes[0].variant?.id!==q.variant_gid)return{state:'requires_attention',reason:'order_total_or_line_mismatch'};
 const outstanding=o.totalOutstandingSet?.shopMoney,refund=o.totalRefundedSet?.shopMoney;
 if(!outstanding||outstanding.currencyCode!==q.currency||cents(outstanding.amount)===null||!refund||refund.currencyCode!==q.currency||cents(refund.amount)===null)return{state:'requires_attention',reason:'financial_evidence_missing'};
 const refunded=cents(refund.amount);if(refunded>0)return{state:refunded>=q.amount_cents?'refunded':'partially_refunded',reason:null};
 if(o.displayFinancialStatus==='PAID'&&cents(outstanding.amount)===0&&moneyMatches(o.currentTotalPriceSet?.shopMoney,q))return{state:'paid',reason:null};
 return{state:'requires_attention',reason:'not_fully_paid'};
}
async function reconcile(env,i){
 const q=await env.DB.prepare('SELECT * FROM qs_shopify_quotes WHERE id=?').bind(i.quote_id).first();
 if(!i.draft_gid){
  const d=await graph(env,`query QabsRecover($q:String!){draftOrders(first:3,query:$q){nodes{${draftFields}}}}`,{q:'tag:qabs-invoice-'+i.id});
  const matches=d.draftOrders.nodes.filter(d=>d.tags.includes('qabs-invoice-'+i.id));
  if(matches.length!==1)return{...i,reason:matches.length?'multiple_drafts_require_review':'draft_not_found_no_automatic_retry'};
  await attachDraft(env,i,q,matches[0]);i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(i.id).first();
 }
 const v=(await env.DB.prepare('UPDATE qs_shopify_invoices SET reconcile_version=reconcile_version+1 WHERE id=? RETURNING reconcile_version').bind(i.id).first()).reconcile_version;
 const d=await draftById(env,i.draft_gid);let state,reason,orderId=null;
 if(!matchingDraft(d,i,q)){state='requires_attention';reason='draft_total_or_identity_mismatch'}
 else if(!d.order){state=d.status==='OPEN'||d.status==='INVOICE_SENT'?'ready':'requires_attention';reason=state==='ready'?null:'draft_status_unconfirmed'}
 else{
  orderId=d.order.id;if(i.order_gid&&i.order_gid!==orderId)fail('shopify_order_link_conflict',409);
  const out=await graph(env,`query QabsOrder($id:ID!){order(id:$id){id test cancelledAt displayFinancialStatus totalPriceSet{shopMoney{amount currencyCode}} currentTotalPriceSet{shopMoney{amount currencyCode}} totalOutstandingSet{shopMoney{amount currencyCode}} totalRefundedSet{shopMoney{amount currencyCode}} lineItems(first:10){nodes{quantity variant{id}}}}}`,{id:orderId});
  ({state,reason}=financialState(out.order,q));
 }
 const t=stamp();await env.DB.prepare('UPDATE qs_shopify_invoices SET order_gid=COALESCE(?,order_gid),state=?,reason=?,updated_at=?,verified_at=? WHERE id=? AND reconcile_version=?').bind(orderId,state,reason,t,t,i.id,v).run();
 return await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(i.id).first();
}
async function setup(env,u){
 const d=await graph(env,`query QabsSetup{shop{myshopifyDomain currencyCode} currentAppInstallation{app{apiKey} accessScopes{handle}} webhookSubscriptions(first:100){nodes{id topic uri} pageInfo{hasNextPage}}}`);
 if(d.shop.myshopifyDomain!==SHOP||d.shop.currencyCode!=='USD'||d.currentAppInstallation.app.apiKey!==env.SHOPIFY_CLIENT_ID||scopeList.some(s=>!d.currentAppInstallation.accessScopes.some(v=>v.handle===s)))fail('shopify_scope_or_shop_mismatch',409);
 if(d.webhookSubscriptions.pageInfo.hasNextPage)fail('shopify_webhook_pagination_review_required',409);const subscriptions=d.webhookSubscriptions.nodes;
 for(const topic of TOPICS){if(subscriptions.some(s=>s.topic===topic&&s.uri===CALLBACK))continue;const a=await graph(env,`mutation QabsWebhook($topic:WebhookSubscriptionTopic!,$input:WebhookSubscriptionInput!){webhookSubscriptionCreate(topic:$topic,webhookSubscription:$input){webhookSubscription{id topic uri} userErrors{message}}}`,{topic,input:{uri:CALLBACK,format:'JSON'}});if(a.webhookSubscriptionCreate.userErrors.length||!a.webhookSubscriptionCreate.webhookSubscription)fail('shopify_webhook_setup_incomplete',503)}
 await env.DB.prepare('UPDATE qs_shopify_integration SET enabled=1,configured_by=?,configured_at=? WHERE id=1').bind(u.user_id,stamp()).run();
}
export async function invoiceRoute(req,env,u,h){
 const {json,body,limit}=h,path=new URL(req.url).pathname,method=req.method;
 if(path==='/api/shopify-invoices'){
  if(method!=='GET')fail('method_not_allowed',405);
  return json({invoices:(await rows(env.DB.prepare('SELECT i.* FROM qs_shopify_invoices i WHERE owner_id=? ORDER BY created_at DESC LIMIT 100').bind(u.user_id))).map(publicInvoice),checkoutReady:await enabled(env),executionEnabled:false});
 }
 if(path==='/api/admin/shopify-integration'){
  if(!u.is_admin)fail('admin_required',403);
  if(method==='GET')return json({credentialsReady:credentials(env),checkoutReady:await enabled(env),products:PRODUCTS,scope:'QABS independent store services only',executionEnabled:false});
  if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,256);exact(b,['confirm']);if(b.confirm!==true)fail('confirmation_required');await limit(env,'shopify-setup:'+u.user_id,3);await setup(env,u);return json({configured:true,checkoutReady:true,paymentCreated:false});
 }
 const quotePath=path.match(/^\/api\/service-requests\/([a-f0-9-]{36})\/shopify-quote(?:\/(accept|invoice))?$/);
 if(quotePath){
  const r=await ownRequest(env,quotePath[1],u),action=quotePath[2];
  let q=await env.DB.prepare('SELECT * FROM qs_shopify_quotes WHERE request_id=?').bind(r.id).first();
  if(!action&&method==='GET'){const i=q?await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE quote_id=?').bind(q.id).first():null;return json({quote:publicQuote(q),invoice:publicInvoice(i),checkoutReady:await enabled(env),executionEnabled:false,progress:{portalSlug:r.portal_slug,reviewRequested:r.status==='under_review',briefSaved:r.portal_slug==='stores'?!!await env.DB.prepare('SELECT request_id FROM qs_store_service_briefs WHERE request_id=?').bind(r.id).first():false}})}
  if(method!=='POST')fail('method_not_allowed',405);
  const b=await body(req,8192);
  if(!action){
   if(!u.is_admin)fail('admin_required',403);exact(b,['productKey','scope','deliveryDays','terms','confirm']);if(b.confirm!==true)fail('confirmation_required');
   if(r.portal_slug!=='stores'||r.status!=='under_review')fail('reviewed_store_request_required',409);
   const brief=await env.DB.prepare('SELECT brief_json FROM qs_store_service_briefs WHERE request_id=?').bind(r.id).first();
   if(!brief||JSON.parse(brief.brief_json).package!=='إنشاء متجر مستقل'||JSON.parse(r.selection_json).service!=='إنشاء متجر مستقل')fail('independent_store_scope_required',409);
   if(q)fail('quote_already_approved',409);const p=PRODUCTS[b.productKey];
   if(!Object.hasOwn(PRODUCTS,b.productKey)||!p||typeof b.scope!=='string'||b.scope.trim().length<30||b.scope.length>2000||typeof b.terms!=='string'||b.terms.trim().length<30||b.terms.length>2000||!Number.isSafeInteger(b.deliveryDays)||b.deliveryDays<1||b.deliveryDays>365)fail('invalid_quote');
   await limit(env,'shopify-quote:'+u.user_id,20);const now=stamp();const id=crypto.randomUUID();
   await env.DB.prepare('INSERT INTO qs_shopify_quotes(id,request_id,owner_id,product_key,variant_gid,amount_cents,currency,scope,delivery_days,terms,approved_by,approved_at,expires_at) VALUES(?,?,?,?,?,?,\'USD\',?,?,?,?,?,?)').bind(id,r.id,r.owner_id,b.productKey,p.variant,p.cents,b.scope.trim(),b.deliveryDays,b.terms.trim(),u.user_id,now,new Date(Date.now()+7*86400000).toISOString()).run();return json({quoteApproved:true,paymentCreated:false},201);
  }
  if(r.owner_id!==u.user_id)fail('owner_confirmation_required',403);
  exact(b,['quoteId','confirm']);if(!q||b.quoteId!==q.id||b.confirm!==true)fail('quote_confirmation_required',409);
  if(action==='accept'){
   if(q.expires_at<stamp())fail('quote_expired',409);await env.DB.prepare('UPDATE qs_shopify_quotes SET accepted_at=COALESCE(accepted_at,?) WHERE id=?').bind(stamp(),q.id).run();return json({accepted:true,paymentCreated:false});
  }
  let i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE quote_id=?').bind(q.id).first();if(i)return json({invoice:publicInvoice(i),duplicate:true});
  if(!q.accepted_at||q.expires_at<stamp())fail('accepted_current_quote_required',409);if(!await enabled(env))fail('shopify_invoices_not_configured',503);
  await limit(env,'shopify-invoice:'+u.user_id,5);
  const catalog=(await graph(env,`query QabsInvoiceProduct($id:ID!){productVariant(id:$id){id price product{status} inventoryItem{requiresShipping}}}`,{id:q.variant_gid})).productVariant;
  if(!catalog||catalog.product.status!=='ACTIVE'||catalog.inventoryItem.requiresShipping||cents(catalog.price)!==q.amount_cents)fail('catalog_changed_requires_review',409);
  const id=crypto.randomUUID(),t=stamp();
  const inserted=await env.DB.prepare("INSERT OR IGNORE INTO qs_shopify_invoices(id,quote_id,owner_id,state,created_at,updated_at) VALUES(?,?,?,'creating',?,?)").bind(id,q.id,u.user_id,t,t).run();
  if(inserted.meta.changes!==1){i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE quote_id=?').bind(q.id).first();return json({invoice:publicInvoice(i),duplicate:true})}
  i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(id).first();
  try{
   const owner=await env.DB.prepare('SELECT email FROM qs_users WHERE id=?').bind(u.user_id).first();
   const d=await graph(env,`mutation QabsCreateInvoice($input:DraftOrderInput!){draftOrderCreate(input:$input){draftOrder{${draftFields}} userErrors{message}}}`,{input:{email:owner.email,lineItems:[{variantId:q.variant_gid,quantity:1}],presentmentCurrencyCode:'USD',acceptAutomaticDiscounts:false,allowDiscountCodesInCheckout:false,tags:['qabs-service-invoice','qabs-invoice-'+id],customAttributes:[{key:'qabs_invoice_id',value:id},{key:'qabs_request_id',value:r.id}]}});
   const out=d.draftOrderCreate;if(out.userErrors.length||!out.draftOrder)fail('shopify_draft_requires_review',409);await attachDraft(env,i,q,out.draftOrder);
  }catch{
   await env.DB.prepare("UPDATE qs_shopify_invoices SET state='needs_review',reason='creation_outcome_requires_reconciliation',updated_at=? WHERE id=? AND state='creating'").bind(stamp(),id).run();
  }
  i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(id).first();return json({invoice:publicInvoice(i),executionStarted:false},201);
 }
 const rec=path.match(/^\/api\/shopify-invoices\/([a-f0-9-]{36})\/reconcile$/);
 if(rec){if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,128);exact(b,['confirm']);if(b.confirm!==true)fail('confirmation_required');const i=await ownInvoice(env,rec[1],u);await limit(env,'shopify-reconcile:'+u.user_id,20);return json({invoice:publicInvoice(await reconcile(env,i)),executionStarted:false})}
 return null;
}
async function boundedBody(req,max){const reader=req.body?.getReader();if(!reader)fail('invalid_webhook');let size=0,chunks=[];while(true){const{value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>max){await reader.cancel();fail('webhook_too_large',413)}chunks.push(value)}const all=new Uint8Array(size);let n=0;for(const c of chunks){all.set(c,n);n+=c.length}return all}
export async function verifyHMAC(raw,header,secret){try{if(!header||!secret)return false;const signature=Uint8Array.from(atob(header),c=>c.charCodeAt(0));if(signature.length!==32)return false;const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);return crypto.subtle.verify('HMAC',key,signature,raw)}catch{return false}}
function resourceGid(topic,p){if(topic==='refunds/create')return /^\d+$/.test(String(p.order_id))?'gid://shopify/Order/'+p.order_id:null;const kind=topic==='draft_orders/update'?'DraftOrder':'Order';if(typeof p.admin_graphql_api_id==='string'&&new RegExp('^gid://shopify/'+kind+'/[0-9]+$').test(p.admin_graphql_api_id))return p.admin_graphql_api_id;return /^\d+$/.test(String(p.id))?'gid://shopify/'+kind+'/'+p.id:null}
export async function shopifyWebhook(req,env,h){
 const{json}=h;if(req.method!=='POST')fail('method_not_allowed',405);if(!credentials(env))fail('shopify_credentials_required',503);
 const shop=req.headers.get('X-Shopify-Shop-Domain'),topic=req.headers.get('X-Shopify-Topic'),event=req.headers.get('X-Shopify-Event-Id')||req.headers.get('X-Shopify-Webhook-Id');
 if(shop!==SHOP||!webhookTopics.includes(topic)||!uuid.test(event||''))fail('webhook_headers_rejected',401);
 const raw=await boundedBody(req,262144);if(!await verifyHMAC(raw,req.headers.get('X-Shopify-Hmac-Sha256'),env.SHOPIFY_CLIENT_SECRET))fail('webhook_signature_rejected',401);
 let payload;try{payload=JSON.parse(new TextDecoder().decode(raw))}catch{fail('invalid_webhook')}
 const gid=resourceGid(topic,payload);if(!gid)fail('webhook_resource_required');
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',raw)),v=>v.toString(16).padStart(2,'0')).join('');
 await env.DB.prepare("INSERT OR IGNORE INTO qs_shopify_events(shop,event_id,topic,payload_hash,resource_gid,state,created_at) VALUES(?,?,?,?,?,'pending',?)").bind(shop,event,topic,hash,gid,stamp()).run();
 const saved=await env.DB.prepare('SELECT * FROM qs_shopify_events WHERE shop=? AND event_id=?').bind(shop,event).first();if(saved.payload_hash!==hash||saved.topic!==topic)fail('webhook_event_conflict',409);if(saved.state==='processed')return json({received:true,duplicate:true});
 let i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE draft_gid=? OR order_gid=?').bind(gid,gid).first();
 // Attributes are lookup hints only; reconciliation always verifies actual draft -> order linkage.
 const attrs=topic==='draft_orders/update'?payload.custom_attributes||payload.note_attributes:payload.note_attributes;
 const hint=Array.isArray(attrs)?attrs.find(a=>(a.key||a.name)==='qabs_invoice_id')?.value:null;
 if(!i&&uuid.test(hint||''))i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(hint).first();
 if(!i&&topic==='refunds/create'){
  const o=await graph(env,'query QabsEventLookup($id:ID!){order(id:$id){customAttributes{key value}}}',{id:gid});const v=o.order?.customAttributes.find(a=>a.key==='qabs_invoice_id')?.value;if(uuid.test(v||''))i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(v).first();
 }
 if(i){const updated=await reconcile(env,i);if(!updated.draft_gid)fail('invoice_link_pending_retry',503)}
 if(!i)await linkedEvent(env,gid,topic,payload);
 await cartEvent(env,gid,topic,payload,graph);
 await platformEvent(env,gid,topic,payload,graph);
 await env.DB.prepare("UPDATE qs_shopify_events SET state='processed',processed_at=? WHERE shop=? AND event_id=?").bind(stamp(),shop,event).run();return json({received:true,executionStarted:false});
}

// Direct hosted Shopify purchase: does NOT create a portal quote/invoice or confirm portal payment.
export async function directServiceCheckout(env,productKey){
 if(typeof productKey!=='string'||!Object.hasOwn(PRODUCTS,productKey))fail('invalid_package_request');
 if(!await enabled(env))fail('shopify_invoices_not_configured',503);
 const p=PRODUCTS[productKey];
 const d=await graph(env,`query QabsDirectProduct($id:ID!){shop{myshopifyDomain currencyCode} productVariant(id:$id){id price product{status} inventoryItem{requiresShipping}}}`,{id:p.variant});
 const v=d.productVariant;
 if(d.shop.myshopifyDomain!==SHOP||d.shop.currencyCode!=='USD'||!v||v.id!==p.variant||v.product.status!=='ACTIVE'||v.inventoryItem.requiresShipping||cents(v.price)!==p.cents)fail('catalog_changed_requires_review',409);
 const variant=p.variant.split('/').pop();if(!/^\d+$/.test(variant))fail('catalog_changed_requires_review',409);
 return{checkoutUrl:'https://www.qabs1.store/cart/'+variant+':1',referenceAmountCents:p.cents,currency:'USD',orderSystem:'shopify',portalPaymentConfirmed:false,portalOrderCreated:false,invoiceCreated:false,serviceFinalPriceApproved:false,scopeRequiresReview:true};
}

// Fixed catalog entries only. Hosted checkout never confirms a portal order/payment.
export async function catalogCheckout(env,handle,variantId){
 const p=PRODUCT_CATALOG.find(p=>p.handle===handle),v=p?.variants.find(v=>v.id===variantId);
 if(!p||!p.direct||!v)fail('catalog_item_requires_review',409);
 if(!await enabled(env))fail('shopify_invoices_not_configured',503);
 const d=await graph(env,`query QabsCatalogProduct($id:ID!){shop{myshopifyDomain currencyCode}productVariant(id:$id){id price inventoryPolicy inventoryQuantity inventoryItem{tracked requiresShipping}product{id handle status description onlineStoreUrl requiresSellingPlan sellingPlanGroups(first:1){nodes{id}}}}}`,{id:'gid://shopify/ProductVariant/'+v.id});
 const live=d.productVariant,q=live?.product;
 const hash=q?Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(q.description)))).map(v=>v.toString(16).padStart(2,'0')).join(''):null;
 if(d.shop?.myshopifyDomain!==SHOP||d.shop.currencyCode!=='USD'||!live||live.id!=='gid://shopify/ProductVariant/'+v.id||q.id!=='gid://shopify/Product/'+p.id||q.handle!==p.handle||q.status!=='ACTIVE'||!q.onlineStoreUrl||q.requiresSellingPlan||q.sellingPlanGroups.nodes.length||live.inventoryItem.requiresShipping||live.inventoryItem.tracked&&live.inventoryQuantity<1&&live.inventoryPolicy!=='CONTINUE'||cents(live.price)!==v.cents||hash!==p.descriptionHash)fail('catalog_changed_requires_review',409);
 return{checkoutUrl:'https://www.qabs1.store/cart/'+v.id+':1',referenceAmountCents:v.cents,currency:'USD',orderSystem:'shopify',portalPaymentConfirmed:false,portalOrderCreated:false,invoiceCreated:false,executionStarted:false,automaticRenewal:false,scopeRequiresReview:true};
}

// Linked checkout uses an opaque server-owned correlation ID, not a browser payment claim.
function checkoutView(i){if(!i)return null;return{id:i.id,requestId:i.request_id,productHandle:i.product_handle,amountCents:i.amount_cents,currency:i.currency,state:i.state,reason:i.reason,createdAt:i.created_at,expiresAt:i.expires_at,verifiedAt:i.verified_at,orderLinked:!!i.order_gid,canReconcile:!!(i.order_gid||i.candidate_order_gid),paymentConfirmed:i.state==='paid',executionStarted:false};}
function correlatedUrl(i){return 'https://www.qabs1.store/cart/'+i.variant_gid.split('/').pop()+':1?'+new URLSearchParams({'attributes[qabs_checkout_id]':i.id});}
async function checkoutOwner(env,id,u){const i=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE id=?').bind(id).first();if(!i||(!u.is_admin&&i.owner_id!==u.user_id))fail('checkout_not_found',404);return i;}
export async function validateCatalogForLink(env,p,v){
 if(!await enabled(env))fail('shopify_invoices_not_configured',503);
 // Same immutable price/identity/description checks as the seven direct products.
 const d=await graph(env,`query QabsLinkedProduct($id:ID!){shop{myshopifyDomain currencyCode}productVariant(id:$id){id price inventoryPolicy inventoryQuantity inventoryItem{tracked requiresShipping}product{id handle status description onlineStoreUrl requiresSellingPlan sellingPlanGroups(first:1){nodes{id}}}}}`,{id:'gid://shopify/ProductVariant/'+v.id});
 const live=d.productVariant,q=live?.product,hash=q?Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(q.description))),v=>v.toString(16).padStart(2,'0')).join(''):null;
 if(d.shop?.myshopifyDomain!==SHOP||d.shop.currencyCode!=='USD'||!live||live.id!=='gid://shopify/ProductVariant/'+v.id||q.id!=='gid://shopify/Product/'+p.id||q.handle!==p.handle||q.status!=='ACTIVE'||!q.onlineStoreUrl||q.requiresSellingPlan||q.sellingPlanGroups.nodes.length||live.inventoryItem.requiresShipping||live.inventoryItem.tracked&&live.inventoryQuantity<1&&live.inventoryPolicy!=='CONTINUE'||cents(live.price)!==v.cents||v.cents<=0||hash!==p.descriptionHash)fail('catalog_changed_requires_review',409);
}
async function startLinkedCheckout(env,u,p,v,attemptId,request=null){
 if(!uuid.test(attemptId||''))fail('invalid_attempt_id');if(!await enabled(env))fail('shopify_invoices_not_configured',503);
 const old=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE owner_id=? AND attempt_id=?').bind(u.user_id,attemptId).first();
 if(old){if(old.product_handle!==p.handle||old.variant_gid!=='gid://shopify/ProductVariant/'+v.id||old.amount_cents!==v.cents||request&&old.request_id!==request.id)fail('attempt_conflict',409);if(old.state!=='pending'||old.expires_at<stamp())fail('checkout_already_used_or_expired',409);await validateCatalogForLink(env,p,v);return{checkout:checkoutView(old),checkoutUrl:correlatedUrl(old),duplicate:true,portalPaymentConfirmed:false};}
 if(request&&await env.DB.prepare('SELECT id FROM qs_checkout_intents WHERE request_id=?').bind(request.id).first())fail('request_checkout_already_created',409);
 await validateCatalogForLink(env,p,v);
 const id=crypto.randomUUID(),requestId=request?.id||crypto.randomUUID(),t=stamp(),expires=new Date(Math.min(Date.now()+24*3600000,request?.quoteExpires?Date.parse(request.quoteExpires):Infinity)).toISOString();
 const items=[];
 if(!request){const selection=JSON.stringify({'المنتج المختار':p.title,'مرجع الكتالوج':p.handle,'الخيار':v.title,'السعر المرجعي USD':(v.cents/100).toFixed(2),'نوع الطلب':'شراء مباشر مرتبط — بانتظار الدفع الموثق'});items.push(env.DB.prepare("INSERT INTO qs_service_requests(id,owner_id,portal_slug,selection_json,attempt_id,status,payment_status,created_at,updated_at) VALUES(?,?,?,?,?,'draft','unpaid',?,?)").bind(requestId,u.user_id,p.portal,selection,attemptId,t,t),env.DB.prepare("INSERT INTO qs_service_events(id,request_id,kind,created_at) VALUES(?,?,'draft_created',?)").bind(crypto.randomUUID(),requestId,t));}
 items.push(env.DB.prepare("INSERT INTO qs_checkout_intents(id,request_id,owner_id,attempt_id,product_handle,variant_gid,amount_cents,currency,state,created_at,expires_at,updated_at) VALUES(?,?,?,?,?,?,?,'USD','pending',?,?,?)").bind(id,requestId,u.user_id,attemptId,p.handle,'gid://shopify/ProductVariant/'+v.id,v.cents,t,expires,t));
 try{await env.DB.batch(items)}catch(e){const prior=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE owner_id=? AND attempt_id=?').bind(u.user_id,attemptId).first();if(prior&&prior.state==='pending'&&prior.expires_at>=stamp()&&prior.amount_cents===v.cents&&prior.product_handle===p.handle&&prior.variant_gid==='gid://shopify/ProductVariant/'+v.id&&(!request||prior.request_id===request.id))return{checkout:checkoutView(prior),checkoutUrl:correlatedUrl(prior),duplicate:true,portalPaymentConfirmed:false};throw e;}
 const saved=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE id=?').bind(id).first();return{checkout:checkoutView(saved),checkoutUrl:correlatedUrl(saved),portalPaymentConfirmed:false,portalOrderCreated:!request,checkoutIntentCreated:true,executionStarted:false};
}
export function linkedFinancialState(o,i,ownerEmail){
 const a=o?.customAttributes?.filter(a=>a.key==='qabs_checkout_id');
 if(!o||a?.length!==1||a[0].value!==i.id||typeof o.email!=='string'||o.email.trim().toLowerCase()!==ownerEmail.trim().toLowerCase())return{state:'requires_attention',reason:'order_identity_unconfirmed',matched:false};
 const item=o.lineItems?.nodes?.[0],unit=item?.originalUnitPriceSet?.shopMoney;
 const created=Date.parse(o.createdAt),opened=Date.parse(i.created_at),expires=Date.parse(i.expires_at);
 const amount=m=>m?.currencyCode==='USD'?cents(m.amount):null;
 const total=amount(o.totalPriceSet?.shopMoney),tax=amount(o.totalTaxSet?.shopMoney),discount=amount(o.totalDiscountsSet?.shopMoney),shipping=amount(o.totalShippingPriceSet?.shopMoney),refund=amount(o.totalRefundedSet?.shopMoney),outstanding=amount(o.totalOutstandingSet?.shopMoney),current=amount(o.currentTotalPriceSet?.shopMoney);
 if(!/^gid:\/\/shopify\/Order\/\d+$/.test(o.id||'')||o.test||!Number.isFinite(created)||!Number.isFinite(opened)||!Number.isFinite(expires)||created<opened-60000||created>expires||o.lineItems?.nodes?.length!==1||o.lineItems?.pageInfo?.hasNextPage!==false||item.quantity!==1||item.variant?.id!==i.variant_gid||amount(unit)!==i.amount_cents||amount(item.discountedTotalSet?.shopMoney)!==i.amount_cents||tax===null||discount!==0||shipping!==0||total!==i.amount_cents+tax||refund===null||refund>total||outstanding===null||current===null)return{state:'requires_attention',reason:'order_amount_or_scope_unconfirmed',matched:false};
 if(o.cancelledAt)return{state:'cancelled',reason:null,matched:true};
 if(refund>0)return{state:refund>=total?'refunded':'partially_refunded',reason:null,matched:true};
 if(o.displayFinancialStatus==='PAID'&&outstanding===0&&current===total)return{state:'paid',reason:null,matched:true};
 return{state:'pending',reason:'not_fully_paid',matched:true};
}
async function reconcileLinked(env,i,orderId=i.order_gid||i.candidate_order_gid){
 if(!orderId)return i;
 const revision=(await env.DB.prepare('UPDATE qs_checkout_intents SET revision=revision+1 WHERE id=? RETURNING revision').bind(i.id).first()).revision;
 const owner=await env.DB.prepare('SELECT email FROM qs_users WHERE id=?').bind(i.owner_id).first();
 const d=await graph(env,`query QabsLinkedOrder($id:ID!){order(id:$id){id email createdAt test cancelledAt displayFinancialStatus customAttributes{key value} totalPriceSet{shopMoney{amount currencyCode}} currentTotalPriceSet{shopMoney{amount currencyCode}} totalOutstandingSet{shopMoney{amount currencyCode}} totalRefundedSet{shopMoney{amount currencyCode}} totalTaxSet{shopMoney{amount currencyCode}} totalDiscountsSet{shopMoney{amount currencyCode}} totalShippingPriceSet{shopMoney{amount currencyCode}} lineItems(first:10){nodes{quantity variant{id} originalUnitPriceSet{shopMoney{amount currencyCode}} discountedTotalSet{shopMoney{amount currencyCode}}}pageInfo{hasNextPage}}}}`,{id:orderId});
 const state=linkedFinancialState(d.order,i,owner.email);if(i.order_gid&&i.order_gid!==orderId)fail('checkout_order_conflict',409);
 if(state.matched){const conflict=await env.DB.prepare('SELECT id FROM qs_checkout_intents WHERE order_gid=? AND id!=?').bind(orderId,i.id).first();if(conflict)fail('checkout_order_conflict',409);}
 const t=stamp(),bound=state.matched?orderId:null;
 const update=env.DB.prepare('UPDATE qs_checkout_intents SET candidate_order_gid=?,order_gid=COALESCE(?,order_gid),state=?,reason=?,updated_at=?,verified_at=? WHERE id=? AND revision=?').bind(orderId,bound,state.state,state.reason,t,t,i.id,revision);
 if(state.state!==i.state){await env.DB.batch([update,env.DB.prepare('INSERT OR IGNORE INTO qs_checkout_transitions(intent_id,revision,state,created_at) SELECT ?,?,?,? WHERE changes()=1').bind(i.id,revision,state.state,t),env.DB.prepare('INSERT OR IGNORE INTO qs_notifications(id,user_id,store_id,type,resource_id,title,message,created_at) SELECT ?,?,NULL,?,?,?,?,? WHERE changes()=1').bind(crypto.randomUUID(),i.owner_id,'checkout_'+state.state,i.id,state.state==='paid'?'تم التحقق من دفع طلبك':'تحديث حالة شراء الخدمة','تحدّثت حالة الدفع من Shopify. راجع مشترياتي وتفاصيل طلب الخدمة؛ التنفيذ الخارجي لا يبدأ تلقائيًا.',t)]);}else await update.run();
 return await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE id=?').bind(i.id).first();
}
async function linkedEvent(env,gid,topic,payload){
 if(topic==='draft_orders/update'||!(await env.DB.prepare('SELECT COUNT(*) AS n FROM qs_checkout_intents').first()).n)return;
 let i=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE order_gid=?').bind(gid).first();
 if(!i){let attrs=payload.note_attributes;if(topic==='refunds/create'||!Array.isArray(attrs)||!attrs.some(a=>(a.key||a.name)==='qabs_checkout_id')){const r=await graph(env,'query QabsLinkedEventLookup($id:ID!){order(id:$id){customAttributes{key value}}}',{id:gid});attrs=r.order?.customAttributes;}
 const hint=Array.isArray(attrs)?attrs.find(a=>(a.key||a.name)==='qabs_checkout_id')?.value:null;if(uuid.test(hint||''))i=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE id=?').bind(hint).first();}
 if(i)await reconcileLinked(env,i,gid);
}
export async function linkedCheckoutRoute(req,env,u,{json,body,limit}){
 const path=new URL(req.url).pathname,method=req.method;
 if(path==='/api/checkout-orders'){
  if(method!=='GET')fail('method_not_allowed',405);const params=new URL(req.url).searchParams,admin=params.get('admin')==='1';if(admin&&!u.is_admin)fail('admin_required',403);
  const items=admin?await rows(env.DB.prepare('SELECT * FROM qs_checkout_intents ORDER BY created_at DESC LIMIT 100')):await rows(env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE owner_id=? ORDER BY created_at DESC LIMIT 100').bind(u.user_id));return json({orders:items.map(checkoutView),executionEnabled:false});
 }
 const match=path.match(/^\/api\/checkout-orders\/([a-f0-9-]{36})(?:\/(reconcile|resume))?$/);
 if(match){const i=await checkoutOwner(env,match[1],u);if(!match[2]&&method==='GET')return json({checkout:checkoutView(i)});if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,256);exact(b,['confirm']);if(b.confirm!==true)fail('confirmation_required');await limit(env,'checkout-action:'+u.user_id,20);
  if(match[2]==='reconcile')return json({checkout:checkoutView(await reconcileLinked(env,i)),executionStarted:false});
  if(i.owner_id!==u.user_id)fail('owner_confirmation_required',403);const p=PRODUCT_CATALOG.find(p=>p.handle===i.product_handle),v=p?.variants.find(v=>'gid://shopify/ProductVariant/'+v.id===i.variant_gid);if(!p||!v||i.amount_cents!==v.cents||i.state!=='pending'||i.expires_at<stamp())fail('checkout_already_used_or_expired',409);await validateCatalogForLink(env,p,v);return json({checkout:checkoutView(i),checkoutUrl:correlatedUrl(i)});
 }
 if(path==='/api/product-catalog/start'){
  if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,1024);exact(b,['handle','variantId','attemptId','confirm']);if(b.confirm!==true)fail('confirmation_required');const p=PRODUCT_CATALOG.find(p=>p.handle===b.handle),v=p?.variants.find(v=>v.id===b.variantId);if(!p?.direct||!v)fail('catalog_item_requires_review',409);await limit(env,'checkout-start:'+u.user_id,20);return json(await startLinkedCheckout(env,u,p,v,b.attemptId),201);
 }
 const approval=path.match(/^\/api\/service-requests\/([a-f0-9-]{36})\/catalog-approval(?:\/(accept|checkout))?$/);if(!approval)return null;
 const r=await ownRequest(env,approval[1],u),action=approval[2];let q=await env.DB.prepare('SELECT * FROM qs_catalog_approvals WHERE request_id=?').bind(r.id).first();
 if(!action&&method==='GET'){const i=await env.DB.prepare('SELECT * FROM qs_checkout_intents WHERE request_id=?').bind(r.id).first();return json({approval:q?(({owner_id,approved_by,...x})=>x)(q):null,checkout:checkoutView(i),executionStarted:false});}
 if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,8192);
 if(!action){if(!u.is_admin)fail('admin_required',403);exact(b,['scope','terms','deliveryDays','confirmFinalTotal','confirmEligibility']);if(b.confirmFinalTotal!==true||b.confirmEligibility!==true||typeof b.scope!=='string'||b.scope.trim().length<30||b.scope.length>2000||typeof b.terms!=='string'||b.terms.trim().length<30||b.terms.length>2000||!Number.isSafeInteger(b.deliveryDays)||b.deliveryDays<1||b.deliveryDays>365)fail('invalid_catalog_approval');if(r.status!=='under_review'||q||await env.DB.prepare('SELECT id FROM qs_checkout_intents WHERE request_id=?').bind(r.id).first())fail('catalog_request_review_required',409);
 const s=JSON.parse(r.selection_json),p=PRODUCT_CATALOG.find(p=>p.handle===s['مرجع الكتالوج']),v=p?.variants.find(v=>v.title===s['الخيار']);if(!p||!v||p.portal!==r.portal_slug||v.cents<=0)fail('catalog_request_review_required',409);await limit(env,'catalog-approval:'+u.user_id,20);await validateCatalogForLink(env,p,v);const t=stamp();await env.DB.prepare("INSERT INTO qs_catalog_approvals(id,request_id,owner_id,product_handle,variant_gid,amount_cents,currency,scope,terms,delivery_days,approved_by,approved_at,expires_at) VALUES(?,?,?,?,?,?,'USD',?,?,?,?,?,?)").bind(crypto.randomUUID(),r.id,r.owner_id,p.handle,'gid://shopify/ProductVariant/'+v.id,v.cents,b.scope.trim(),b.terms.trim(),b.deliveryDays,u.user_id,t,new Date(Date.now()+7*86400000).toISOString()).run();return json({approved:true,paymentCreated:false},201);}
 if(r.owner_id!==u.user_id)fail('owner_confirmation_required',403);exact(b,action==='accept'?['approvalId','confirm']:['approvalId','attemptId','confirm']);if(!q||q.id!==b.approvalId||b.confirm!==true||q.expires_at<stamp())fail('accepted_current_quote_required',409);
 if(action==='accept'){await env.DB.prepare('UPDATE qs_catalog_approvals SET accepted_at=COALESCE(accepted_at,?) WHERE id=?').bind(stamp(),q.id).run();return json({accepted:true,paymentCreated:false});}
 if(!q.accepted_at)fail('accepted_current_quote_required',409);const p=PRODUCT_CATALOG.find(p=>p.handle===q.product_handle),v=p?.variants.find(v=>'gid://shopify/ProductVariant/'+v.id===q.variant_gid);if(!p||!v||v.cents!==q.amount_cents)fail('catalog_changed_requires_review',409);await limit(env,'checkout-start:'+u.user_id,20);return json(await startLinkedCheckout(env,u,p,v,b.attemptId,{...r,quoteExpires:q.expires_at}),201);
}

// Retry only records that previously passed the provider signature check and entered the inbox.
export async function retryPendingShopifyEvents(env){
 const pending=await rows(env.DB.prepare("SELECT shop,event_id,topic,resource_gid FROM qs_shopify_events WHERE state='pending' ORDER BY created_at LIMIT 10"));
 const out={examined:pending.length,processed:0,failed:0,executionStarted:false};
 for(const e of pending){try{
  if(e.shop!==SHOP||!webhookTopics.includes(e.topic)||!/^gid:\/\/shopify\/(Order|DraftOrder)\/\d+$/.test(e.resource_gid||''))throw Error('invalid_stored_event');
  let i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE draft_gid=? OR order_gid=?').bind(e.resource_gid,e.resource_gid).first();
  let attrs=[];
  if(!i){if(e.topic==='draft_orders/update')attrs=(await draftById(env,e.resource_gid))?.customAttributes||[];else attrs=(await graph(env,'query QabsOpsEventLookup($id:ID!){order(id:$id){customAttributes{key value}}}',{id:e.resource_gid})).order?.customAttributes||[];
   const hint=attrs.find(a=>a.key==='qabs_invoice_id')?.value;if(uuid.test(hint||''))i=await env.DB.prepare('SELECT * FROM qs_shopify_invoices WHERE id=?').bind(hint).first();}
  if(i){const updated=await reconcile(env,i);if(!updated.draft_gid)throw Error('invoice_link_pending');}else await linkedEvent(env,e.resource_gid,e.topic,{note_attributes:attrs});
  await cartEvent(env,e.resource_gid,e.topic,{note_attributes:attrs},graph);
  await platformEvent(env,e.resource_gid,e.topic,{note_attributes:attrs},graph);
  await env.DB.prepare("UPDATE qs_shopify_events SET state='processed',processed_at=? WHERE shop=? AND event_id=? AND state='pending'").bind(stamp(),e.shop,e.event_id).run();out.processed++;
 }catch{out.failed++;}}
 return out;
}

