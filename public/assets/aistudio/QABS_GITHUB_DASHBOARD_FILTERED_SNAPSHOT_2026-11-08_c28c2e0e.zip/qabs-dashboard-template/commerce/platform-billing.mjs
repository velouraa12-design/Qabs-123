// Fixed first-party platform access only. Never charges merchant customers or publishes a store.
export const PLATFORM_PLANS=Object.freeze({basic:Object.freeze({id:'basic',sku:'QABS-PLATFORM-BASIC-30D-V51',title:'قبس — اشتراك المنصة الأساسية لمدة 30 يومًا',cents:1900,limit:25}),growth:Object.freeze({id:'growth',sku:'QABS-PLATFORM-GROWTH-30D-V51',title:'قبس — اشتراك منصة النمو لمدة 30 يومًا',cents:3900,limit:100})});
const SHOP='5my584-2x.myshopify.com',CALLBACK='https://portal.qabs1.store/api/shopify/webhooks',UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const ts=()=>new Date().toISOString(),sec=()=>Math.floor(Date.now()/1000),list=async q=>(await q.all()).results||[];
function fail(code,status=400){throw Object.assign(Error(code),{status})}
function exact(x,keys){if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==keys.length||keys.some(k=>!Object.hasOwn(x,k)))fail('invalid_platform_billing_request')}
export function cents(v){if(typeof v!=='string'||!/^\d{1,10}(\.\d{1,2})?$/.test(v))return null;const[a,b='']=v.split('.'),n=Number(a)*100+Number(b.padEnd(2,'0'));return Number.isSafeInteger(n)?n:null}
function money(x){return x?.currencyCode==='USD'?cents(x.amount):null}
export function invoiceURL(x){try{const u=new URL(x);return u.protocol==='https:'&&[SHOP,'qabs1.store','www.qabs1.store'].includes(u.hostname)&&!u.username&&!u.password&&!u.port&&/^\/\d+\/invoices\/[A-Za-z0-9_-]+/.test(u.pathname)?u.href:null}catch{return null}}
function attrs(x,id){return x?.customAttributes?.some(a=>a.key==='qabs_platform_billing_id'&&a.value===id)}
const amountFields='subtotalPriceSet{shopMoney{amount currencyCode}} totalPriceSet{shopMoney{amount currencyCode}} totalTaxSet{shopMoney{amount currencyCode}} totalDiscountsSet{shopMoney{amount currencyCode}}';
const lineFields='lineItems(first:3){nodes{title sku quantity requiresShipping originalUnitPriceSet{shopMoney{amount currencyCode}} variant{id}}}';
const draftFields=`id status tags customAttributes{key value} invoiceUrl ${amountFields} ${lineFields} order{id}`;
const orderFields=`id email test cancelledAt displayFinancialStatus tags customAttributes{key value} ${amountFields} ${lineFields} currentTotalPriceSet{shopMoney{amount currencyCode}} totalOutstandingSet{shopMoney{amount currencyCode}} totalRefundedSet{shopMoney{amount currencyCode}}`;
function lineMatches(o,i){const p=PLATFORM_PLANS[i.plan_id],lines=o?.lineItems?.nodes;return !!p&&i.amount_cents===p.cents&&lines?.length===1&&lines[0].quantity===1&&!lines[0].variant&&lines[0].sku===p.sku&&lines[0].title===p.title&&lines[0].requiresShipping===false&&money(lines[0].originalUnitPriceSet?.shopMoney)===p.cents}
function totals(o,i){const subtotal=money(o?.subtotalPriceSet?.shopMoney),total=money(o?.totalPriceSet?.shopMoney),tax=money(o?.totalTaxSet?.shopMoney),discount=money(o?.totalDiscountsSet?.shopMoney);return subtotal===i.amount_cents&&tax!==null&&tax>=0&&tax<=i.amount_cents&&discount===0&&total===i.amount_cents+tax?{total,tax}:null}
export function matchingDraft(d,i){return !!d&&/^gid:\/\/shopify\/DraftOrder\/\d+$/.test(d.id)&&d.tags?.includes('qabs-platform-'+i.id)&&attrs(d,i.id)&&lineMatches(d,i)&&!!totals(d,i)}
export function platformFinancialState(o,i,ownerEmail){
 if(!o||!/^gid:\/\/shopify\/Order\/\d+$/.test(o.id||'')||!attrs(o,i.id)||!o.tags?.includes('qabs-platform-'+i.id)||!lineMatches(o,i))return{state:'requires_attention',reason:'platform_order_identity_mismatch'};
 if(o.test)return{state:'requires_attention',reason:'test_order_not_payment'};
 if(typeof o.email!=='string'||o.email.toLowerCase()!==ownerEmail.toLowerCase())return{state:'requires_attention',reason:'platform_payer_email_mismatch'};
 if(o.cancelledAt)return{state:'cancelled',reason:null};
 const t=totals(o,i),refunded=money(o.totalRefundedSet?.shopMoney),outstanding=money(o.totalOutstandingSet?.shopMoney);if(!t||refunded===null||outstanding===null)return{state:'requires_attention',reason:'platform_financial_evidence_mismatch'};
 if(refunded>0)return{state:refunded>=t.total?'refunded':'partially_refunded',reason:null,...t};
 if(o.displayFinancialStatus==='PAID'&&outstanding===0&&money(o.currentTotalPriceSet?.shopMoney)===t.total)return{state:'paid',reason:null,...t};
 return{state:'ready',reason:'not_fully_paid',...t};
}
function view(i){if(!i)return null;return{id:i.id,store_id:i.store_id,plan_id:i.plan_id,amount_cents:i.amount_cents,currency:'USD',days:30,state:i.state,reason:i.reason,created_at:i.created_at,updated_at:i.updated_at,paymentConfirmed:i.state==='paid',subscriptionActivated:i.state==='paid'&&!!i.applied_at,granted_start:i.granted_start,granted_end:i.granted_end,actual_total_cents:i.actual_total_cents,tax_cents:i.tax_cents,invoiceUrl:i.state==='ready'?invoiceURL(i.invoice_url):null,storePublished:false,automaticRenewal:false}}
let providerCache;
export async function platformReadiness(env,graph){
 const config=await env.DB.prepare('SELECT enabled FROM qs_platform_billing_config WHERE id=1').first(),plans=await list(env.DB.prepare("SELECT id,price_cents,cycle,status,product_limit FROM qs_plans WHERE id IN('basic','growth')"));
 const planOK=Object.values(PLATFORM_PLANS).every(p=>plans.some(x=>x.id===p.id&&x.price_cents===p.cents&&x.cycle==='month'&&x.status==='approved'&&x.product_limit===p.limit));
 let provider=false,issue='shopify_platform_not_configured';
 if(env.SHOPIFY_CLIENT_ID&&env.SHOPIFY_CLIENT_SECRET){try{if(providerCache&&providerCache.client===env.SHOPIFY_CLIENT_ID&&providerCache.until>Date.now()){provider=providerCache.ok;issue=providerCache.issue}else{
 const d=await graph(env,'query QabsPlatformReadiness{shop{myshopifyDomain currencyCode} currentAppInstallation{app{apiKey}accessScopes{handle}} webhookSubscriptions(first:100){nodes{topic uri}pageInfo{hasNextPage}}}');
 provider=d.shop.myshopifyDomain===SHOP&&d.shop.currencyCode==='USD'&&d.currentAppInstallation.app.apiKey===env.SHOPIFY_CLIENT_ID&&['write_draft_orders','read_draft_orders','read_orders'].every(s=>d.currentAppInstallation.accessScopes.some(x=>x.handle===s))&&!d.webhookSubscriptions.pageInfo.hasNextPage&&['ORDERS_PAID','ORDERS_CANCELLED','REFUNDS_CREATE','DRAFT_ORDERS_UPDATE'].every(t=>d.webhookSubscriptions.nodes.some(x=>x.topic===t&&x.uri===CALLBACK));issue=provider?null:'shopify_scope_or_webhook_mismatch';providerCache={client:env.SHOPIFY_CLIENT_ID,until:Date.now()+60000,ok:provider,issue};
 }}catch{issue='shopify_provider_unavailable'}}
 return{provider:'Shopify',providerVerified:provider,plansApproved:planOK,enabled:config?.enabled===1,checkoutReady:provider&&planOK&&config?.enabled===1,issue:!provider?issue:!planOK?'platform_plans_not_approved':config?.enabled!==1?'platform_billing_not_enabled':null,days:30,currency:'USD',plans:Object.values(PLATFORM_PLANS).map(p=>({id:p.id,title:p.title,amount_cents:p.cents,product_limit:p.limit})),automaticRenewal:false,publicationAutomatic:false};
}
async function ownedStore(env,id,u){const s=await env.DB.prepare('SELECT * FROM qs_stores WHERE id=? AND owner_id=?').bind(id,u.user_id).first();if(!s)fail('store_not_found',404);return s}
async function ownedIntent(env,id,u){const i=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(id).first();if(!i||(!u.is_admin&&i.owner_id!==u.user_id))fail('platform_invoice_not_found',404);return i}
async function attach(env,i,d){
 if(!matchingDraft(d,i))fail('platform_draft_mismatch',409);const url=invoiceURL(d.invoiceUrl);if(!url)fail('platform_invoice_url_unconfirmed',503);
 await env.DB.prepare("UPDATE qs_platform_billing_intents SET draft_gid=?,invoice_url=?,state='ready',reason=NULL,updated_at=? WHERE id=? AND draft_gid IS NULL AND state IN('creating','needs_review')").bind(d.id,url,ts(),i.id).run();return await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(i.id).first();
}
async function applyState(env,i,fin,orderId,version){
 const t=ts(),now=sec();const access=PLATFORM_PLANS[i.plan_id];
 const guarded="id=? AND reconcile_version=?";
 const q=[env.DB.prepare(`UPDATE qs_platform_billing_intents SET state=?,reason=?,order_gid=COALESCE(?,order_gid),actual_total_cents=COALESCE(?,actual_total_cents),tax_cents=COALESCE(?,tax_cents),updated_at=?,verified_at=? WHERE ${guarded}`).bind(fin.state,fin.reason,orderId,fin.total??null,fin.tax??null,t,t,i.id,version)];
 if(fin.state==='paid'){
  // D1 batch is one serializable transaction. The applied_at latch grants exactly once.
  q.push(env.DB.prepare(`UPDATE qs_stores SET plan_id=?,subscription_state='active',paid_reference=?,expires_at=(CASE WHEN subscription_state='active' AND expires_at>? THEN expires_at ELSE ? END)+2592000,updated_at=? WHERE id=? AND owner_id=? AND status!='suspended' AND NOT EXISTS(SELECT 1 FROM qs_platform_billing_holds WHERE store_id=qs_stores.id) AND (subscription_state!='active' OR expires_at<=? OR plan_id=?) AND EXISTS(SELECT 1 FROM qs_plans WHERE id=? AND status='approved' AND cycle='month' AND price_cents=? AND product_limit=?) AND (SELECT COUNT(*) FROM qs_products WHERE store_id=qs_stores.id AND status!='archived')<=? AND EXISTS(SELECT 1 FROM qs_platform_billing_intents WHERE id=? AND state='paid' AND applied_at IS NULL AND reconcile_version=?)`).bind(i.plan_id,'shopify-platform:'+i.id,now,now,t,i.store_id,i.owner_id,now,i.plan_id,i.plan_id,access.cents,access.limit,access.limit,i.id,version));
  q.push(env.DB.prepare(`UPDATE qs_platform_billing_intents SET applied_at=?,granted_start=(SELECT expires_at-2592000 FROM qs_stores WHERE id=?),granted_end=(SELECT expires_at FROM qs_stores WHERE id=?) WHERE id=? AND reconcile_version=? AND state='paid' AND applied_at IS NULL AND EXISTS(SELECT 1 FROM qs_stores WHERE id=? AND owner_id=? AND paid_reference=?)`).bind(t,i.store_id,i.store_id,i.id,version,i.store_id,i.owner_id,'shopify-platform:'+i.id));
  q.push(env.DB.prepare("UPDATE qs_platform_billing_intents SET state='requires_attention',reason='paid_subscription_activation_requires_review' WHERE id=? AND reconcile_version=? AND state='paid' AND applied_at IS NULL").bind(i.id,version));
 }else if(['refunded','partially_refunded','cancelled','requires_attention'].includes(fin.state)){
  q.push(env.DB.prepare(`INSERT OR IGNORE INTO qs_platform_billing_holds(store_id,intent_id,reason,created_at) SELECT store_id,id,?,? FROM qs_platform_billing_intents WHERE id=? AND reconcile_version=? AND applied_at IS NOT NULL AND granted_end>?`).bind('payment_'+fin.state,t,i.id,version,now));
  q.push(env.DB.prepare("UPDATE qs_stores SET subscription_state='pending_review',updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM qs_platform_billing_holds WHERE store_id=qs_stores.id)").bind(t,i.store_id));
 }
 q.push(env.DB.prepare('INSERT INTO qs_platform_billing_log(id,intent_id,event,created_at) SELECT ?,id,?,? FROM qs_platform_billing_intents WHERE id=? AND reconcile_version=?').bind(crypto.randomUUID(),'verified:'+fin.state,t,i.id,version));await env.DB.batch(q);
 return await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(i.id).first();
}
export async function reconcilePlatform(env,i,graph){
 if(!i.draft_gid){const d=await graph(env,`query QabsPlatformRecover($q:String!){draftOrders(first:3,query:$q){nodes{${draftFields}}}}`,{q:'tag:qabs-platform-'+i.id});const matches=d.draftOrders.nodes.filter(x=>x.tags.includes('qabs-platform-'+i.id));if(matches.length!==1){await env.DB.prepare("UPDATE qs_platform_billing_intents SET state='needs_review',reason=?,updated_at=? WHERE id=? AND draft_gid IS NULL").bind(matches.length?'multiple_platform_drafts':'platform_draft_not_found_no_retry',ts(),i.id).run();return await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(i.id).first()}i=await attach(env,i,matches[0]);}
 const lock=await env.DB.prepare('UPDATE qs_platform_billing_intents SET reconcile_version=reconcile_version+1 WHERE id=? RETURNING reconcile_version').bind(i.id).first();const version=lock.reconcile_version;
 const d=(await graph(env,`query QabsPlatformDraft($id:ID!){draftOrder(id:$id){${draftFields}}}`,{id:i.draft_gid})).draftOrder;
 let fin,orderId=null;
 if(!matchingDraft(d,i))fin={state:'requires_attention',reason:'platform_draft_identity_mismatch'};
 else if(!d.order)fin={state:['OPEN','INVOICE_SENT'].includes(d.status)?'ready':'requires_attention',reason:['OPEN','INVOICE_SENT'].includes(d.status)?null:'platform_draft_status_unconfirmed'};
 else{orderId=d.order.id;if(i.order_gid&&orderId!==i.order_gid)fail('platform_order_link_conflict',409);const owner=await env.DB.prepare('SELECT email FROM qs_users WHERE id=?').bind(i.owner_id).first();if(!owner)fail('platform_owner_missing',409);const o=(await graph(env,`query QabsPlatformOrder($id:ID!){order(id:$id){${orderFields}}}`,{id:orderId})).order;fin=platformFinancialState(o,i,owner.email);}
 if(i.applied_at&&fin.state==='ready')fin={state:'requires_attention',reason:'platform_payment_evidence_regressed'};return applyState(env,i,fin,orderId,version);
}
export async function platformBillingRoute(req,env,u,{json,body,limit,graph}){
 const path=new URL(req.url).pathname;
 if(path==='/api/platform-billing/readiness'){if(req.method!=='GET')fail('method_not_allowed',405);return json(await platformReadiness(env,graph))}
 if(path==='/api/platform-billing'){
  if(req.method!=='GET')fail('method_not_allowed',405);const readiness=await platformReadiness(env,graph);return json({readiness,invoices:(await list(env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE owner_id=? ORDER BY created_at DESC LIMIT 100').bind(u.user_id))).map(view)});
 }
 if(path==='/api/platform-billing/start'){
  if(req.method!=='POST')fail('method_not_allowed',405);const b=await body(req,512);exact(b,['storeId','planId','attemptId','confirm']);if(b.confirm!==true||!UUID.test(b.storeId||'')||!UUID.test(b.attemptId||'')||!Object.hasOwn(PLATFORM_PLANS,b.planId))fail('invalid_platform_billing_request');
  const store=await ownedStore(env,b.storeId,u),p=PLATFORM_PLANS[b.planId];const existing=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE owner_id=? AND attempt_id=?').bind(u.user_id,b.attemptId).first();if(existing){if(existing.store_id!==store.id||existing.plan_id!==p.id)fail('platform_attempt_conflict',409);return json({invoice:view(existing),duplicate:true})}
  const hold=await env.DB.prepare('SELECT store_id FROM qs_platform_billing_holds WHERE store_id=?').bind(store.id).first();if(hold||store.status==='suspended')fail('platform_store_requires_review',409);if(store.subscription_state==='active'&&store.expires_at>sec()&&store.plan_id!==p.id)fail('platform_change_after_current_period',409);
  const count=await env.DB.prepare("SELECT COUNT(*) AS n FROM qs_products WHERE store_id=? AND status!='archived'").bind(store.id).first();if(count.n>p.limit)fail('platform_product_limit_exceeded',409);
  const pending=await env.DB.prepare("SELECT * FROM qs_platform_billing_intents WHERE store_id=? AND applied_at IS NULL AND state IN('creating','ready','needs_review','requires_attention')").bind(store.id).first();if(pending)return json({invoice:view(pending),duplicate:true,existingPending:true});
  const ready=await platformReadiness(env,graph);if(!ready.checkoutReady)fail('platform_shopify_not_ready',503);await limit(env,'platform-start:'+u.user_id,5);const owner=await env.DB.prepare('SELECT email FROM qs_users WHERE id=?').bind(u.user_id).first();if(!owner?.email)fail('platform_owner_missing',409);
  const id=crypto.randomUUID(),t=ts();const inserted=await env.DB.prepare("INSERT OR IGNORE INTO qs_platform_billing_intents(id,owner_id,store_id,attempt_id,plan_id,amount_cents,state,created_at,updated_at) VALUES(?,?,?,?,?,?,'creating',?,?)").bind(id,u.user_id,store.id,b.attemptId,p.id,p.cents,t,t).run();if(inserted.meta.changes!==1){const item=await env.DB.prepare("SELECT * FROM qs_platform_billing_intents WHERE (owner_id=? AND attempt_id=?) OR (store_id=? AND applied_at IS NULL AND state IN('creating','ready','needs_review','requires_attention')) ORDER BY created_at LIMIT 1").bind(u.user_id,b.attemptId,store.id).first();if(!item||item.owner_id!==u.user_id)fail('platform_invoice_conflict',409);return json({invoice:view(item),duplicate:true})}
  let i=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(id).first();
  try{const d=await graph(env,`mutation QabsPlatformInvoice($input:DraftOrderInput!){draftOrderCreate(input:$input){draftOrder{${draftFields}} userErrors{message}}}`,{input:{email:owner.email,lineItems:[{title:p.title,sku:p.sku,quantity:1,requiresShipping:false,taxable:true,originalUnitPriceWithCurrency:{amount:(p.cents/100).toFixed(2),currencyCode:'USD'}}],presentmentCurrencyCode:'USD',acceptAutomaticDiscounts:false,allowDiscountCodesInCheckout:false,tags:['qabs-platform-billing','qabs-platform-'+id],customAttributes:[{key:'qabs_platform_billing_id',value:id},{key:'qabs_platform_store_id',value:store.id},{key:'qabs_platform_plan_id',value:p.id}]}});if(d.draftOrderCreate.userErrors.length||!d.draftOrderCreate.draftOrder)fail('platform_draft_unconfirmed',503);i=await attach(env,i,d.draftOrderCreate.draftOrder);}catch{await env.DB.prepare("UPDATE qs_platform_billing_intents SET state='needs_review',reason='creation_outcome_requires_reconciliation',updated_at=? WHERE id=? AND state='creating'").bind(ts(),id).run();i=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(id).first()}
  return json({invoice:view(i),duplicate:false},201);
 }
 const m=path.match(/^\/api\/platform-billing\/([a-f0-9-]{36})\/reconcile$/);if(!m)return null;if(req.method!=='POST')fail('method_not_allowed',405);const b=await body(req,128);exact(b,['confirm']);if(b.confirm!==true)fail('confirmation_required');const i=await ownedIntent(env,m[1],u);await limit(env,'platform-reconcile:'+u.user_id,20);return json({invoice:view(await reconcilePlatform(env,i,graph))});
}
// Only invoked inside the existing HMAC-verified inbox and its signed-event retry path.
export async function platformEvent(env,gid,topic,payload,graph){
 let i=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE draft_gid=? OR order_gid=?').bind(gid,gid).first();let attributes=topic==='draft_orders/update'?payload.custom_attributes||payload.note_attributes:payload.note_attributes;
 if(!i&&!Array.isArray(attributes)&&topic!=='draft_orders/update')attributes=(await graph(env,'query QabsPlatformHint($id:ID!){order(id:$id){customAttributes{key value}}}',{id:gid})).order?.customAttributes;
 const id=Array.isArray(attributes)?attributes.find(a=>(a.key||a.name)==='qabs_platform_billing_id')?.value:null;if(!i&&UUID.test(id||''))i=await env.DB.prepare('SELECT * FROM qs_platform_billing_intents WHERE id=?').bind(id).first();
 if(i){const result=await reconcilePlatform(env,i,graph);if(!result.draft_gid)fail('platform_invoice_link_pending_retry',503)}
}

