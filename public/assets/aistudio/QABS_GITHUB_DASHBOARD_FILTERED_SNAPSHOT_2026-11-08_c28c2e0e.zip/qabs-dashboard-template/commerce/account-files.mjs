// Metadata only, strict owner scope even when the current commerce user is an admin.
const fail=(m,status=400)=>{throw Object.assign(Error(m),{status})};const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
export async function accountFilesRoute(req,e,path,h){
 if(path!=='/api/account/files')return null;if(req.method!=='GET')fail('method_not_allowed',405);
 const u=await h.identity(req,e),raw=new URL(req.url).searchParams.get('offset')||'0';if(!/^\d{1,6}$/.test(raw))fail('invalid_offset');const offset=Number(raw),limit=40;
 const sql=`SELECT 'commerce-reference' source,f.id,f.request_id,f.filename name,f.mime,f.bytes,f.created_at,r.portal_slug request_title,NULL group_id,NULL line_id,NULL purpose FROM qs_service_references f JOIN qs_service_requests r ON r.id=f.request_id WHERE f.owner_id=? AND r.owner_id=? AND f.state='ready'
 UNION ALL SELECT 'commerce-vault' source,f.id,f.group_id request_id,CASE f.purpose WHEN 'delivery' THEN 'Delivery attachment' ELSE 'Intake attachment' END name,f.mime,f.bytes,f.created_at,l.title request_title,f.group_id,f.line_id,f.purpose FROM qs_cart_documents f JOIN qs_cart_groups g ON g.id=f.group_id JOIN qs_cart_lines l ON l.id=f.line_id AND l.group_id=g.id WHERE f.owner_id=? AND g.owner_id=? AND f.group_id=g.id AND f.state='ready' AND f.expires_at>? ORDER BY 7 DESC,1,2 LIMIT ? OFFSET ?`;
 const rows=(await e.DB.prepare(sql).bind(u.user_id,u.user_id,u.user_id,u.user_id,new Date().toISOString(),limit+1,offset).all()).results;
 const files=rows.slice(0,limit).filter(f=>UUID.test(f.id)&&UUID.test(f.request_id)&&(f.source!=='commerce-vault'||UUID.test(f.group_id)&&UUID.test(f.line_id))).map(f=>({...f,download:f.source==='commerce-reference'?'/api/service-requests/'+f.request_id+'/references/'+f.id:'/api/cart-groups/'+f.group_id+'/lines/'+f.line_id+'/documents/'+f.id}));
 return h.json({files,account:{id:u.user_id,email:u.email},scope:'current_account_owner_only',malwareScanned:false,page:{offset,limit,nextOffset:rows.length>limit?offset+limit:null}});
}
