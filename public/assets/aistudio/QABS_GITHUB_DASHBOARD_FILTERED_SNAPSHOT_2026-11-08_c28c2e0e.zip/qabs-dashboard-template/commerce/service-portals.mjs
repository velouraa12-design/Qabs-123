
const STORE_BRIEF_FIELDS=Object.freeze([
{key:'package',label:'نطاق الباقة المطلوب — السعر ينتظر الاعتماد',options:['إعداد متجر فرعي','إنشاء متجر مستقل','إدارة متجر قائم']},
{key:'language',label:'لغة المتجر',options:['العربية','الإنجليزية','العربية والإنجليزية']},
{key:'market',label:'السوق الأول المستهدف',options:['السعودية','الإمارات','الكويت','قطر','البحرين','عمان','الخليج','الشرق الأوسط']},
{key:'products',label:'نوع المنتجات',options:['منتجات مادية','منتجات رقمية','خدمات','مزيج — يحتاج مراجعة']},
{key:'catalog',label:'حالة كتالوج المنتجات',options:['سأضيف المنتجات يدويًا','لدي ملف CSV','أحتاج مساعدة في تجهيز الكتالوج','أحتاج مراجعة مورد من الصين أو أمريكا']},
{key:'domain',label:'الدومين',options:['أكتفي بعنوان المتجر الفرعي','لدي دومين وأحتاج ربطه','أريد مراجعة شراء دومين']},
{key:'payment',label:'احتياج دفع مشتري المتجر',options:['لدي حساب مزود وأحتاج مراجعة الربط','أحتاج مراجعة الأهلية واختيار المزود','لم أحدد بعد']},
{key:'shipping',label:'احتياج الشحن',options:['منتجات لا تحتاج شحنًا','لدي شركة شحن','أحتاج مراجعة خيارات الشحن من الصين أو أمريكا']}
]);
import {SERVICE_PORTALS,getPortal} from './catalog.mjs';
const states='AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
export const SERVICE_FIELDS=Object.freeze({
 formation:[{key:'entity',label:'نوع الكيان',options:['LLC','CORP']},{key:'state',label:'ولاية التأسيس',options:states}],
 compliance:[{key:'service',label:'الخدمة',options:['التقرير الدوري','الوكيل المسجل','تجديد خدمة قائمة']},{key:'state',label:'الولاية',options:states}],
 stores:[{key:'service',label:'مسار المتجر',options:['متجر فرعي','إنشاء متجر مستقل','إدارة متجر قائم']},{key:'source',label:'مصدر المنتجات المستهدف',options:['يدوي','الصين','أمريكا','الصين وأمريكا']}],
 'business-payments':[{key:'service',label:'الخدمة المطلوبة',options:['مراجعة متطلبات بوابة دفع','تجهيز طلب حساب أعمال','طلب مساعدة في الربط']},{key:'provider',label:'المزود المستهدف',options:['Stripe','PayPal','PayTabs','MyFatoorah','Tap','لم أحدد بعد']}],
 branding:[{key:'service',label:'نوع التصميم',options:['شعار','هوية متكاملة','تصميم واجهة','مواد تسويقية']},{key:'language',label:'لغة الهوية',options:['العربية','الإنجليزية','العربية والإنجليزية']}],
 development:[{key:'service',label:'نوع المشروع',options:['موقع تعريفي','تطبيق ويب','لوحة تحكم','تكامل API','صيانة']},{key:'stage',label:'مرحلة المشروع',options:['فكرة جديدة','تطوير نظام قائم','معالجة مشكلة']}],
 marketing:[{key:'service',label:'الخدمة',options:['خطة تسويق','إدارة محتوى','حملات إعلانية','SEO','تقارير وتحليل']},{key:'market',label:'السوق المستهدف',options:['الخليج','الشرق الأوسط','سوق آخر']}],
 consulting:[{key:'service',label:'موضوع الجلسة',options:['التجارة الإلكترونية','تنظيم الأعمال','التخطيط لمشروع','التدريب على أدوات رقمية']},{key:'language',label:'لغة الجلسة',options:['العربية','الإنجليزية']}],
 'digital-solutions':[{key:'service',label:'نوع الطلب',options:['منتج رقمي','خدمة رقمية','اشتراك دعم','صيانة دورية']},{key:'cycle',label:'المدة المطلوبة للمراجعة',options:['مرة واحدة','شهري','سنوي']}]
});
export async function servicePortalRoute(req,env,u,helpers){
 const {json,err,body,all,limit}=helpers;const path=new URL(req.url).pathname;const method=req.method;
 if(path==='/api/service-portals'&&method==='GET'){
  const counts=await all(env.DB.prepare('SELECT portal_slug,COUNT(*) AS count FROM qs_service_requests WHERE owner_id=? GROUP BY portal_slug').bind(u.user_id));
  return json({portals:SERVICE_PORTALS.map(p=>({...p,fields:SERVICE_FIELDS[p.slug],draftCount:counts.find(c=>c.portal_slug===p.slug)?.count||0})),checkoutReady:false,providerExecutionReady:false});
 }
 if(path==='/api/admin/service-requests'&&method==='GET'){
  if(!u.is_admin)err('admin_required',403);
  const requests=await all(env.DB.prepare("SELECT id,portal_slug,selection_json,status,payment_status,created_at FROM qs_service_requests WHERE status='under_review' ORDER BY created_at DESC LIMIT 100"));
  for(const r of requests){r.selection=JSON.parse(r.selection_json);delete r.selection_json;if(r.portal_slug==='stores'){const brief=await env.DB.prepare('SELECT brief_json,revision,updated_at FROM qs_store_service_briefs WHERE request_id=?').bind(r.id).first();r.storeBrief=brief?{...JSON.parse(brief.brief_json),revision:brief.revision,updatedAt:brief.updated_at}:null}}return json({requests,executionEnabled:false});
 }

 const briefMatch=path.match(/^\/api\/service-requests\/([a-f0-9-]{36})\/store-brief$/);
 if(briefMatch){
 const row=await env.DB.prepare("SELECT id,status FROM qs_service_requests WHERE id=? AND owner_id=? AND portal_slug='stores'").bind(briefMatch[1],u.user_id).first();if(!row)err('service_request_not_found',404);
 const saved=await env.DB.prepare('SELECT brief_json,revision,updated_at FROM qs_store_service_briefs WHERE request_id=?').bind(row.id).first();
 if(method==='GET')return json({fields:STORE_BRIEF_FIELDS,brief:saved?JSON.parse(saved.brief_json):null,revision:saved?.revision||0,editable:row.status==='draft',stores:await all(env.DB.prepare('SELECT id,name,slug FROM qs_stores WHERE owner_id=? ORDER BY created_at DESC').bind(u.user_id)),priceApproved:false,checkoutReady:false,executionEnabled:false});
 if(method!=='POST')err('method_not_allowed',405);if(row.status!=='draft')err('reviewed_brief_locked',409);await limit(env,'store-brief:'+u.user_id,40);
 const b=await body(req,4096);if(!b||Object.keys(b).length!==3||!['revision','brief','confirm'].every(k=>Object.hasOwn(b,k))||b.confirm!==true||!Number.isSafeInteger(b.revision)||b.revision<0)err('invalid_store_brief');
 const v=b.brief;if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==STORE_BRIEF_FIELDS.length+1||STORE_BRIEF_FIELDS.some(f=>!f.options.includes(v[f.key]))||!Object.hasOwn(v,'storeId')||!(v.storeId===null||typeof v.storeId==='string'&&/^[a-f0-9-]{36}$/.test(v.storeId)))err('invalid_store_brief');
 if(v.storeId&&!await env.DB.prepare('SELECT id FROM qs_stores WHERE id=? AND owner_id=?').bind(v.storeId,u.user_id).first())err('store_not_found',404);
 if(b.revision!==(saved?.revision||0))err('brief_revision_conflict',409);
 const canonical=JSON.stringify({...Object.fromEntries(STORE_BRIEF_FIELDS.map(f=>[f.key,v[f.key]])),storeId:v.storeId}),stamp=new Date().toISOString();
 const q=await env.DB.prepare("INSERT INTO qs_store_service_briefs(request_id,brief_json,revision,updated_at) SELECT ?,?,1,? WHERE ?=0 AND EXISTS(SELECT 1 FROM qs_service_requests WHERE id=? AND owner_id=? AND status='draft') ON CONFLICT(request_id) DO UPDATE SET brief_json=excluded.brief_json,revision=qs_store_service_briefs.revision+1,updated_at=excluded.updated_at WHERE qs_store_service_briefs.revision=? AND EXISTS(SELECT 1 FROM qs_service_requests WHERE id=? AND owner_id=? AND status='draft')").bind(row.id,canonical,stamp,saved?0:b.revision,row.id,u.user_id,b.revision,row.id,u.user_id).run();
 if(q.meta.changes!==1)err('brief_revision_conflict',409);return json({saved:true,revision:b.revision+1,paymentConfirmed:false,executionStarted:false});
 }
 let match=path.match(/^\/api\/service-portals\/([a-z-]+)(?:\/(drafts))?$/);
 if(match){
  const portal=getPortal(match[1]);if(!portal)err('service_not_found',404);
  if(!match[2]&&method==='GET'){
   const requests=await all(env.DB.prepare('SELECT id,portal_slug,selection_json,status,payment_status,created_at,updated_at FROM qs_service_requests WHERE owner_id=? AND portal_slug=? ORDER BY created_at DESC LIMIT 100').bind(u.user_id,portal.slug));
   return json({portal,fields:SERVICE_FIELDS[portal.slug],requests:requests.map(r=>({...r,selection:JSON.parse(r.selection_json),selection_json:undefined})),checkoutReady:false,providerExecutionReady:false,documentsReady:false,referenceUploadsReady:!!env.IMAGES});
  }
  if(match[2]&&method==='POST'){
   await limit(env,'service-draft:'+u.user_id,30);const b=await body(req,4096);
   if(!b||Object.keys(b).some(k=>!['selection','attemptId'].includes(k))||!b.selection||typeof b.selection!=='object'||Array.isArray(b.selection))err('invalid_service_draft');
   if(!/^[a-f0-9-]{36}$/.test(b.attemptId||''))err('invalid_attempt_id');
   const fields=SERVICE_FIELDS[portal.slug];if(Object.keys(b.selection).length!==fields.length||fields.some(f=>!f.options.includes(b.selection[f.key])))err('invalid_service_selection');
   const existing=await env.DB.prepare('SELECT id,portal_slug,selection_json FROM qs_service_requests WHERE owner_id=? AND attempt_id=?').bind(u.user_id,b.attemptId).first();
   const selection=JSON.stringify(Object.fromEntries(fields.map(f=>[f.key,b.selection[f.key]])));
   if(existing){if(existing.portal_slug!==portal.slug||existing.selection_json!==selection)err('attempt_conflict',409);return json({id:existing.id,duplicate:true,paymentConfirmed:false},200)}
   const id=crypto.randomUUID(),stamp=new Date().toISOString();
   await env.DB.batch([env.DB.prepare("INSERT INTO qs_service_requests(id,owner_id,portal_slug,selection_json,attempt_id,status,payment_status,created_at,updated_at) VALUES(?,?,?,?,?,'draft','unpaid',?,?)").bind(id,u.user_id,portal.slug,selection,b.attemptId,stamp,stamp),env.DB.prepare("INSERT INTO qs_service_events(id,request_id,kind,created_at) VALUES(?,?,'draft_created',?)").bind(crypto.randomUUID(),id,stamp)]);
   return json({id,status:'draft',paymentConfirmed:false},201);
  }
  err('method_not_allowed',405);
 }
 match=path.match(/^\/api\/service-requests\/([a-f0-9-]{36})(?:\/(review))?$/);
 if(match){
  const row=await env.DB.prepare('SELECT id,portal_slug,selection_json,status,payment_status,created_at,updated_at FROM qs_service_requests WHERE id=? AND owner_id=?').bind(match[1],u.user_id).first();if(!row)err('service_request_not_found',404);
  if(!match[2]&&method==='GET')return json({request:{...row,selection:JSON.parse(row.selection_json),selection_json:undefined},events:await all(env.DB.prepare('SELECT kind,created_at FROM qs_service_events WHERE request_id=? ORDER BY created_at,id').bind(row.id)),paymentConfirmed:false});
  if(match[2]&&method==='POST'){
   const b=await body(req,512);if(!b||Object.keys(b).length!==1||b.confirm!==true)err('review_confirmation_required');if(row.status!=='draft')err('review_already_requested',409);
   if(row.portal_slug==='stores'&&!await env.DB.prepare('SELECT request_id FROM qs_store_service_briefs WHERE request_id=?').bind(row.id).first())err('store_brief_required',409);
   const stamp=new Date().toISOString();
   const transaction=await env.DB.batch([env.DB.prepare("UPDATE qs_service_requests SET status='under_review',updated_at=? WHERE id=? AND owner_id=? AND status='draft'").bind(stamp,row.id,u.user_id),env.DB.prepare("INSERT INTO qs_service_events(id,request_id,kind,created_at) SELECT ?,?,'review_requested',? WHERE changes()=1").bind(crypto.randomUUID(),row.id,stamp)]);if(transaction[0]?.meta?.changes!==1)err('review_already_requested',409);
   return json({id:row.id,status:'under_review',paymentConfirmed:false,executionStarted:false});
  }
  err('method_not_allowed',405);
 }
 err('service_not_found',404);
}

