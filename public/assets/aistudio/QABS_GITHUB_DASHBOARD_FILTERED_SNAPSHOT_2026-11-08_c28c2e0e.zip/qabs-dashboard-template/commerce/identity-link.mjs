// Explicit account linking only: never match or merge by email.
const bad=(code,status=400)=>{throw Object.assign(Error(code),{status})};
const clock=()=>Math.floor(Date.now()/1000);
const sha=async s=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const token=req=>(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('qs_session='))?.slice(11);
const workspaceToken=req=>(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('__Host-qdp_session='))?.slice(19);
const cookieValue=t=>`qs_session=${t}; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600`;
const one=(e,s,...a)=>e.DB.prepare(s).bind(...a).first();
const objectBody=async(req,h,max)=>{const d=await h.body(req,max);if(!d||typeof d!=='object'||Array.isArray(d))bad('invalid_fields');return d;};
async function workspace(req,e,proof=false,verifiedRequired=true){
 if(!e.STUDIO?.fetch)bad('identity_service_unavailable',503);
 const h=new Headers();h.set('Cookie',req.headers.get('Cookie')||'');
 if(proof){h.set('Origin',e.APP_ORIGIN);h.set('Content-Type','application/json');h.set('X-CSRF-Token',req.headers.get('X-Workspace-CSRF')||'');}
 const r=await e.STUDIO.fetch(new Request(e.APP_ORIGIN+(proof?'/workspace/api/identity-link/proof':'/workspace/api/me'),{method:proof?'POST':'GET',headers:h,...(proof?{body:'{}'}:{})}));
 if(!r.ok){if(r.status===401)bad('workspace_signin_required',401);if(r.status===403)bad('workspace_reauthentication_required',403);bad('identity_service_unavailable',503);}
 const u=await r.json();if(!proof){const mh=new Headers();mh.set('Cookie',req.headers.get('Cookie')||'');const mr=await e.STUDIO.fetch(new Request(e.APP_ORIGIN+'/workspace/api/settings/security',{headers:mh}));if(!mr.ok)bad('identity_service_unavailable',503);u.mfaEnabled=!!(await mr.json()).enabled;}if(typeof u.id!=='string'||typeof u.csrf!=='string'||(verifiedRequired&&!u.emailVerified))bad('verified_workspace_account_required',403);return u;
}
const credential=async(e,id)=>{const p=await one(e,'SELECT hash FROM qs_password_credentials WHERE user_id=?',id);return sha(p?.hash||'no-password');};
function origin(req,e){if(req.headers.get('Origin')!==e.APP_ORIGIN)bad('origin_rejected',403);}
function studioCSRF(req,u){if(req.headers.get('X-CSRF-Token')!==u.csrf)bad('csrf_rejected',403);}
async function linkFor(e,id){return one(e,'SELECT * FROM qabs_identity_links WHERE studio_user_id=?',id);}
async function validLink(e,u){const l=await linkFor(e,u.id);if(!l)bad('account_link_required',409);const owner=await one(e,'SELECT email FROM qs_users WHERE id=?',l.commerce_user_id);if(!owner)bad('commerce_account_missing',401);if(e.ADMIN_EMAIL&&owner.email.toLowerCase()===e.ADMIN_EMAIL.toLowerCase()&&!u.mfaEnabled)bad('workspace_mfa_required_for_admin_link',403);if(l.credential_fingerprint!==await credential(e,l.commerce_user_id))bad('commerce_credentials_changed_relink_required',403);return l;}
export async function assertWorkspaceSession(req,e,s){
 const method=await one(e,'SELECT auth_method FROM qs_session_security WHERE hash=?',s.hash);if(method?.auth_method!=='workspace_link')return;
 if(e.IDENTITY_LINK_ENABLED!=='true')bad('workspace_session_unavailable',503);
 const b=await one(e,'SELECT * FROM qs_workspace_sessions WHERE commerce_session_hash=?',s.hash);if(!b)bad('authentication_required',401);
 const u=await workspace(req,e),l=await validLink(e,u),qdp=workspaceToken(req);
 if(!qdp||!/^[a-f0-9]{64}$/.test(qdp)||b.studio_session_hash!==await sha(qdp)||b.studio_user_id!==u.id||l.commerce_user_id!==s.user_id)bad('authentication_required',401);
}
export async function identityLinkRoute(req,e,path,h){
 if(!path.startsWith('/api/identity-link')&&path!=='/api/auth/workspace-session')return null;
 if(e.IDENTITY_LINK_ENABLED!=='true')return h.json({enabled:false,linked:false,error:'identity_link_not_enabled'},path==='/api/identity-link'&&req.method==='GET'?200:503);
 const method=req.method;if(!['GET','POST'].includes(method))bad('method_not_allowed',405);
 if(method==='POST')origin(req,e);
 if(path==='/api/identity-link'&&method==='GET'){
  const u=await workspace(req,e),l=await linkFor(e,u.id);let native=null;
  try{native=await h.identity(req,e)}catch(error){if(error.status!==401&&error.status!==403)throw error;}
  const linked=!!l;
  const linkedUser=linked?await one(e,'SELECT email FROM qs_users WHERE id=?',l.commerce_user_id):null;
  const admin=!!(linkedUser&&e.ADMIN_EMAIL&&linkedUser.email.toLowerCase()===e.ADMIN_EMAIL.toLowerCase());
  const valid=!!(linkedUser&&(!admin||u.mfaEnabled)&&l.credential_fingerprint===await credential(e,l.commerce_user_id));
  return h.json({enabled:true,linked,valid,workspaceEmail:u.email,commerceEmail:linkedUser?.email||native?.email||null,commerceSignedIn:!!native,commerceCSRF:native?.csrf||null,accountConflict:!!l&&!!native&&native.user_id!==l.commerce_user_id,automaticEmailMatching:false});
 }
 if(path==='/api/identity-link/link'&&method==='POST'){
  const native=await h.identity(req,e),data=await objectBody(req,h,2048);
  if(Object.keys(data).some(k=>!['confirm','current_password'].includes(k))||data.confirm!==true)bad('explicit_confirmation_required');
  await h.limit(e,'identity-link:'+native.user_id,8);
  const verified=await workspace(req,e,true);
  if(native.is_admin&&!verified.mfaEnabled)bad('workspace_mfa_required_for_admin_link',403);
  const security=await one(e,'SELECT email_verified_at FROM qs_session_security WHERE hash=?',native.hash),p=await one(e,'SELECT salt,hash,iterations FROM qs_password_credentials WHERE user_id=?',native.user_id);
  const fresh=security?.email_verified_at>clock()-300;
  if(!fresh&&!await h.passwordMatches(typeof data.current_password==='string'&&data.current_password.length<=128?data.current_password:'',p))bad('commerce_reauthentication_required',403);
  const fingerprint=await credential(e,native.user_id),now=new Date().toISOString();
  const a=await linkFor(e,verified.id),b=await one(e,'SELECT studio_user_id FROM qabs_identity_links WHERE commerce_user_id=?',native.user_id);
  if(a&&a.commerce_user_id!==native.user_id||b&&b.studio_user_id!==verified.id)bad('account_already_linked',409);
  // A different account is never substituted by an upsert.
  try{await e.DB.prepare('INSERT INTO qabs_identity_links(studio_user_id,commerce_user_id,credential_fingerprint,linked_at) VALUES(?,?,?,?) ON CONFLICT(studio_user_id) DO UPDATE SET credential_fingerprint=excluded.credential_fingerprint WHERE qabs_identity_links.commerce_user_id=excluded.commerce_user_id').bind(verified.id,native.user_id,fingerprint,now).run()}catch(error){if(/unique constraint/i.test(error.message||''))bad('account_already_linked',409);throw error;}
  const saved=await linkFor(e,verified.id);if(saved?.commerce_user_id!==native.user_id)bad('link_not_confirmed',409);
  return h.json({linked:true,merged:false,requiresNextWorkspaceSignIn:false});
 }
 if(path==='/api/auth/workspace-session'&&method==='POST'){
  const u=await workspace(req,e);studioCSRF(req,u);const data=await objectBody(req,h,256);if(Object.keys(data).length)bad('invalid_fields');await h.limit(e,'workspace-session:'+u.id,30);
  const l=await validLink(e,u),qdp=workspaceToken(req);if(!/^[a-f0-9]{64}$/.test(qdp||''))bad('workspace_signin_required',401);
  const oldToken=token(req);if(/^[a-f0-9]{64}$/.test(oldToken||'')){
   const s=await one(e,'SELECT s.*,u.email FROM qs_sessions s JOIN qs_users u ON u.id=s.user_id WHERE s.hash=? AND s.expires_at>?',await sha(oldToken),clock());
   if(s){if(s.user_id!==l.commerce_user_id)bad('commerce_account_conflict',409);try{await assertWorkspaceSession(req,e,s);return h.json({authenticated:true,existingSession:true})}catch(error){if(error.status!==401&&error.status!==403)throw error;}}
  }
  const raw=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-',''),hash=await sha(raw),csrf=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-',''),fingerprint=await sha(qdp);
  await e.DB.batch([
   e.DB.prepare('INSERT INTO qs_sessions(hash,user_id,csrf,expires_at) VALUES(?,?,?,?)').bind(hash,l.commerce_user_id,csrf,clock()+3600),
   e.DB.prepare("INSERT INTO qs_session_security(hash,auth_method,email_verified_at) VALUES(?,'workspace_link',NULL)").bind(hash),
   e.DB.prepare('INSERT INTO qs_workspace_sessions(commerce_session_hash,studio_session_hash,studio_user_id,created_at) VALUES(?,?,?,?)').bind(hash,fingerprint,u.id,new Date().toISOString())
  ]);
  return h.json({authenticated:true,linkedSession:true},200,{'Set-Cookie':cookieValue(raw)});
 }
 if(path==='/api/identity-link/unlink'&&method==='POST'){
  const u=await workspace(req,e);studioCSRF(req,u);const data=await objectBody(req,h,256);if(Object.keys(data).some(k=>k!=='confirm')||data.confirm!==true)bad('explicit_confirmation_required');
  const check=new Request(e.APP_ORIGIN+'/api/identity-link/unlink',{method:'POST',headers:new Headers(req.headers),body:'{}'});check.headers.set('X-Workspace-CSRF',u.csrf);const verified=await workspace(check,e,true);if(verified.id!==u.id)bad('account_changed',409);
  await e.DB.batch([
   e.DB.prepare('DELETE FROM qs_sessions WHERE hash IN (SELECT commerce_session_hash FROM qs_workspace_sessions WHERE studio_user_id=?)').bind(u.id),
   e.DB.prepare('DELETE FROM qs_workspace_sessions WHERE studio_user_id=?').bind(u.id),
   e.DB.prepare('DELETE FROM qabs_identity_links WHERE studio_user_id=?').bind(u.id)
  ]);return h.json({unlinked:true,customerDataDeleted:false},200,{'Set-Cookie':'qs_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
 }
 bad('not_found',404);
}
export async function workspaceLogout(req,e){
 if(new URL(req.url).pathname!=='/workspace/api/auth/logout'||req.method!=='POST')return null;
 origin(req,e);const u=await workspace(req,e,false,false);studioCSRF(req,u);
 const t=token(req);if(/^[a-f0-9]{64}$/.test(t||''))await e.DB.prepare('DELETE FROM qs_sessions WHERE hash=?').bind(await sha(t)).run();
 const r=await e.STUDIO.fetch(req),headers=new Headers(r.headers);headers.append('Set-Cookie','qs_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return new Response(r.body,{status:r.status,headers});
}
