const origin='https://portal.qabs1.store';
const migrationHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Qabs-Workspace':'studio-relocated-v1'};
const redirect=to=>new Response(null,{status:302,headers:{...migrationHeaders,Location:to}});
export async function workspaceGateway(req,env){
 const u=new URL(req.url),isWorkspace=u.pathname==='/workspace'||u.pathname.startsWith('/workspace/'),isLogin=u.pathname==='/login'&&u.searchParams.get('portal')!=='commerce';
 if(!isWorkspace&&!isLogin)return null;
 if(!env.STUDIO?.fetch)return new Response('Workspace temporarily unavailable',{status:503,headers:migrationHeaders});
 if(isLogin&&!['GET','HEAD'].includes(req.method))return new Response(null,{status:405,headers:migrationHeaders});
 if(isWorkspace&&['/workspace','/workspace/','/workspace/dashboard','/workspace/login','/workspace/signup'].includes(u.pathname)&&['GET','HEAD'].includes(req.method)){
  const check=new URL('/workspace/api/me',origin);const session=await env.STUDIO.fetch(new Request(check,{headers:req.headers,method:'GET'}));
  if(session.status===401)return redirect('/login?portal=workspace');
  if(!session.ok)return new Response('Session verification unavailable',{status:503,headers:migrationHeaders});
 }
 const upstream=new URL(req.url);if(isLogin){upstream.pathname='/workspace/login';upstream.search='';}
 const formation=/^\/workspace\/formation(?:[/.]|$)/.test(upstream.pathname);const fetcher=formation?env.FORMATION:env.STUDIO;if(!fetcher?.fetch)return new Response('Section temporarily unavailable',{status:503,headers:migrationHeaders});const res=await fetcher.fetch(new Request(upstream,req.method==='HEAD'?{method:'GET',headers:req.headers}:req)),h=new Headers(res.headers);h.set('Cache-Control','no-store');h.set('X-Qabs-Workspace','studio-relocated-v1');
 const rewrite=v=>v.replaceAll('/studio','/workspace');
 const location=h.get('Location');if(location)h.set('Location',rewrite(location));
 const type=h.get('Content-Type')||'';
 if(req.method==='HEAD')return new Response(null,{status:res.status,headers:h});
 if(!/(?:text\/|javascript|application\/json|svg\+xml)/i.test(type))return new Response(res.body,{status:res.status,headers:h});
 let text=await res.text();if(type.includes('application/json')){const urlKeys=new Set(['url','href','location','preview_url','editor_url','download_url','asset_url','public_url','previewUrl','editorUrl','downloadUrl']);const visit=(v,key)=>{if(typeof v==='string')return urlKeys.has(key)&&(v.startsWith('/studio')||v.startsWith(origin+'/studio'))?rewrite(v):v;if(Array.isArray(v))return v.map(x=>visit(x,key));if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,visit(x,k)]));return v;};try{text=JSON.stringify(visit(JSON.parse(text),''))}catch{}}else{text=rewrite(text)}
 if(type.includes('javascript')&&u.pathname==='/workspace/app.js')text+=`
;(()=>{if(location.pathname==='/login'&&new URLSearchParams(location.hash.slice(1)).has('token')){location.replace('/login?portal=commerce'+location.hash);return}const toHome=()=>{if(currentUser&&location.pathname==='/login'){const hash=location.hash.startsWith('#/')?location.hash:'#/home';location.replace('/workspace'+hash)}};const oldShow=show;show=function(...args){toHome();return oldShow.apply(this,args)};toHome()})();
`;
 // Preserve the distinct commerce login required by original merchant API actions.
 if(type.includes('javascript'))text=text.replaceAll('/login?next=', '/login?portal=commerce&next=').replaceAll('href="/login"','href="/login?portal=commerce"');
 h.delete('Content-Length');h.delete('Content-Encoding');h.delete('ETag');
 return new Response(text,{status:res.status,headers:h});
}
