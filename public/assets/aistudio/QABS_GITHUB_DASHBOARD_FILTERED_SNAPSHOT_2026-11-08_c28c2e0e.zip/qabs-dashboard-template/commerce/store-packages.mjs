import {PRODUCT_CATALOG,PRODUCT_CATALOG_DATE} from './catalog.mjs';
import {catalogCheckout} from './shopify-invoices.mjs';
import {PRODUCTS,directServiceCheckout} from './shopify-invoices.mjs';
import {SERVICE_FIELDS} from './service-portals.mjs';
const sources=SERVICE_FIELDS.stores.find(f=>f.key==='source').options;
const validId=v=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(v);
const product=k=>typeof k==='string'&&Object.hasOwn(PRODUCTS,k);
function fail(code,status=400){throw Object.assign(Error(code),{status})}
function exact(v,keys){if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('invalid_package_request')}
function pack(key){const p=PRODUCTS[key];return{key,title:p.title,amount_cents:p.cents,currency:'USD',cycle:'once',independentStoreOnly:true,requiresApprovedQuote:true}}
export async function storePackageRoute(req,env,u,{json,body,limit}){
 const path=new URL(req.url).pathname,method=req.method;
 if(path==='/api/store-service-packages/checkout'){if(method!=='POST')fail('method_not_allowed',405);const b=await body(req,256);exact(b,['productKey','confirm']);if(!product(b.productKey)||b.confirm!==true)fail('invalid_package_request');await limit(env,'store-direct-checkout:'+u.user_id,20);return json(await directServiceCheckout(env,b.productKey));}

 if(path==='/api/store-service-packages'){
  if(method==='GET')return json({packages:Object.keys(PRODUCTS).map(pack),sources,automaticCollection:false,automaticFulfillment:false,directCheckoutSupported:true});
  if(method!=='POST')fail('method_not_allowed',405);
  const b=await body(req,2048);exact(b,['productKey','source','attemptId','confirmReviewOnly']);
  if(!product(b.productKey)||!sources.includes(b.source)||!validId(b.attemptId)||b.confirmReviewOnly!==true)fail('invalid_package_request');
  await limit(env,'service-draft:'+u.user_id,30);
  const selection=JSON.stringify({service:'إنشاء متجر مستقل',source:b.source});
  async function duplicate(){const row=await env.DB.prepare('SELECT r.id,r.portal_slug,r.selection_json,r.status,p.product_key FROM qs_service_requests r LEFT JOIN qs_store_package_preferences p ON p.request_id=r.id WHERE r.owner_id=? AND r.attempt_id=?').bind(u.user_id,b.attemptId).first();if(!row)return null;if(row.portal_slug!=='stores'||row.selection_json!==selection||row.product_key!==b.productKey)fail('attempt_conflict',409);return json({id:row.id,duplicate:true,status:row.status,paymentCreated:false,executionStarted:false})}
  const existing=await duplicate();if(existing)return existing;
  const id=crypto.randomUUID(),stamp=new Date().toISOString();
  try{await env.DB.batch([
   env.DB.prepare("INSERT INTO qs_service_requests(id,owner_id,portal_slug,selection_json,attempt_id,status,payment_status,created_at,updated_at) VALUES(?,?,'stores',?,?,'draft','unpaid',?,?)").bind(id,u.user_id,selection,b.attemptId,stamp,stamp),
   env.DB.prepare("INSERT INTO qs_service_events(id,request_id,kind,created_at) VALUES(?,?,'draft_created',?)").bind(crypto.randomUUID(),id,stamp),
   env.DB.prepare('INSERT INTO qs_store_package_preferences(request_id,product_key,revision,created_at,updated_at) VALUES(?,?,1,?,?)').bind(id,b.productKey,stamp,stamp)
  ])}catch(e){const existing=await duplicate();if(existing)return existing;throw e}
  return json({id,status:'draft',package:pack(b.productKey),paymentCreated:false,executionStarted:false},201);
 }
 const m=path.match(/^\/api\/service-requests\/([a-f0-9-]{36})\/store-package$/);if(!m)return null;
 const row=await env.DB.prepare('SELECT id,owner_id,portal_slug,selection_json,status FROM qs_service_requests WHERE id=?').bind(m[1]).first();
 if(!row||row.portal_slug!=='stores'||JSON.parse(row.selection_json).service!=='إنشاء متجر مستقل'||(row.owner_id!==u.user_id&&!u.is_admin))fail('service_request_not_found',404);
 const saved=await env.DB.prepare('SELECT product_key,revision FROM qs_store_package_preferences WHERE request_id=?').bind(row.id).first();
 if(method==='GET')return json({package:saved?pack(saved.product_key):null,revision:saved?.revision||0,editable:row.status==='draft'&&row.owner_id===u.user_id,packages:Object.keys(PRODUCTS).map(pack),paymentCreated:false});
 if(method!=='PUT')fail('method_not_allowed',405);if(row.owner_id!==u.user_id)fail('owner_confirmation_required',403);if(row.status!=='draft')fail('reviewed_brief_locked',409);
 const b=await body(req,512);exact(b,['productKey','revision','confirmReviewOnly']);if(!product(b.productKey)||!Number.isSafeInteger(b.revision)||b.revision<0||b.confirmReviewOnly!==true)fail('invalid_package_request');if(b.revision!==(saved?.revision||0))fail('brief_revision_conflict',409);
 await limit(env,'store-package:'+u.user_id,40);const stamp=new Date().toISOString();
 const update=await env.DB.prepare("INSERT INTO qs_store_package_preferences(request_id,product_key,revision,created_at,updated_at) SELECT ?,?,1,?,? WHERE ?=0 AND EXISTS(SELECT 1 FROM qs_service_requests WHERE id=? AND owner_id=? AND status='draft') ON CONFLICT(request_id) DO UPDATE SET product_key=excluded.product_key,revision=qs_store_package_preferences.revision+1,updated_at=excluded.updated_at WHERE qs_store_package_preferences.revision=? AND EXISTS(SELECT 1 FROM qs_service_requests WHERE id=? AND owner_id=? AND status='draft')").bind(row.id,b.productKey,stamp,stamp,saved?0:b.revision,row.id,u.user_id,b.revision,row.id,u.user_id).run();
 if(update.meta.changes!==1)fail('brief_revision_conflict',409);return json({saved:true,revision:b.revision+1,paymentCreated:false,executionStarted:false});
}

export async function productCatalogRoute(req,env,u,{json,body,limit}){
 const path=new URL(req.url).pathname;
 if(path==='/api/product-catalog'){
  if(req.method!=='GET')fail('method_not_allowed',405);
  return json({products:PRODUCT_CATALOG.map(({descriptionHash,...p})=>p),snapshotDate:PRODUCT_CATALOG_DATE,currency:'USD',automaticRenewal:false,portalPaymentConfirmed:false});
 }
 if(!['/api/product-catalog/checkout','/api/product-catalog/requests'].includes(path))return null;
 if(req.method!=='POST')fail('method_not_allowed',405);
 const b=await body(req,2048),checkout=path.endsWith('/checkout');exact(b,checkout?['handle','variantId','confirm']:['handle','variantId','attemptId','confirmReviewOnly']);
 const p=PRODUCT_CATALOG.find(p=>p.handle===b.handle),v=p?.variants.find(v=>v.id===b.variantId);
 if(!p||!v)fail('catalog_product_not_found',404);
 if(checkout){if(b.confirm!==true)fail('catalog_confirmation_required');await limit(env,'catalog-checkout:'+u.user_id,20);return json(await catalogCheckout(env,p.handle,v.id));}
 if(b.confirmReviewOnly!==true||!validId(b.attemptId))fail('invalid_catalog_request');
 await limit(env,'service-draft:'+u.user_id,30);
 const selection=JSON.stringify({'المنتج المختار':p.title,'مرجع الكتالوج':p.handle,'الخيار':v.title,'السعر المرجعي USD':(v.cents/100).toFixed(2),'نوع الطلب':'مراجعة النطاق والأهلية والرسوم قبل الدفع'});
 async function existing(){const r=await env.DB.prepare('SELECT id,portal_slug,selection_json,status FROM qs_service_requests WHERE owner_id=? AND attempt_id=?').bind(u.user_id,b.attemptId).first();if(!r)return null;if(r.portal_slug!==p.portal||r.selection_json!==selection)fail('attempt_conflict',409);return json({id:r.id,status:r.status,duplicate:true,paymentCreated:false,executionStarted:false});}
 const prior=await existing();if(prior)return prior;
 const id=crypto.randomUUID(),stamp=new Date().toISOString();
 try{await env.DB.batch([env.DB.prepare("INSERT INTO qs_service_requests(id,owner_id,portal_slug,selection_json,attempt_id,status,payment_status,created_at,updated_at) VALUES(?,?,?,?,?,'draft','unpaid',?,?)").bind(id,u.user_id,p.portal,selection,b.attemptId,stamp,stamp),env.DB.prepare("INSERT INTO qs_service_events(id,request_id,kind,created_at) VALUES(?,?,'draft_created',?)").bind(crypto.randomUUID(),id,stamp)])}catch(e){const dupe=await existing();if(dupe)return dupe;throw e}
 return json({id,status:'draft',paymentCreated:false,executionStarted:false},201);
}

