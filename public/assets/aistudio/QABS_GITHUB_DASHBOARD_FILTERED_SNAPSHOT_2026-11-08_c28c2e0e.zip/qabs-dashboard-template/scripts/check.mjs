import {readdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
let count=0;
async function walk(dir){for(const f of await readdir(dir,{withFileTypes:true})){if(f.name.startsWith('.')||f.name==='node_modules')continue;const path=dir+'/'+f.name;if(f.isDirectory())await walk(path);else if(/\.(mjs|js)$/.test(f.name)){const p=spawnSync(process.execPath,['--check',path],{encoding:'utf8'});if(p.status!==0){console.error(path,p.stderr);process.exit(1)}count++}}}
await walk('.');console.log(`Syntax OK: ${count} JavaScript files`);
