import {emailChangeReady} from './email-change.mjs';
import {extraSettings} from './settings-extra.mjs';
const profileDefaults={first_name:'',last_name:'',phone:'',country:'',city:'',bio:''};
const preferenceDefaults={language:'ar',timezone:'Asia/Aden',date_format:'dmy',theme:'dark',accent:'emerald',font_size:'normal'};
export async function settingsRoute(req,env,path,h){
 if(!path.startsWith('/api/settings'))return null;
 const {u,json,fail,keys,read,rate,digest,hex,ITER,clock}=h;
 const q=async(sql,...args)=>env.DB.prepare(sql).bind(...args).first();
 const unpack=r=>({profile:{...profileDefaults,...r?JSON.parse(r.profile_json):{}},preferences:{...preferenceDefaults,...r?JSON.parse(r.preferences_json):{}},revision:r?.revision||0,updated_at:r?.updated_at||null});
 const extra=await extraSettings(req,env,path,h);if(extra)return extra;
 const capabilities={profile:true,language:true,appearance:true,passwordChange:true,sessionList:true,revokeOtherSessions:true,emailChange:emailChangeReady(env),avatarUpload:false,twoFactor:true,notifications:true,knowledge:true,export:true,accountDeletion:false,deletionRequest:true,supportTickets:true};
 if(path==='/api/settings'&&req.method==='GET'){
  const row=await q('SELECT profile_json,preferences_json,revision,updated_at FROM account_settings WHERE user_id=?',u.id);
  const sessions=(await env.DB.prepare('SELECT hash,expires_at FROM sessions WHERE user_id=? AND expires_at>? ORDER BY expires_at DESC LIMIT 51').bind(u.id,clock()).all()).results;
  return json({account:{id:u.id,email:u.email,emailVerified:!!u.email_verified},settings:unpack(row),sessions:sessions.slice(0,50).map(s=>({current:s.hash===u.hash,expires_at:new Date(s.expires_at*1000).toISOString()})),sessionsLimited:sessions.length>50,capabilities});
 }
 if(path==='/api/settings'&&req.method==='PUT'){
  await rate(env,'settings-write:'+u.id,90);const b=keys(await read(req,16000),['revision','profile','preferences']);if(!Number.isSafeInteger(b.revision)||b.revision<0)fail('invalid_revision');
  const profile=keys(b.profile,Object.keys(profileDefaults)),preferences=keys(b.preferences,Object.keys(preferenceDefaults));
  for(const [k,max]of Object.entries({first_name:80,last_name:80,phone:40,country:80,city:100,bio:1000})){if(typeof profile[k]!=='string'||profile[k].length>max||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(profile[k]))fail('invalid_profile');profile[k]=profile[k].trim()}
  const options={language:['ar','en'],date_format:['dmy','mdy','iso'],theme:['dark','light','system'],accent:['emerald','blue','violet','rose','amber'],font_size:['normal','large']};for(const [k,allowed]of Object.entries(options))if(!allowed.includes(preferences[k]))fail('invalid_preferences');
  if(typeof preferences.timezone!=='string'||preferences.timezone.length>80)fail('invalid_timezone');try{new Intl.DateTimeFormat('en',{timeZone:preferences.timezone}).format()}catch{fail('invalid_timezone')}
  const existing=await q('SELECT revision FROM account_settings WHERE user_id=?',u.id);if((existing?.revision||0)!==b.revision)fail('revision_conflict',409);const t=new Date().toISOString(),result=await env.DB.prepare('INSERT INTO account_settings(user_id,profile_json,preferences_json,revision,updated_at) VALUES(?,?,?,1,?) ON CONFLICT(user_id) DO UPDATE SET profile_json=excluded.profile_json,preferences_json=excluded.preferences_json,revision=account_settings.revision+1,updated_at=excluded.updated_at WHERE account_settings.revision=? RETURNING profile_json,preferences_json,revision,updated_at').bind(u.id,JSON.stringify(profile),JSON.stringify(preferences),t,b.revision).all();
  // Existing stale writes are rejected; new rows must start at revision 0.
  if(!result.results?.length)fail('revision_conflict',409);return json({saved:true,settings:unpack(result.results[0])});
 }
 if(path==='/api/settings/password'&&req.method==='POST'){
  await rate(env,'settings-password:'+u.id,6);const b=keys(await read(req,2048),['current_password','new_password']);if(typeof b.current_password!=='string'||b.current_password.length>128||typeof b.new_password!=='string'||b.new_password.length<12||b.new_password.length>128||b.new_password===b.current_password)fail('invalid_password');
  const row=await q('SELECT password_hash,salt FROM users WHERE id=?',u.id),candidate=await digest(b.current_password,row.salt);let mismatch=0;for(let i=0;i<64;i++)mismatch|=candidate.charCodeAt(i)^row.password_hash.charCodeAt(i);if(mismatch)fail('current_password_incorrect',403);
  const salt=hex(crypto.getRandomValues(new Uint8Array(16))),value=await digest(b.new_password,salt),guard='EXISTS(SELECT 1 FROM users WHERE id=? AND password_hash=?)';
  const statements=[env.DB.prepare('UPDATE users SET password_hash=?,salt=?,iterations=? WHERE id=? AND password_hash=? RETURNING id').bind(value,salt,ITER,u.id,row.password_hash),env.DB.prepare('DELETE FROM sessions WHERE user_id=? AND '+guard).bind(u.id,u.id,value),env.DB.prepare('DELETE FROM password_reset_tokens WHERE user_id=? AND '+guard).bind(u.id,u.id,value),env.DB.prepare('DELETE FROM email_login_challenges WHERE email=? AND '+guard).bind(u.email,u.id,value)];
  const result=await env.DB.batch(statements);if(!result[0].results?.length)fail('revision_conflict',409);return json({saved:true,signedOut:true},200,{'Set-Cookie':'__Host-qdp_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
 }
 if(path==='/api/settings/sessions/revoke-others'&&req.method==='POST'){
  await rate(env,'settings-revoke:'+u.id,20);keys(await read(req,512),[]);await env.DB.prepare('DELETE FROM sessions WHERE user_id=? AND hash<>?').bind(u.id,u.hash).run();return json({saved:true,currentSessionPreserved:true});
 }
 fail('method_not_allowed',405);
}
