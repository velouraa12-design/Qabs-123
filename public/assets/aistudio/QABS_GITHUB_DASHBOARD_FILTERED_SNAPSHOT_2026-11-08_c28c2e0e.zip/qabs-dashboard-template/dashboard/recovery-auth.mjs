export function recoveryReady(e){return e.PASSWORD_RECOVERY_ENABLED==='true'&&e.EMAIL_LOGIN_ENABLED==='true'&&!!e.RESEND_API_KEY&&!!e.MAIL_FROM}
export async function recoveryAuth(req,env,path,h){
 if(!['/api/auth/password/forgot','/api/auth/password/reset','/api/auth/sessions/revoke'].includes(path))return null;
 const {fail,json,keys,read,rate,rand,hash,clock,digest,hex,ITER,user}=h;
 if(req.method!=='POST')fail('method_not_allowed',405);
 if(path==='/api/auth/sessions/revoke'){const u=await user(req,env);await env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(u.id).run();return json({ok:true,signedOut:true},200,{'Set-Cookie':'__Host-qdp_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})}
 if(!recoveryReady(env))fail('password_recovery_unavailable',503);
 await rate(env,'password-reset-ip:'+(req.headers.get('CF-Connecting-IP')||'unknown'),20);
 const b=keys(await read(req,2048),path.endsWith('/forgot')?['email']:['token','password']);
 if(path.endsWith('/forgot')){
  if(typeof b.email!=='string'||b.email.length>254||!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(b.email)||/[\r\n]/.test(b.email))fail('invalid_email');
  const email=b.email.toLowerCase();await rate(env,'password-reset-email:'+email,4);
  await env.DB.prepare('DELETE FROM password_reset_tokens WHERE expires_at<?').bind(clock()-86400).run();
  const account=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first();
  // Uniform public response; failed mail is never reported as delivered.
  if(account){
   const recent=await env.DB.prepare('SELECT token_hash FROM password_reset_tokens WHERE user_id=? AND created_at>? LIMIT 1').bind(account.id,clock()-60).first();
   if(!recent){
    const token=rand(),proof=await hash(token);
    await env.DB.prepare('INSERT INTO password_reset_tokens(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').bind(proof,account.id,clock(),clock()+900).run();
    let sent=false;
    try{const link=env.APP_ORIGIN+(env.APP_BASEPATH||'')+'#/reset-password/'+token;const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'qdp-reset-'+proof},body:JSON.stringify({from:env.MAIL_FROM,to:[email],subject:'استعادة كلمة مرور قبس الرقمية | Reset Qabs Digital password',text:`لإعادة تعيين كلمة المرور افتح الرابط التالي. صالح لمدة ١٥ دقيقة ولمرة واحدة:\nReset your password using this single-use link (15 minutes):\n${link}\nإذا لم تطلب ذلك تجاهل الرسالة. لا تشارك الرابط.\nIf this was not you, ignore this message. Do not share the link.`}),signal:AbortSignal.timeout(10000)});sent=r.ok;await r.body?.cancel()}catch{}
    if(!sent)await env.DB.prepare('DELETE FROM password_reset_tokens WHERE token_hash=?').bind(proof).run();
   }
  }
  return json({accepted:true,message:'If the account exists and delivery is available, a reset link will be sent.'});
 }
 if(!/^[a-f0-9]{64}$/.test(b.token||'')||typeof b.password!=='string'||b.password.length<12||b.password.length>128)fail('invalid_reset_request');
 const proof=await hash(b.token),row=await env.DB.prepare('SELECT user_id FROM password_reset_tokens WHERE token_hash=? AND expires_at>?').bind(proof,clock()).first();if(!row)fail('invalid_or_expired_link',401);
 const salt=hex(crypto.getRandomValues(new Uint8Array(16))),password=await digest(b.password,salt);
 // D1 batch is transactional. Token removal and password update are guarded inside the same transaction.
 const results=await env.DB.batch([
  env.DB.prepare('UPDATE users SET password_hash=?,salt=?,iterations=?,email_verified=1 WHERE id=? AND EXISTS(SELECT 1 FROM password_reset_tokens WHERE token_hash=? AND user_id=? AND expires_at>?)').bind(password,salt,ITER,row.user_id,proof,row.user_id,clock()),
  env.DB.prepare('DELETE FROM sessions WHERE user_id=? AND EXISTS(SELECT 1 FROM password_reset_tokens WHERE token_hash=? AND user_id=? AND expires_at>?)').bind(row.user_id,proof,row.user_id,clock()),
  env.DB.prepare('DELETE FROM email_login_challenges WHERE email=(SELECT email FROM users WHERE id=?) AND EXISTS(SELECT 1 FROM password_reset_tokens WHERE token_hash=? AND user_id=? AND expires_at>?)').bind(row.user_id,proof,row.user_id,clock()),
  env.DB.prepare('DELETE FROM google_auth_challenges WHERE user_id=? AND EXISTS(SELECT 1 FROM password_reset_tokens WHERE token_hash=? AND user_id=? AND expires_at>?)').bind(row.user_id,proof,row.user_id,clock()),
  env.DB.prepare('DELETE FROM mfa_challenges WHERE user_id=?').bind(row.user_id),
  env.DB.prepare('DELETE FROM mfa_setups WHERE user_id=?').bind(row.user_id),
  env.DB.prepare('DELETE FROM password_reset_tokens WHERE user_id=?').bind(row.user_id)
 ]);
 if(results[0].meta.changes!==1)fail('invalid_or_expired_link',401);
 return json({ok:true,passwordChanged:true,signedOut:true},200,{'Set-Cookie':'__Host-qdp_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
}
