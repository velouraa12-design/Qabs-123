// تهيئة قائمة اللوحة مستقلة عن الصفحة التي فُتحت مباشرة، بما فيها صفحات الإعدادات المضافة.
export const CONSOLE_NAVIGATION_JS=String.raw`;(()=>{
let pending=null,owner=null;
async function ensure(){if(!currentUser||typeof window.qabsEnsureConsoleNavigation!=='function')return;const id=currentUser.id;if(pending&&owner===id)return pending;owner=id;const task=Promise.resolve().then(()=>window.qabsEnsureConsoleNavigation());pending=task;try{await task}finally{if(pending===task){pending=null;owner=null}}}
const previous=routeFromHash;routeFromHash=async function(...args){try{return await previous.apply(this,args)}finally{await ensure()}};
if(currentUser)queueMicrotask(ensure);
})();`;
