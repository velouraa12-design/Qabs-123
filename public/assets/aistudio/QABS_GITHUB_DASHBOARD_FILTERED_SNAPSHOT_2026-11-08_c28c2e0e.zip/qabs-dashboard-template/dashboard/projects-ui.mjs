import{PROJECTS_JS,PROJECTS_CSS}from'./projects-ui-packed.mjs';
export function integrateProjects(ui){return{...ui,JS:ui.JS+'\n'+PROJECTS_JS,CSS:ui.CSS+'\n'+PROJECTS_CSS}}
