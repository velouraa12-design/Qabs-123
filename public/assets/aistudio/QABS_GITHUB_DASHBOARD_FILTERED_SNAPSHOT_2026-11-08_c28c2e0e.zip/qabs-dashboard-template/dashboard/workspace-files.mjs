// Owner-only metadata and attachment downloads. Admin status never widens this hub's scope.
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const fail=(m,status=400)=>{throw Object.assign(Error(m),{status})};
const downloadHeaders=id=>({'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename="qabs-service-${id}.bin"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'",'Referrer-Policy':'no-referrer','X-Frame-Options':'DENY'});
export async function workspaceFilesRoute(req,e,path,h){
 if(path!=='/api/workspace-files'&&!path.startsWith('/api/workspace-files/'))return null;
 if(req.method!=='GET')fail('method_not_allowed',405);const u=await h.user(req,e);if(!u.email_verified)fail('verified_email_required',403);
 const one=(sql,...a)=>e.DB.prepare(sql).bind(...a).first();
 if(path==='/api/workspace-files'){
  const url=new URL(req.url),raw=url.searchParams.get('offset')||'0';if(!/^\d{1,6}$/.test(raw))fail('invalid_offset');const offset=Number(raw),limit=40;
  const sql=`SELECT 'formation' source,f.id,f.request_id,CASE f.kind WHEN 'passport' THEN 'Passport' ELSE 'Address proof' END name,f.mime,f.size bytes,f.created_at,r.company_name request_title,CASE WHEN f.details_revision=d.revision THEN 1 ELSE 0 END current_revision FROM formation_documents f JOIN requests r ON r.id=f.request_id JOIN formation_details d ON d.request_id=r.id WHERE f.owner_id=? AND r.owner_id=? AND f.status='ready'
   UNION ALL SELECT 'service' source,f.id,f.request_id,f.name,f.mime,f.bytes,f.created_at,r.title request_title,1 current_revision FROM qs_files f JOIN qs_requests r ON r.id=f.request_id WHERE r.owner_id=? ORDER BY 7 DESC,1,2 LIMIT ? OFFSET ?`;
  const rows=(await e.DB.prepare(sql).bind(u.id,u.id,u.id,limit+1,offset).all()).results;
  const files=rows.slice(0,limit).filter(f=>UUID.test(f.id)&&UUID.test(f.request_id)).map(f=>({...f,download:f.source==='formation'?'/workspace/api/formation-documents/'+f.id:'/workspace/api/workspace-files/service/'+f.id}));
  return h.json({files,account:{id:u.id,email:u.email},scope:'current_account_owner_only',malwareScanned:false,page:{offset,limit,nextOffset:rows.length>limit?offset+limit:null}});
 }
 const m=path.match(/^\/api\/workspace-files\/service\/([a-f0-9-]{36})$/);if(!m||!UUID.test(m[1]))fail('not_found',404);
 const f=await one('SELECT f.id,f.mime,f.bytes,f.content,f.sha256 FROM qs_files f JOIN qs_requests r ON r.id=f.request_id WHERE f.id=? AND r.owner_id=?',m[1],u.id);if(!f)fail('file_not_found',404);
 if(!['application/pdf','image/jpeg','image/png'].includes(f.mime)||!Number.isSafeInteger(f.bytes)||f.bytes<1||f.bytes>262144||typeof f.content!=='string'||f.content.length>349536)fail('file_unavailable',503);
 let bytes;try{bytes=Uint8Array.from(atob(f.content),c=>c.charCodeAt(0))}catch{fail('file_unavailable',503)}
 const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');if(bytes.length!==f.bytes||sha!==f.sha256)fail('file_unavailable',503);
 const ext={'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png'}[f.mime],headers=downloadHeaders(f.id);headers['Content-Disposition']=`attachment; filename="qabs-service-${f.id}.${ext}"`;
 return new Response(bytes,{headers});
}
