import {requireReauth} from './security.mjs';
let certCache=null,certUntil=0;
const enc=new TextEncoder(),cookieName='__Host-qdp_google';
export function googleReady(env){return env.GOOGLE_LOGIN_ENABLED==='true'&&/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/.test(env.GOOGLE_CLIENT_ID||'')}
function unb64(s){if(!/^[A-Za-z0-9_-]+$/.test(s))throw Error('encoding');return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),x=>x.charCodeAt(0))}
async function tokenClaims(token,aud,nonceHash,h){
 const {fail,clock,hash}=h;if(typeof token!=='string'||token.length>12000)fail('google_token_invalid',400);let parts,head,c;
 try{parts=token.split('.');if(parts.length!==3)throw Error('shape');head=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(unb64(parts[0])));c=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(unb64(parts[1])))}catch{fail('google_token_invalid',400)}
 if(!head||head.alg!=='RS256'||typeof head.kid!=='string'||head.kid.length>128||head.crit||head.b64===false)fail('google_token_invalid',400);
 const now=clock();if(!c||!['https://accounts.google.com','accounts.google.com'].includes(c.iss)||c.aud!==aud||c.azp&&c.azp!==aud||!Number.isFinite(c.exp)||c.exp<=now||!Number.isFinite(c.iat)||c.iat>now+60||c.iat<now-7200||c.exp-c.iat>7200||typeof c.sub!=='string'||!c.sub||c.sub.length>255||typeof c.nonce!=='string'||await hash(c.nonce)!==nonceHash)fail('google_token_invalid',400);
 if(!certCache||certUntil<=now){let r;try{r=await fetch('https://www.googleapis.com/oauth2/v3/certs',{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('keys');const data=await r.json();if(!Array.isArray(data.keys)||data.keys.length>20)throw Error('keys');certCache=data.keys;const max=Number(r.headers.get('Cache-Control')?.match(/max-age=(\d+)/)?.[1]||300);certUntil=now+Math.max(30,Math.min(max,3600))}catch{fail('google_verification_unavailable',503)}}
 const jwk=certCache.find(k=>k.kid===head.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256')&&(!k.use||k.use==='sig'));if(!jwk){certUntil=0;fail('google_token_invalid',400)}
 let valid=false;try{const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);valid=await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,unb64(parts[2]),enc.encode(parts[0]+'.'+parts[1]))}catch{}if(!valid)fail('google_token_invalid',400);return c;
}
export async function googleAuth(req,env,path,h){
 if(!['/api/auth/google/start','/api/auth/google/callback','/api/auth/google/status'].includes(path))return null;
 const {fail,json,keys,read,rate,rand,hash,clock,user,issue,digest,hex,ITER,stamp}=h;
 if(!googleReady(env))fail('google_login_not_configured',503);
 if(path.endsWith('/status')){if(req.method!=='GET')fail('method_not_allowed',405);const u=await user(req,env),identity=await env.DB.prepare("SELECT user_id FROM auth_identities WHERE provider='google' AND user_id=?").bind(u.id).first();return json({linked:!!identity})}
 if(req.method!=='POST')fail('method_not_allowed',405);
 const browser=(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1);
 if(path.endsWith('/start')){
  const b=keys(await read(req,512),['link']);if(typeof b.link!=='boolean')fail('invalid_fields');const u=b.link?await user(req,env):null;
  if(u)await requireReauth(env,u);
  await rate(env,'google-start:'+(req.headers.get('CF-Connecting-IP')||'unknown'),30);const id=crypto.randomUUID(),binding=rand(),nonce=rand(),csrf=rand();
  await env.DB.prepare('DELETE FROM google_auth_challenges WHERE id IN (SELECT id FROM google_auth_challenges WHERE expires_at<? LIMIT 100)').bind(clock()-86400).run();
  await env.DB.prepare('INSERT INTO google_auth_challenges(id,nonce_hash,csrf_hash,browser_hash,expires_at,attempts,user_id,session_hash) VALUES(?,?,?,?,?,0,?,?)').bind(id,await hash(nonce),await hash(csrf),await hash(binding),clock()+600,u?.id||null,u?.hash||null).run();return json({challenge_id:id,nonce,csrf,link:b.link},200,{'Set-Cookie':`${cookieName}=${binding}; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=600`});
 }
 const b=keys(await read(req,16000),['challenge_id','credential','csrf','confirm_link']);await rate(env,'google-verify:'+(req.headers.get('CF-Connecting-IP')||'unknown'),50);
 if(!/^[a-f0-9-]{36}$/.test(b.challenge_id||'')||!/^[a-f0-9]{64}$/.test(browser||'')||!/^[a-f0-9]{64}$/.test(b.csrf||''))fail('google_attempt_invalid',400);
 const ch=await env.DB.prepare('UPDATE google_auth_challenges SET attempts=attempts+1 WHERE id=? AND browser_hash=? AND csrf_hash=? AND expires_at>? AND attempts<3 RETURNING *').bind(b.challenge_id,await hash(browser),await hash(b.csrf),clock()).first();if(!ch)fail('google_attempt_invalid',400);
 const c=await tokenClaims(b.credential,env.GOOGLE_CLIENT_ID,ch.nonce_hash,h);
 let linkingUser=null;if(ch.user_id){linkingUser=await user(req,env);await requireReauth(env,linkingUser);if(linkingUser.id!==ch.user_id||linkingUser.hash!==ch.session_hash||b.confirm_link!==true)fail('google_link_confirmation_required',403)}else if(b.confirm_link===true)fail('google_link_confirmation_required',403);
 const consumed=await env.DB.prepare('DELETE FROM google_auth_challenges WHERE id=? AND browser_hash=? AND csrf_hash=? AND expires_at>? RETURNING id').bind(ch.id,await hash(browser),await hash(b.csrf),clock()).first();if(!consumed)fail('google_attempt_invalid',400);
 const identity=await env.DB.prepare("SELECT user_id FROM auth_identities WHERE provider='google' AND subject=?").bind(c.sub).first();
 if(linkingUser){if(identity&&identity.user_id!==linkingUser.id)fail('google_identity_in_use',409);try{await env.DB.prepare("INSERT INTO auth_identities(provider,subject,user_id,created_at) VALUES('google',?,?,?) ON CONFLICT(provider,subject) DO NOTHING").bind(c.sub,linkingUser.id,stamp()).run()}catch{fail('google_already_linked',409)}const actual=await env.DB.prepare("SELECT user_id FROM auth_identities WHERE provider='google' AND subject=?").bind(c.sub).first();if(actual?.user_id!==linkingUser.id)fail('google_identity_in_use',409);return json({linked:true})}
 let id=identity?.user_id;
 if(!id){const email=typeof c.email==='string'?c.email.toLowerCase():'';const authoritative=email.endsWith('@gmail.com')||c.email_verified===true&&typeof c.hd==='string'&&c.hd.length>0;
  if(c.email_verified!==true||!authoritative||!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)||email.length>254)fail('google_email_confirmation_required',409);
  if(await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first())fail('google_link_required',409);
  if(env.REGISTRATION_ENABLED!=='true')fail('registration_disabled',403);
  id=crypto.randomUUID();const salt=hex(crypto.getRandomValues(new Uint8Array(16))),password=await digest(rand(),salt);
  try{await env.DB.batch([env.DB.prepare("INSERT INTO users(id,email,password_hash,salt,iterations,role,email_verified,created_at) VALUES(?,?,?,?,?,'client',1,?)").bind(id,email,password,salt,ITER,stamp()),env.DB.prepare("INSERT INTO auth_identities(provider,subject,user_id,created_at) VALUES('google',?,?,?)").bind(c.sub,id,stamp())])}catch{const won=await env.DB.prepare("SELECT user_id FROM auth_identities WHERE provider='google' AND subject=?").bind(c.sub).first();if(!won)fail('google_link_required',409);id=won.user_id}
 }
 const response=await issue(env,id),headers=new Headers(response.headers);headers.append('Set-Cookie',`${cookieName}=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`);return new Response(response.body,{status:response.status,headers});
}
