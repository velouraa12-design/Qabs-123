import{JS,CSS}from'./workspace-stores-ui-packed.mjs';export function integrateWorkspaceStores(ui){return{...ui,JS:ui.JS+'\n'+JS,CSS:ui.CSS+'\n'+CSS}}
