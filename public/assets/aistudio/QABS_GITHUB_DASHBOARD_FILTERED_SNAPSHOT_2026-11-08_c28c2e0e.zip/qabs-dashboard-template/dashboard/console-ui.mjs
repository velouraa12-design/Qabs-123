import{JS,CSS}from'./console-ui-packed.mjs';
// Keep the server-authorized navigation loader available to all final route wrappers.
const end='if(currentUser)routeFromHash()})();';
const expose='window.qabsEnsureConsoleNavigation=async()=>{if(currentUser&&(r!==currentUser.id||!n.querySelector("[data-section]"))&&!n.querySelector("[data-console-retry]"))return L()};'+end;
const fail='n.replaceChildren();w(o,r,()=>L());';
const recover='n.replaceChildren();const retry=e("div",undefined,"console-navigation-retry");retry.dataset.consoleRetry="1";w(retry,r,()=>L());n.append(retry);w(o,r,()=>L());';
if(!JS.includes(end)||!JS.includes(fail))throw Error('console_navigation_patch_mismatch');
const fixed=JS.replace(end,expose).replace(fail,recover);
export function integrateConsole(ui){return{...ui,JS:ui.JS+'\n'+fixed,CSS:ui.CSS+'\n'+CSS}}
