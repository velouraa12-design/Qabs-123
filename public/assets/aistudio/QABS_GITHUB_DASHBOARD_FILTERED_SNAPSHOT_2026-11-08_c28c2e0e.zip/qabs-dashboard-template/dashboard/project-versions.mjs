import {storeContent} from './store-content.mjs';
const fail=(c,s=400)=>{throw Object.assign(Error(c),{status:s})};
const keys=(b,allowed)=>{if(!b||typeof b!=='object'||Array.isArray(b)||Object.keys(b).some(k=>!allowed.includes(k)))fail('invalid_fields');return b};
const rows=async s=>(await s.all()).results||[];
export async function projectVersionsRoute(req,env,path,h,u,loadProject,clean){
 const m=path.match(/^\/api\/projects\/([a-f0-9-]{36})\/versions(?:\/([1-9][0-9]{0,9})(?:\/(restore))?)?$/);if(!m)return null;
 const {json,read,rate}=h,url=new URL(req.url),pid=m[1],p=await loadProject(env,u,pid),version=m[2]?Number(m[2]):null;
 if(req.method!=='GET'&&!(req.method==='POST'&&m[3]))fail('method_not_allowed',405);
 let body;if(req.method==='POST'){if(req.headers.get('Origin')!==env.APP_ORIGIN)fail('origin_rejected',403);body=keys(await read(req,2048),['scope','project_revision','content_revision','confirm']);}
 const scope=body?.scope||url.searchParams.get('scope')||'metadata';if(!['metadata','content'].includes(scope))fail('invalid_version_scope');
 if(scope==='content'&&(!p.editor_draft_id||p.owner_id!==u.id))fail('content_history_not_available',403);
 const currentContent=scope==='content'?await env.DB.prepare('SELECT revision FROM store_draft_content WHERE draft_id=? AND owner_id=?').bind(p.editor_draft_id,u.id).first():null;
 const current=scope==='content'?(currentContent?.revision||0):p.revision;
 if(req.method==='GET'&&!version){const raw=url.searchParams.get('offset')||'0';if(!/^\d{1,5}$/.test(raw)||+raw>10000)fail('invalid_pagination');const offset=Number(raw);const list=scope==='content'?await rows(env.DB.prepare('SELECT revision,saved_at,length(config) bytes FROM qabs_content_versions WHERE draft_id=? AND owner_id=? ORDER BY revision DESC LIMIT 26 OFFSET ?').bind(p.editor_draft_id,u.id,offset)):await rows(env.DB.prepare('SELECT revision,name,description,type,template_key,status,saved_at FROM qabs_project_versions WHERE project_id=? ORDER BY revision DESC LIMIT 26 OFFSET ?').bind(pid,offset));return json({scope,current_revision:current,project_revision:p.revision,versions:list.slice(0,25),next_offset:list.length>25?offset+25:null,can_restore:['owner','admin','editor'].includes(p.member_role)&&p.status==='active',history_scope:scope==='content'?'saved_store_configuration_only':'project_name_and_description_only',historical_revisions_before_activation:'unavailable',published:false});}
 const snapshot=scope==='content'?await env.DB.prepare('SELECT revision,config,saved_at FROM qabs_content_versions WHERE draft_id=? AND owner_id=? AND revision=?').bind(p.editor_draft_id,u.id,version).first():await env.DB.prepare('SELECT revision,name,description,type,template_key,status,saved_at FROM qabs_project_versions WHERE project_id=? AND revision=?').bind(pid,version).first();if(!snapshot)fail('project_version_not_found',404);
 if(req.method==='GET')return json({scope,snapshot:scope==='content'?{...snapshot,config:JSON.parse(snapshot.config)}:snapshot,current_revision:current,project_revision:p.revision,published:false});
 if(body.confirm!==true)fail('explicit_confirmation_required');await loadProject(env,u,pid,true);if(p.status!=='active')fail('project_archived',409);
 if(!Number.isSafeInteger(body.project_revision)||body.project_revision!==p.revision)fail('project_revision_conflict',409);
 if(scope==='content'){
  if(!Number.isSafeInteger(body.content_revision)||body.content_revision!==current)fail('store_revision_conflict',409);
  await rate(env,'project-version-restore:'+u.id,30);const target=new URL(req.url);target.pathname=(env.APP_BASEPATH||'')+'/api/store-content/'+p.editor_draft_id;target.search='';const delegated=new Request(target,{method:'PUT',headers:new Headers(req.headers),body:JSON.stringify({revision:current,config:JSON.parse(snapshot.config)})});
  const result=await storeContent(delegated,env,'/api/store-content/'+p.editor_draft_id,{...h,fail,keys});if(!result.ok)return result;const saved=await result.json();return json({restored:true,scope,from_revision:version,revision:saved.revision,project_revision:p.revision,published:false,payments:false,files_restored:false});
 }
 if(Object.hasOwn(body,'content_revision'))fail('invalid_fields');if(snapshot.type!==p.type||snapshot.template_key!==p.template_key)fail('version_type_mismatch',409);
 const name=clean(snapshot.name,120),description=clean(snapshot.description,1000,false);if(name===p.name&&description===p.description)return json({restored:true,unchanged:true,scope,revision:p.revision,from_revision:version,published:false});
 await rate(env,'project-version-restore:'+u.id,30);const at=new Date().toISOString(),op=crypto.randomUUID();const result=await env.DB.batch([
 env.DB.prepare("UPDATE projects SET name=?,description=?,revision=revision+1,last_actor=?,last_operation=?,updated_at=? WHERE id=? AND revision=? AND status='active' AND EXISTS(SELECT 1 FROM project_memberships WHERE workspace_id=projects.workspace_id AND user_id=? AND status='active' AND role IN ('owner','admin','editor')) RETURNING revision").bind(name,description,u.id,op,at,pid,p.revision,u.id),
 env.DB.prepare('UPDATE store_drafts SET name=? WHERE id=(SELECT editor_draft_id FROM projects WHERE id=? AND last_operation=?) AND owner_id=?').bind(name,pid,op,p.owner_id)
 ]);if(!result[0].results?.length)fail('project_revision_conflict',409);return json({restored:true,scope,from_revision:version,revision:result[0].results[0].revision,published:false,content_restored:false,status_changed:false});
}
