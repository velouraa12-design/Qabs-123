import{STORE_LINK_JS,STORE_LINK_CSS}from'./store-links-ui-packed.mjs';export function integrateStoreLinks(ui){return{...ui,JS:ui.JS+'\n'+STORE_LINK_JS,CSS:ui.CSS+'\n'+STORE_LINK_CSS}}
