// تغيير بريد الحساب نفسه فقط؛ لا دمج للحسابات ولا تعديل لبريد المتاجر أو صلاحياتها.
import {securityReady,requireReauth} from './security.mjs';
const fail=(m,status=400)=>{throw Object.assign(Error(m),{status})},now=()=>Math.floor(Date.now()/1000),enc=new TextEncoder();
const hex=a=>Array.from(new Uint8Array(a),x=>x.toString(16).padStart(2,'0')).join(''),equal=(a,b)=>{if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0};
export const emailChangeReady=e=>e.EMAIL_CHANGE_ENABLED==='true'&&e.EMAIL_LOGIN_ENABLED==='true'&&!!e.RESEND_API_KEY&&!!e.MAIL_FROM&&securityReady(e);
async function proof(e,id,uid,mail,code){const key=await crypto.subtle.importKey('raw',enc.encode(e.ACCOUNT_SECURITY_KEY),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode(JSON.stringify(['qabs-email-change-v1',id,uid,mail,code]))))}
async function send(e,id,to,subject,text){try{const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+e.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'qabs-email-change-'+id},body:JSON.stringify({from:e.MAIL_FROM,to:[to],subject,text}),signal:AbortSignal.timeout(10000)});const ok=r.ok;await r.body?.cancel();return ok}catch{return false}}
export async function emailChangeRoute(req,e,path,h){
 if(!['/api/settings/email','/api/settings/email/start','/api/settings/email/confirm'].includes(path))return null;
 const {user,json,read,keys,rate}=h,u=await user(req,e),q=(s,...a)=>e.DB.prepare(s).bind(...a).first(),p=(s,...a)=>e.DB.prepare(s).bind(...a);
 if(path==='/api/settings/email'&&req.method==='GET')return json({available:emailChangeReady(e),email:u.email,scope:'studio_account_only',commerceEmailChanged:false,reauthRequired:true,signOutOnSuccess:true,googleIdentitiesPreserved:true});
 if(req.method!=='POST'||path==='/api/settings/email')fail('method_not_allowed',405);
 if(!emailChangeReady(e))fail('email_change_unavailable',503);
 if(!u.email_verified)fail('verified_email_required',403);
 await requireReauth(e,u);const m=await q('SELECT enabled,version FROM account_mfa WHERE user_id=?',u.id);if(u.role==='admin'&&!m?.enabled)fail('admin_mfa_required',403);
 const b=keys(await read(req,1024),path.endsWith('/start')?['email','consent']:['challenge_id','code','consent']);if(b.consent!==true)fail('email_change_consent_required');
 await rate(e,'email-change-ip:'+(req.headers.get('CF-Connecting-IP')||'unknown'),30);
 if(path.endsWith('/start')){
  if(typeof b.email!=='string'||b.email.length>254||!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$/.test(b.email.trim()))fail('invalid_email');const mail=b.email.trim().toLowerCase();if(mail===u.email.toLowerCase())fail('email_unchanged');
  if(e.EMAIL_LOGIN_TEST_RECIPIENT&&mail!==e.EMAIL_LOGIN_TEST_RECIPIENT)fail('email_change_pilot_only',403);
  await rate(e,'email-change-user:'+u.id,3);await rate(e,'email-change-target:'+mail,3);
  if(await q('SELECT id FROM users WHERE email=? COLLATE NOCASE',mail))fail('email_unavailable',409);
  if(await q('SELECT id FROM account_email_changes WHERE user_id=? AND created_at>?',u.id,now()-60))fail('email_change_wait',429);
  const credential=await q('SELECT password_hash FROM users WHERE id=?',u.id),id=crypto.randomUUID();let n;do{n=crypto.getRandomValues(new Uint32Array(1))[0]}while(n>=4200000000);const code=String(n%100000000).padStart(8,'0');
  await p('DELETE FROM account_email_changes WHERE id IN(SELECT id FROM account_email_changes WHERE expires_at<? LIMIT 100)',now()-86400).run();
  await p("INSERT INTO account_email_changes(id,user_id,session_hash,old_email,new_email,password_hash,mfa_version,proof_hash,created_at,expires_at,status) VALUES(?,?,?,?,?,?,?,?,?,?,'sending')",id,u.id,u.hash,u.email,mail,credential.password_hash,m?.version||0,await proof(e,id,u.id,mail,code),now(),now()+600).run();
  // نجاح إرسال التنبيه والرمز شرط لفتح التحقق، ولا نعتبر الحفظ المحلي نجاحًا.
  const notified=await send(e,id+'-old',u.email,'طلب تغيير البريد الأساسي — قبس',`طُلب تغيير بريد حساب قبس إلى ${mail}. لم يتم التغيير بعد. يلزم رمز للبريد الجديد وتأكيد الهوية. إذا لم تطلب ذلك، غيّر كلمة المرور وألغِ الجلسات من بوابة قبس. بريد حساب المتاجر وصلاحياته لا يتغيران بهذا الطلب.`);
  const delivered=notified&&await send(e,id+'-new',mail,'رمز تغيير بريد قبس | Qabs email change',`رمز تأكيد تغيير بريد حساب قبس: ${code}\nصالح لعشر دقائق ولمرة واحدة. استخدمه فقط في إعدادات بريد حسابك على portal.qabs1.store. لا تشاركه. إذا لم تطلب تغيير البريد تجاهل الرسالة.\nQabs email change code: ${code}. Expires in 10 minutes.`);
  if(!delivered){await p('DELETE FROM account_email_changes WHERE id=?',id).run();fail('email_delivery_unavailable',503)}
  await e.DB.batch([p('DELETE FROM account_email_changes WHERE user_id=? AND id<>? AND status<>?',u.id,id,'complete'),p("UPDATE account_email_changes SET status='sent' WHERE id=?",id)]);
  return json({accepted:true,challenge_id:id,email:mail,expiresIn:600,changed:false});
 }
 await rate(e,'email-change-confirm:'+u.id,20);
 if(!/^[a-f0-9-]{36}$/.test(b.challenge_id||'')||!/^\d{8}$/.test(b.code||''))fail('invalid_or_expired_code',401);
 const row=await q("UPDATE account_email_changes SET attempts=attempts+1 WHERE id=? AND user_id=? AND session_hash=? AND status='sent' AND expires_at>? AND attempts<5 AND claim IS NULL RETURNING *",b.challenge_id,u.id,u.hash,now());
 if(!row||!equal(row.proof_hash,await proof(e,row.id,u.id,row.new_email,b.code)))fail('invalid_or_expired_code',401);
 // الادعاء والتغيير وإلغاء الجلسات تتم معًا؛ يُعاد فحص كلمة المرور وMFA والإيميل داخل المعاملة.
 const claim=crypto.randomUUID(),guard=`EXISTS(SELECT 1 FROM users u JOIN sessions s ON s.user_id=u.id JOIN session_assurance a ON a.session_hash=s.hash WHERE u.id=account_email_changes.user_id AND u.email=account_email_changes.old_email AND u.password_hash=account_email_changes.password_hash AND s.hash=account_email_changes.session_hash AND s.expires_at>? AND a.user_id=u.id AND a.password_hash=u.password_hash AND a.reauth_until>? AND a.version=account_email_changes.mfa_version AND COALESCE((SELECT version FROM account_mfa WHERE user_id=u.id),0)=account_email_changes.mfa_version AND (u.role<>'admin' OR EXISTS(SELECT 1 FROM account_mfa WHERE user_id=u.id AND enabled=1)))`;
 const won='EXISTS(SELECT 1 FROM account_email_changes c WHERE c.id=? AND c.user_id=? AND c.claim=? AND c.status=\'complete\')',args=[row.id,u.id,claim];
 let out;try{out=await e.DB.batch([
  p(`UPDATE account_email_changes SET claim=? WHERE id=? AND user_id=? AND session_hash=? AND status='sent' AND claim IS NULL AND expires_at>? AND proof_hash=? AND ${guard} AND NOT EXISTS(SELECT 1 FROM users WHERE email=account_email_changes.new_email COLLATE NOCASE)`,claim,row.id,u.id,u.hash,now(),row.proof_hash,now(),now()),
  p("UPDATE users SET email=?,email_verified=1 WHERE id=? AND email=? AND password_hash=? AND EXISTS(SELECT 1 FROM account_email_changes WHERE id=? AND claim=? AND status='sent')",row.new_email,u.id,row.old_email,row.password_hash,row.id,claim),
  p("UPDATE account_email_changes SET status='complete' WHERE id=? AND claim=? AND EXISTS(SELECT 1 FROM users WHERE id=? AND email=account_email_changes.new_email AND email_verified=1)",row.id,claim,u.id),
  p('DELETE FROM sessions WHERE user_id=? AND '+won,u.id,...args),p('DELETE FROM session_assurance WHERE user_id=? AND '+won,u.id,...args),
  p('DELETE FROM password_reset_tokens WHERE user_id=? AND '+won,u.id,...args),p('DELETE FROM email_login_challenges WHERE email IN(?,?) AND '+won,row.old_email,row.new_email,...args),
  p('DELETE FROM mfa_challenges WHERE user_id=? AND '+won,u.id,...args),p('DELETE FROM google_auth_challenges WHERE user_id=? AND '+won,u.id,...args),
  p("DELETE FROM account_email_changes WHERE user_id=? AND id<>? AND "+won,u.id,row.id,...args)
 ])}catch{fail('email_change_conflict',409)}
 if(out[1].meta.changes!==1||out[2].meta.changes!==1)fail('email_change_conflict',409);
 return json({changed:true,email:row.new_email,signedOut:true,scope:'studio_account_only',commerceEmailChanged:false,googleIdentitiesPreserved:true},200,{'Set-Cookie':'__Host-qdp_session=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
}
