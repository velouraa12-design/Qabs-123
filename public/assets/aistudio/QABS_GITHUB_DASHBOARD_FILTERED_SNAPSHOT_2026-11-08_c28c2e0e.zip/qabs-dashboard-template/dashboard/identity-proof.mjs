// Fresh proof of the existing Studio account; never accepts a target account ID.
export async function identityProofRoute(req,e,path,h){
 if(path!=='/api/identity-link/proof')return null;
 if(e.IDENTITY_LINK_ENABLED!=='true')return h.json({error:'identity_link_not_enabled'},503);
 if(req.method!=='POST')h.fail('method_not_allowed',405);
 const u=await h.user(req,e);if(!u.email_verified)h.fail('email_verification_required',403);
 h.keys(await h.read(req,256),[]);await h.requireReauth(e,u);
 const m=await e.DB.prepare('SELECT enabled FROM account_mfa WHERE user_id=?').bind(u.id).first();
 return h.json({id:u.id,email:u.email,emailVerified:true,csrf:u.csrf,mfaEnabled:!!m?.enabled});
}
