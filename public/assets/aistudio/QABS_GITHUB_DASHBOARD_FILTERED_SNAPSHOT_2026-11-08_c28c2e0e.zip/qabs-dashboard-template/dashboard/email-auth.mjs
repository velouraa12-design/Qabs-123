const cookieName='__Host-qdp_email';
export function emailReady(env){return env.EMAIL_LOGIN_ENABLED==='true'&&!!env.RESEND_API_KEY&&!!env.MAIL_FROM}
export async function emailAuth(req,env,path,h){
 if(!['/api/auth/email/start','/api/auth/email/verify'].includes(path))return null;
 const {json,fail,keys,read,text,hash,rate,rand,clock,issue,digest,hex,stamp,ITER}=h;
 if(req.method!=='POST')fail('method_not_allowed',405);
 if(!emailReady(env))fail('email_login_not_configured',503);
 const b=keys(await read(req,2048),path.endsWith('/start')?['email']:['challenge_id','code']);
 const browser=(req.headers.get('Cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);
 const proof=async(id,email,code)=>{const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.RESEND_API_KEY),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('qdp-email-login-v1|'+id+'|'+email+'|'+code)))};
 if(path.endsWith('/start')){
  const email=text(b.email,254).toLowerCase();if(!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)||/[\r\n]/.test(email))fail('invalid_email');
  if(env.EMAIL_LOGIN_TEST_RECIPIENT&&email!==env.EMAIL_LOGIN_TEST_RECIPIENT)fail('email_login_pilot_only',403);
  await env.DB.prepare('DELETE FROM email_login_challenges WHERE id IN (SELECT id FROM email_login_challenges WHERE expires_at<? LIMIT 100)').bind(clock()-86400).run();
  await rate(env,'email-login-ip:'+(req.headers.get('CF-Connecting-IP')||'unknown'),10);await rate(env,'email-login-address:'+email,5);
  const recent=await env.DB.prepare('SELECT id FROM email_login_challenges WHERE email=? AND created_at>? LIMIT 1').bind(email,clock()-60).first();if(recent)fail('email_login_wait',429);
  const id=crypto.randomUUID(),binding=rand();let n;do{n=crypto.getRandomValues(new Uint32Array(1))[0]}while(n>=4200000000);const code=String(n%100000000).padStart(8,'0');
  await env.DB.prepare("INSERT INTO email_login_challenges(id,email,proof_hash,browser_hash,created_at,expires_at,attempts,status) VALUES(?,?,?,?,?,?,0,'sending')").bind(id,email,await proof(id,email,code),await hash(binding),clock(),clock()+600).run();
  let sent=false;
  try{const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'qdp-login-'+id},body:JSON.stringify({from:env.MAIL_FROM,to:[email],subject:'رمز دخول قبس الرقمية | Qabs Digital sign-in code',text:`رمز الدخول إلى قبس الرقمية: ${code}\nSign-in code: ${code}\nصالح لعشر دقائق ولمرة واحدة. لا تشاركه مع أي شخص.\nExpires in 10 minutes. Do not share this code.\nإذا لم تطلب الدخول تجاهل الرسالة. If you did not request this, ignore this email.`}),signal:AbortSignal.timeout(10000)});sent=r.ok;await r.body?.cancel()}catch{}
  if(!sent){await env.DB.prepare('DELETE FROM email_login_challenges WHERE id=?').bind(id).run();fail('email_delivery_unavailable',503)}
  await env.DB.prepare("UPDATE email_login_challenges SET status='sent' WHERE id=?").bind(id).run();
  return json({accepted:true,challenge_id:id,expiresIn:600},200,{'Set-Cookie':`${cookieName}=${binding}; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=600`});
 }
 await rate(env,'email-login-verify-ip:'+(req.headers.get('CF-Connecting-IP')||'unknown'),40);
 if(!/^[a-f0-9-]{36}$/.test(b.challenge_id||'')||!/^\d{8}$/.test(b.code||'')||!/^[a-f0-9]{64}$/.test(browser||''))fail('invalid_or_expired_code',401);
 const row=await env.DB.prepare("UPDATE email_login_challenges SET attempts=attempts+1 WHERE id=? AND browser_hash=? AND status='sent' AND expires_at>? AND attempts<5 RETURNING id,email,proof_hash").bind(b.challenge_id,await hash(browser),clock()).first();
 if(!row)fail('invalid_or_expired_code',401);
 const candidate=await proof(row.id,row.email,b.code);let mismatch=0;for(let i=0;i<64;i++)mismatch|=candidate.charCodeAt(i)^row.proof_hash.charCodeAt(i);if(mismatch)fail('invalid_or_expired_code',401);
 const consumed=await env.DB.prepare("DELETE FROM email_login_challenges WHERE id=? AND proof_hash=? AND browser_hash=? AND expires_at>? RETURNING email").bind(row.id,candidate,await hash(browser),clock()).first();if(!consumed)fail('invalid_or_expired_code',401);
 let account=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(row.email).first();
 if(!account){if(env.REGISTRATION_ENABLED!=='true')fail('invalid_or_expired_code',401);const id=crypto.randomUUID(),salt=hex(crypto.getRandomValues(new Uint8Array(16))),password_hash=await digest(rand(),salt);try{await env.DB.prepare("INSERT INTO users(id,email,password_hash,salt,iterations,role,email_verified,created_at) VALUES(?,?,?,?,?,'client',1,?)").bind(id,row.email,password_hash,salt,ITER,stamp()).run();account={id}}catch{account=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(row.email).first();if(!account)fail('account_unavailable',503)}}
 await env.DB.prepare('UPDATE users SET email_verified=1 WHERE id=?').bind(account.id).run();
 const response=await issue(env,account.id),headers=new Headers(response.headers);headers.append('Set-Cookie',`${cookieName}=; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`);return new Response(response.body,{status:response.status,headers});
}
